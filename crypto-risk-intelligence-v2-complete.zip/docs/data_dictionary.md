# Data dictionary

Every number in the API and dashboard comes from the tables below. Units are
explicit on purpose: mixing percent with fraction, or per-day with per-year
variance, is the most common way a risk platform silently lies.

**Sign conventions (fixed end-to-end)**

| Quantity | Sign / unit | Where |
|---|---|---|
| `ret_pct` | percent, `100·ln(P_t/P_{t−1})` | `engineered_features` |
| `rv` | percent² per day (sum of squared intraday returns) | `engineered_features` |
| `rv_ann_vol` / `predicted_vol_annualized` | **fraction** (0.65 = 65 % annualized) | features, forecasts |
| `predicted_rv` | percent² per day, same units as `rv` | `forecasts` |
| `var_pct`, `es_pct` | **positive loss** in percent of notional (a 4.2 means −4.2 % P&L) | `var_es_estimates` |
| `actual_loss_pct` | `max(0, −realized_return_pct)`, positive = loss | `var_es_estimates` |
| `funding_rate` | fraction per funding interval as reported by the venue | `derivative_metrics` |
| `basis` | fraction, `mark/index − 1` | `derivative_metrics` |
| `spread_bps` | basis points, `(ask−bid)/mid·10 000` | `markets`, `market_snapshots` |

---

## `exchanges`

One row per venue adapter (8 configured).

| Column | Type | Meaning |
|---|---|---|
| `code` | text PK | `binance_spot`, `binance_futures`, `okx_spot`, `okx_swap`, `bybit_spot`, `bybit_linear`, `coinbase`, `kraken` |
| `name` | text | human label |
| `market_types` | JSON | `["spot"]`, `["swap","futures"]`, … |
| `enabled` | bool | adapter participating in discovery |
| `rest_url`, `ws_url` | text | endpoints actually used |
| `status` | text | `ok` / `degraded` / `blocked` / `unknown` (last probe) |
| `status_detail` | text | HTTP status and venue message when blocked (never invented) |
| `latency_ms`, `time_skew_ms` | float | probe results |
| `last_checked_at` | ts | probe time |
| `capabilities` | JSON | tri-state booleans per feature (`ohlcv`, `funding`, `open_interest`, `mark_price`, `liquidation`, `orderbook`, `trades`, `websocket`) — `false` means the venue or the environment does not provide it |
| `notes` | text | free-text caveats |

## `markets`

One row per tradable instrument found by discovery (≈3 200 rows); the research
universe is the subset with `in_universe = true`.

| Column | Type | Meaning |
|---|---|---|
| `exchange_code`, `symbol` | text | **composite PK** — the canonical identity is `(exchange, market_type, base, quote, contract_type, price_unit)`, never the ticker alone |
| `canonical_symbol` | text | `EXCHANGE:BASE/QUOTE[:CONTRACT]` display id |
| `base_asset`, `quote_asset` | text | normalized (`1000PEPE → PEPE`, `XBT → BTC` on Kraken) |
| `market_type` | text | `spot`, `swap`, `futures` |
| `contract_type` | text | `perpetual`, `dated`, null for spot |
| `price_unit` | text | `quote` or the contract multiplier for 1000× contracts (`1000PEPE` is *not* merged with `PEPE`) |
| `status` | text | venue trading status |
| `is_stable_pair`, `is_leveraged_token`, `is_wrapped` | bool | quality flags; stable and leveraged pairs are excluded from the universe |
| `in_universe` | bool | selected for deep ingestion (target 34) |
| `model_eligible` | bool | has enough history *and* completeness to be modelled |
| `ineligible_reasons` | JSON | list such as `["insufficient_history"]` |
| `eligibility` | text | `eligible` / `insufficient_history` / `insufficient_completeness` / `excluded_*` |
| `last_price`, `quote_volume_24h`, `bid`, `ask`, `spread_bps`, `price_change_24h_pct` | float | latest venue snapshot |
| `last_update_ts` | ts | venue timestamp of the snapshot |
| `data_completeness` | float | fraction of expected bars present |
| `history_days_available` | int | days between first and last bar |
| `meta_json` | JSON | raw venue metadata worth keeping |
| `discovered_at`, `updated_at` | ts | bookkeeping |

## `ohlcv`

Raw 4 h bars (canonical research timeframe; 1 h/1 d used only for spot checks).

| Column | Type | Meaning |
|---|---|---|
| `exchange_code`, `symbol`, `timeframe`, `ts` | — | **unique key**; `ts` is the bar **open** time in UTC |
| `open`, `high`, `low`, `close`, `volume`, `quote_volume` | float | venue OHLCV, quote volume only when the venue serves it |
| `is_final` | bool | `true` once the bar's close time has passed — the only bars used for modelling |
| `source` | text | `rest` / `ws` / venue-specific |
| `ingested_at` | ts | **ingest time** (distinct from event time `ts`) |

## `market_snapshots`

Point-in-time ticker snapshots (price/bid/ask/spread/24 h volume) used for
freshness and liquidity alerts. Append-only, ~1 row per market per refresh.

## `derivative_metrics`

Only written for markets whose adapter declares the capability *and* the venue
returns the field.

| Column | Meaning |
|---|---|
| `exchange_code`, `symbol`, `ts` | unique key |
| `funding_rate`, `funding_next` | current / next funding rate (fraction) |
| `open_interest`, `open_interest_quote` | contracts and quote-notional OI |
| `mark_price`, `index_price`, `basis` | mark and index prices, `mark/index − 1` |
| `source` | endpoint family used |

## `engineered_features`

Daily feature rows, one per `(market, bar_date)`; the modelling input.

| Column | Meaning |
|---|---|
| `close` | last 4 h close of the day |
| `ret_pct` | daily log return in percent |
| `rv` | realized variance, percent²/day, Σ r² of intraday 4 h returns |
| `rv_w`, `rv_m` | 5-day and 22-day trailing means of `rv` |
| `semivar_neg`, `semivar_pos` | downside/upside semivariance |
| `range_pct` | Parkinson-style high-low range in percent |
| `volume`, `quote_volume`, `volume_z` | volume and its 30-day z-score |
| `funding_rate`, `open_interest`, `oi_change_7d` | derivative context where available, else null |
| `spread_bps` | latest spread |
| `cross_btc_rv` | BTC realized variance on the same date (cross-asset signal) |
| `n_bars`, `completeness` | intraday bars available and fraction of expected |
| `features_json` | HAR/XGBoost feature vector actually fed to the models |

## `realized_targets`

The label every forecast is scored against. `target_rv` is the **forward
average** realized variance over the horizon (percent²/day), `target_vol_annualized`
is its annualized square root in fraction units. Written only once the whole
target window has closed, which is what makes `forecasts.actual_rv` safe.

## `forecasts`

Immutable forecast log. Rows are never updated in place; a re-run appends a new
`run_id`, and scoring fills `actual_rv` exactly once.

| Column | Meaning |
|---|---|
| `id` | surrogate PK |
| `exchange_code`, `symbol`, `model_name`, `model_version`, `horizon`, `bar_date` | forecast identity (`bar_date` = origin date) |
| `forecast_ts` | when the forecast was produced |
| `data_cutoff_ts` | latest data the model could see — always ≤ `forecast_ts` |
| `target_start_date`, `target_end_date` | the window being predicted |
| `predicted_rv` | percent²/day |
| `predicted_vol_annualized` | fraction |
| `actual_rv` | filled once, after `target_end_date` |
| `config_json` | model hyper-parameters and feature list |
| `data_quality` | `ok` / `stale` / `gapped` at origin time |
| `run_id` | links to `model_runs.id` |

Models: `naive`, `har_rv`, `garch_normal`, `garch_t`, `xgb_har`, `xgb_extended`.
Horizons 1/7/30 days are produced **directly** (one model per horizon); they are
never summed from one-step forecasts.

## `var_es_estimates`

Walk-forward VaR/ES, one row per `(market, model, confidence, asof_date)`.

| Column | Meaning |
|---|---|
| `asof_date` | origin: estimates use data up to and including this date |
| `model_name` | `historical`, `garch_normal`, `garch_t`, `garch_evt` |
| `confidence` | 0.95, 0.975, 0.99 |
| `horizon_days` | always 1 (one-day-ahead) |
| `var_pct`, `es_pct` | positive loss percent |
| `mu`, `sigma` | conditional mean/std used (percent) |
| `threshold`, `xi`, `beta`, `n_exceedances` | GPD fit (EVT model only) — threshold is **data-driven per origin**, never global |
| `method_meta` | JSON: `standardized_residuals: true`, fallback reason, ES-finite flag |
| `actual_loss_pct`, `breach` | realized loss and `loss > var` |

GARCH-EVT applies POT/GPD to **standardized residuals** (`z_t`) of the GARCH
filter, not to raw losses, and converts back with the conditional `σ_t`; that
choice is recorded in `method_meta` and documented in the limitations report.

## `backtest_results`

Long-format metric store: `run_id, scope, exchange_code, symbol, horizon,
model_name, metric, value, n_obs, p_value, config_json`. Metrics include RMSE,
MAE, QLIKE (mean **and** median), Diebold–Mariano statistics and coverage /
independence p-values. `scope` is `market`, `exchange`, `asset` or `global`.

## `model_registry` / `model_runs`

`model_registry` holds name, version, family, target definition and params.
`model_runs` is the audit trail: `kind` (`forecast`, `risk`, `evaluation`,
`ingest`), status, timings, `scope_json` (which markets, which config) and
`metrics_json` (per-market diagnostics, including `insufficient_history` reasons).

## `alerts`

| Column | Meaning |
|---|---|
| `dedupe_key` | stable hash of type + market + trigger so one episode is one alert |
| `severity` | `info` / `warning` / `critical` |
| `alert_type` | `high_forecast_vol`, `var_breach`, `es_jump`, `price_shock`, `liquidity_drop`, `spread_widening`, `funding_spike`, `oi_shift`, `stale_data`, `model_drift` |
| `trigger`, `message` | machine-readable condition and human explanation |
| `observed_value`, `threshold` | what was seen vs the configured limit |
| `acknowledged` | analyst flag (PUT endpoint) |

Cooldown is per `dedupe_key` and configurable (`alert_cooldown_minutes`,
default 360); the current default lives in `config_store`.

## `ingestion_jobs`

Resumable ingest checkpoints: `kind`, `status`, `rows_written`,
`checkpoint_json` (last completed bar per market), `error`.

## `data_quality_events`

Detected anomalies: `event_type` ∈ `gap`, `duplicate`, `late_bar`,
`out_of_order`, `non_final_bar`, `cross_exchange_deviation`,
`missing_derivatives`, … with severity and `details_json`; `resolved` once the
ingestion re-run healed the hole.

## `config_store`

Runtime-tunable settings written by the Settings page (`alert_cooldown_minutes`
today). Secrets are **not** stored here — they come only from the environment.

# Crypto Risk Intelligence Platform — Nền tảng phân tích biến động và rủi ro đuôi

Hệ thống nghiên cứu có thể chạy thực tế, nạp **dữ liệu công khai thật từ sàn**, xây đặc trưng point-in-time, chạy dự báo cuốn chiếu (walk-forward) không rò rỉ và engine VaR/ES, phục vụ qua FastAPI và dashboard tối màu, responsive.

Không giao dịch, không cần API key, không đặt lệnh. Chỉ dùng endpoint dữ liệu công khai.

---

## 1. Hệ thống thực sự làm gì

1. **Khám phá (Discovery)** — thăm dò từng adapter sàn, lấy toàn bộ danh mục công cụ và dựng vũ trụ nghiên cứu từ bộ lọc thanh khoản, chênh lệch, lịch sử và chất lượng. Không hard-code BTC/ETH.
2. **Nạp dữ liệu (Ingestion)** — backfill lịch sử có thể tiếp tục, checkpoint theo thị trường, đảm bảo nến đã đóng, phát hiện trùng/lỗ hổng/lộn xộn, retry với backoff mũ và token bucket riêng từng sàn.
3. **Đặc trưng (Features)** — phương sai thực tế hằng ngày từ lợi suất 4 giờ, thành phần HAR (`rv`, `rv_w` 5 ngày, `rv_m` 22 ngày), bán phương sai, biên độ, z-score khối lượng và bối cảnh phái sinh tùy chọn.
4. **Dự báo (Forecasting)** — walk-forward, cửa sổ mở rộng, mô hình trực tiếp theo chân trời: `naive`, `har_rv` (OLS), `garch_normal`, `garch_t`, `xgb_har`, `xgb_extended` cho chân trời 1/7/30 ngày.
5. **Rủi ro đuôi (Tail risk)** — VaR/ES 1 ngày ở 95 / 97,5 / 99% với mô phỏng lịch sử, GARCH-Chuẩn, GARCH-Student-t và GARCH-EVT (POT/GPD trên phần dư chuẩn hóa), kèm kiểm định Kupiec, Christoffersen, tỷ lệ ES và tổn thất phân vị.
6. **Trạng thái & cảnh báo** — trạng thái thấp/bình thường/cao/cực đoan/dị thường từ phân vị RV trượt, và cảnh báo ngưỡng cho biến động, vượt VaR, nhảy ES, sốc giá, giãn chênh lệch, biến động funding/OI, luồng cũ và độ lệch mô hình (có cooldown riêng).
7. **Dashboard** — 8 trang gắn với API trực tiếp: Tổng quan thị trường, Bộ lọc tài sản, Chi tiết tài sản, Phòng thí nghiệm mô hình, Trung tâm rủi ro cực đoan, Giám sát sàn, Nghiên cứu & kiểm định, Cài đặt.

> **Quy ước hiển thị:** VaR 99% — mức tổn thất ước lượng trong 1 ngày. Ví dụ: **“VaR 99% — mức tổn thất ước lượng trong 1 ngày: 8,2%”** kèm giải thích: *“Trong điều kiện mô hình và dữ liệu phù hợp, mức tổn thất thực tế được kỳ vọng vượt ngưỡng này khoảng 1% số ngày. Đây là ước lượng thống kê, không phải giới hạn tổn thất tối đa.”* ES là *mức lỗ trung bình trong nhóm ngày đã vượt VaR*.

---

## 2. Kiến trúc

```
                 ┌──────────── adapter sàn ────────────┐
                 │ binance_spot · binance_futures · okx_spot · okx_swap · coinbase · kraken │
                 │ bybit_spot · bybit_linear (httpx, token bucket, retry, cờ năng lực)      │
                 └──────────────────────┬─────────────────┘
                                        │
               khám phá · nạp có tiếp tục · kiểm chất lượng · snapshot phái sinh
                                        │
                          ┌─────────────▼─────────────┐
                          │  lưu trữ (SQLAlchemy 2)   │  SQLite cục bộ,
                          │  Alembic migrations       │  PostgreSQL/TimescaleDB
                          └─────────────┬─────────────┘  qua DATABASE_URL
                                        │
             đặc trưng (RV/HAR) ──► dự báo walk-forward ──► VaR/ES walk-forward
                                        │
                     đánh giá (RMSE/MAE/QLIKE/DM) · cảnh báo · xuất Parquet
                                        │
                          ┌─────────────▼─────────────┐
                          │ FastAPI /api/v1 + WS/SSE  │──► dashboard (SPA)
                          └───────────────────────────┘
```

Các lớp mỏng, kiểm thử độc lập:

| Gói | Trách nhiệm |
|---|---|
| `backend/exchanges/` | mỗi sàn một adapter, chuẩn hóa mã, năng lực |
| `backend/data_ingestion/` | khám phá vũ trụ, nạp lịch sử + trực tiếp, chất lượng |
| `backend/features/` | RV, thành phần HAR, dựng đặc trưng point-in-time |
| `backend/quant/` | HAR, XGBoost, GARCH, walk-forward, đánh giá |
| `backend/risk/` | mô hình VaR/ES, EVT/POT, kiểm định độ bao phủ |
| `backend/services/` | read model cho API (không có SQL trong routes) |
| `backend/api/` | route FastAPI, phân trang, lỗi có cấu trúc |
| `backend/workers/` | scheduler làm mới định kỳ |
| `frontend/` | SPA ES-module không phụ thuộc, do FastAPI phục vụ |

---

## 3. Yêu cầu hệ thống

- **Python** 3.11–3.13 (khuyến nghị 3.13)
- **pip** ≥ 23
- **RAM** ≥ 2 GB cho pipeline đầy đủ; ~512 MB cho API chỉ đọc
- **Đĩa** ≥ 1 GB cho DB SQLite + Parquet
- **Hệ điều hành:** Linux / macOS / WSL2. Windows native cũng chạy được (PowerShell: thay `source` bằng `.\.venv\Scripts\Activate.ps1`).
- Không cần khóa sàn, không cần Redis/Postgres bắt buộc (SQLite mặc định).

---

## 4. Cài đặt môi trường

```bash
# 1) Tạo môi trường ảo
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .\.venv\Scripts\Activate.ps1

# 2) Cài dependencies (đã ghim phiên bản đã kiểm thử)
pip install -r requirements.txt

# 3) (Tùy chọn) tạo .env — mặc định đã chạy được
cp .env.example .env
# Chỉnh TARGET_MARKETS, DATABASE_URL, API_TOKEN nếu cần
```

**requirements chính:** `fastapi==0.150.0`, `uvicorn[standard]==0.54.0`, `SQLAlchemy==2.1.5`, `alembic==1.20.0`, `pyarrow==26.0.0`, `numpy==2.3.5`, `pandas==2.2.3`, `scipy==1.17.1`, `statsmodels==0.15.0`, `arch==8.0.0` (GARCH), `xgboost==3.4.1`, `scikit-learn==1.6.1`. Nếu `arch` thiếu, GARCH sẽ báo lỗi rõ ràng và không trả volatility giả.

---

## 5. Cấu hình (.env)

Tất cả qua `backend/core/config.py` và `.env.example`. Quan trọng:

| Biến | Mặc định | Ý nghĩa |
|---|---|---|
| `DATABASE_URL` | `sqlite:///data/risk_intel.db` | SQLite cục bộ; đổi sang `postgresql+psycopg://...` cho production |
| `TARGET_MARKETS` | `34` | số thị trường vào vũ trụ sâu |
| `BAR_TIMEFRAME` | `4h` | khung nến để dựng RV ngày |
| `INGEST_LOOKBACK_DAYS` | `760` | số ngày nhìn lại |
| `MIN_QUOTE_VOLUME_USD` | `3_000_000` | ngưỡng thanh khoản |
| `WALKFORWARD_MIN_TRAIN` | `250` | mẫu huấn luyện tối thiểu |
| `RISK_MIN_TRAIN` | `400` | mẫu tối thiểu cho VaR/ES |
| `EVT_TAIL_FRACTION` | `0.10` | tỷ lệ đuôi cho POT |
| `ALERT_*` | — | ngưỡng biến động/giá/chênh lệch + cooldown |
| `API_TOKEN` | — | nếu đặt, endpoint ghi cần `Authorization: Bearer <token>` |
| `ENABLE_BACKGROUND_JOBS` | `true` | bật scheduler nạp trực tiếp |

Không có bí mật nào được commit. Mọi khóa đều qua môi trường.

---

## 6. Khởi chạy backend & frontend

```bash
# Áp migration (lần đầu)
alembic upgrade head

# Một lệnh dựng lại tất cả từ dữ liệu thực
python -m scripts.bootstrap

# Phục vụ API + dashboard
uvicorn backend.main:app --host 0.0.0.0 --port 8000
```

Mở http://localhost:8000 cho dashboard và http://localhost:8000/api/docs cho Swagger.

`python -m scripts.bootstrap` chạy theo thứ tự:

```
khám phá → nạp → phái sinh → đặc trưng → dự báo → rủi ro → đánh giá → cảnh báo → dọn dẹp
```

và **idempotent** — chạy lại sẽ vá lỗ hổng thay vì trùng dòng. Nó in JSON tổng hợp thời gian từng bước.

Biến thể hữu ích:

```bash
python -m scripts.bootstrap --from features      # tiếp tục từ bước bất kỳ
python -m scripts.bootstrap --skip-ingest        # chỉ chạy lại mô hình
python -m scripts.cli status                     # số dòng
python -m scripts.cli forecast --markets 10      # chạy nhanh với 10 thị trường
python -m scripts.cli evaluate                   # báo cáo RMSE/MAE/QLIKE/DM
```

---

## 7. Chạy bằng Docker

```bash
docker compose up -d --build                 # API + dashboard :8000 (volume SQLite)
docker compose --profile postgres up -d      # chạy với TimescaleDB
docker compose --profile postgres run --rm api alembic upgrade head
```

SQLite dùng WAL + `busy_timeout=15000` nên nhiều reader không chặn writer. Với nhiều writer đồng thời, hãy dùng profile `postgres` hoặc hàng đợi ghi riêng — không dùng chung SQLite theo cách tranh chấp ghi.

---

## 8. Khởi tạo database

Alembic quản lý schema:

```bash
alembic upgrade head                         # áp migration
alembic revision --autogenerate -m "change"  # tạo migration mới
alembic downgrade -1
```

Revision đầu (`20261020_63fa19457724_initial_schema`) tạo 16 bảng giống `Base.metadata.create_all`; parity được kiểm bởi `tests/test_migrations_parity.py`.

---

## 9. Lấy dữ liệu lịch sử & bật cập nhật

- ** Lịch sử:** `python -m scripts.bootstrap` tự thực hiện `discover` + `ingest` với checkpoint từng thị trường, chỉ đóng nến mới được ghi, nến chưa đóng không ghi đè.
- **Trực tiếp:** `LiveIngestor` chạy REST polling 30s + WebSocket OKX/Binance (nếu bật). Trạng thái `STATE` được phát qua SSE.
- **Định kỳ:** `backend/workers/scheduler.py` chạy `alerts` 5 phút, `derivatives` 10 phút, `ingest` 1 giờ, `universe` 6 giờ, `prune` 24 giờ. Mô hình hằng ngày chỉ bật ở production.

---

## 10. Chạy hai pipeline mô hình

**Pipeline 1 — Biến động (HAR-RV + XGBoost):**
- Mục tiêu: trung bình phương sai thực tế trên chân trời, `%²/ngày`, `target_rv = 100·mean(r²_{t+1..t+h})`, cũng chấm theo biến động năm hóa.
- Mô hình: `naive`, `har_rv` (OLS trên rv/rv_w/rv_m — Corsi 2009), `garch_normal`, `garch_t`, `xgb_har`, `xgb_extended`.
- Walk-forward: cửa sổ mở rộng, tối thiểu 250 gốc, khớp lại mỗi 10 bước, ước lượng trực tiếp cho từng chân trời, cửa sổ kiểm tra cuối cùng không bị chạm.

**Pipeline 2 — Rủi ro đuôi (GARCH + EVT):**
- Lịch sử, GARCH-Chuẩn, GARCH-Student-t, GARCH-EVT (lọc GARCH rồi POT/GPD trên phần dư chuẩn hóa; ngưỡng chọn theo phân vị, ≥25 exceedances; ES chỉ báo khi ξ < 1).
- Kiểm định: Kupiec POF, Christoffersen độc lập + có điều kiện, tỷ lệ ES, tổn thất phân vị.

Chạy thủ công:

```bash
python -m scripts.cli forecast --markets 34
python -m scripts.cli risk --markets 34
python -m scripts.cli evaluate
```

---

## 11. Chạy kiểm thử & xem log

```bash
pytest -q                     # 88 test = 85 unit + 3 integration
pytest -m integration -q      # chỉ test cần DB nghiên cứu
pytest tests/test_formulas.py -k garch -q  # riêng GARCH (cần arch)

# Log
tail -f logs/api.log logs/ingest.log logs/forecast.log
cat logs/bootstrap.log
```

**SSE kiểm thử:** `test_stream_endpoint_is_event_stream` kiểm tra dòng đầu `retry:`/`event:` nhận trong thời gian hữu hạn; các test heartbeat/disconnect bổ sung kiểm tra heartbeat 20s và dọn subscriber khi ngắt.

**GARCH kiểm thử:** 3 test `test_garch_*` kiểm tra tính dừng (`alpha+beta<1`), hội tụ, đơn vị dự báo và dự báo nhiều bước. Khi thiếu `arch`, test báo lỗi rõ ràng thay vì trả volatility giả.

---

## 12. Xử lý lỗi thường gặp

| Lỗi | Nguyên nhân | Cách khắc phục |
|---|---|---|
| `ModuleNotFoundError: No module named 'arch'` | Chưa cài `arch==8.0.0` | `pip install -r requirements.txt` hoặc `pip install arch==8.0.0`; kiểm tra Dockerfile có `RUN pip install -r requirements.txt` |
| `database is locked` (SQLite) | Nhiều writer cùng lúc | Dùng `DATABASE_URL` Postgres hoặc chạy worker riêng (`--profile worker`); đã bật WAL + busy_timeout 15s |
| `API unreachable` ở topbar | Backend chưa chạy | `uvicorn backend.main:app --port 8000` hoặc `docker compose up` |
| `Blocked in this environment` | Sàn chặn IP CI | Báo là `blocked`, không lấp số giả; thử lại ở mạng khác |
| `insufficient_history` trong Asset Detail | Thị trường mới, thiếu nến | Chờ ingest đủ 320 ngày hoặc giảm `MIN_HISTORY_DAYS` |
| `gpd_fit_failed` | Quá ít exceedances cho EVT | Tăng `EVT_TAIL_FRACTION` hoặc giảm `EVT_MIN_EXCEEDANCES`; kiểm tra `mean_excess_curve` |
| Frontend trắng khi API lỗi | Lỗi request không xử lý | Đã có `errorView` + nút Thử lại; xem Console (F12) và `logs/api.log` |

---

## 13. Danh sách endpoint

Base `/api/v1`, OpenAPI `/api/docs`.

| Endpoint | Mục đích |
|---|---|
| `GET /health` | liveness + DB readiness |
| `GET /system/status` | scheduler, độ mới, lịch sử chạy, số dòng |
| `GET /exchanges` | adapter, năng lực, trạng thái (sàn bị chặn báo rõ) |
| `GET /data-quality` | lỗ hổng, trùng, feed cũ, lệch liên sàn |
| `GET /overview` | thẻ tổng quan |
| `GET /markets` | bảng sàng lọc phân trang (`exchange`, `quote`, `sort`, `limit`, `offset`) |
| `GET /markets/{exchange}/{symbol}` | chi tiết thị trường |
| `GET /markets/{exchange}/{symbol}/ohlcv` | nến (`timeframe`, `limit`) |
| `GET /markets/{exchange}/{symbol}/series` | chuỗi giá + RV + trạng thái |
| `GET /markets/{exchange}/{symbol}/features` | dòng đặc trưng mới nhất |
| `GET /markets/{exchange}/{symbol}/forecasts` | lịch sử dự báo theo mô hình/chân trời |
| `GET /markets/{exchange}/{symbol}/risk` | lịch sử VaR/ES + chẩn đoán |
| `GET /markets/{exchange}/{symbol}/comparison` | so sánh liên sàn |
| `GET /forecasts` | bảng dự báo toàn cục |
| `GET /models` | danh mục mô hình + metadata lần chạy |
| `GET /risk/var-es`, `/risk/overview`, `/risk/backtests` | bảng rủi ro đuôi |
| `GET /backtests` | chỉ số đánh giá (RMSE/MAE/QLIKE/DM) |
| `GET /alerts` | cảnh báo có bộ lọc; `POST /alerts/{id}/ack` |
| `GET /settings`, `PUT /settings` | ngưỡng runtime (bảo vệ bằng token) |
| `POST /admin/run/{task}` | kích hoạt tác vụ pipeline (bảo vệ token) |
| `GET /stream` | SSE luồng ticker trực tiếp |

Lỗi có cấu trúc `{"error": {"code", "message", "detail"}}` và nguồn lỗi trả `unavailable` — không bao giờ bịa số.

---

## 14. Cách đọc các chỉ số

- **RV (Realized Variance):** `%²/ngày`, tổng bình phương lợi suất trong ngày (`rv`). **Biến động năm hóa** = `sqrt(RV*365)/100` (dạng fraction, hiển thị %).
- **HAR-RV:** `rv_{t+1}=b0 + b_d·rv_t + b_w·mean(rv_{t-4..t}) + b_m·mean(rv_{t-21..t})`. Hệ số OLS, không rò rỉ.
- **GARCH(1,1):** `σ²_t = ω + α·ε²_{t-1} + β·σ²_{t-1}`. Yêu cầu `α+β<1` (stationarity) và hội tụ; dự báo nhiều bước là trung bình phương sai có điều kiện.
- **VaR 99%:** tổn thất dương, ví dụ 8,2% nghĩa là kỳ vọng vượt 1% số ngày. **ES 99%:** trung bình lỗ trong nhóm ngày đã vượt VaR. ES chỉ báo khi `ξ<1`.
- **QLIKE:** `QLIKE = y/ŷ - ln(y/ŷ) -1`; trung bình nhạy với ngoại lệ gần 0, trung vị bền vững hơn — đọc cả hai.
- **Diebold-Mariano:** thống kê âm nghĩa là mô hình thách thức tốt hơn baseline; p<0.05 mới đáng kể.
- **Kupiec POF:** kiểm bao phủ vô điều kiện; **Christoffersen:** thêm tính độc lập. Mẫu nhỏ (n<300) năng lực thấp — không kết luận “mô hình tốt” chỉ vì không bị bác bỏ.

---

## 15. Giới hạn mô hình & dữ liệu

Đọc `docs/limitations.md` trước khi trích bất kỳ con số nào. Tóm tắt:

- Một số sàn có thể bị chặn trong môi trường CI — báo `blocked`, không lấp số giả.
- Frontend gốc yêu cầu Next.js/React; bản giao là SPA không build — sai lệch ghi trong `limitations.md`.
- EVT mẫu nhỏ cho ước lượng phương sai lớn; xem đường cong mean-excess và bảng nhạy ngưỡng.
- Dữ liệu thanh lý chưa có — OI/funding hiển thị “không có” khi thiếu.
- Backtest không chứng minh mô hình đủ tốt; luôn đọc kèm `n_obs`, p-value, tỷ lệ vượt.

---

## 16. Hiệu năng (đo thực tế)

Môi trường đo: laptop Linux, SQLite WAL, 34 thị trường model-eligible, 123k nến, 61k dự báo.

| Endpoint | p50 | p95 | Ghi chú |
|---|---|---|---|
| `GET /health` | ~4 ms | ~48 ms | ping DB |
| `GET /system/status` | ~20 ms | ~32 ms | 7 bảng count + freshness |
| `GET /overview` | ~79 ms | ~305 ms | 4 truy vấn nặng có cache 30s |
| `GET /markets?page=1&page_size=20` | ~110 ms | ~239 ms | 3,194 thị trường + enrich |
| `GET /markets/binance_spot/BTCUSDT` | ~6 ms | ~10 ms | chi tiết 1 thị trường |
| `GET /risk/var-es` | ~6 ms | ~10 ms | VaR/ES mới nhất |
| `GET /backtests` | ~73 ms | ~167 ms | metrics + DM |

Tối ưu đã áp dụng: TTL cache 20–30s cho `universe_metrics`, `latest_forecasts`, `latest_var_es`; truy vấn batch; index `ix_ohlcv_lookup`, `ix_features_lookup`; không refit mô hình trên event loop; scheduler tách khỏi API; phân trang; giới hạn 400 điểm/biểu đồ; debounce tìm kiếm 350 ms; hủy subscription khi chuyển trang; hủy request cũ khi lọc mới.

SSE khi idle: heartbeat 20s, không busy polling (`asyncio.wait_for` + timeout), CPU ~0% khi không có tick.

---

## 17. Giấy phép & miễn trừ

Đây là hệ thống nghiên cứu mô phỏng, không phải khuyến nghị đầu tư. Mọi dự báo và VaR/ES là ước lượng thống kê có sai số mô hình — không phải giới hạn tổn thất tối đa.


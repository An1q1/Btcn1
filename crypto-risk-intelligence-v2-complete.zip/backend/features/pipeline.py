"""Feature Service: builds daily RV/HAR features from stored intraday bars."""
from __future__ import annotations

import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import delete, func, select, text

from backend.core.config import effective_settings
from backend.core.db import chunked, dumps, get_engine, session_scope, upsert_rows
from backend.core.logging import get_logger
from backend.core.models import EngineeredFeature, Market, OHLCV, RealizedTarget
from backend.data_ingestion.universe import expected_bars_per_day, target_timeframe_for
from backend.exchanges.symbols import timeframe_to_ms
from backend.features.rv import (
    EXTENDED_FEATURES,
    HAR_BASE_FEATURES,
    annualized_vol_from_rv,
    build_daily_features,
    make_target,
)

log = get_logger("features")


def load_ohlcv(exchange: str, symbol: str, timeframe: str) -> pd.DataFrame:
    q = text(
        "SELECT ts, open, high, low, close, volume, quote_volume FROM ohlcv "
        "WHERE exchange_code=:e AND symbol=:s AND timeframe=:t ORDER BY ts"
    )
    with get_engine().connect() as conn:
        df = pd.read_sql_query(q, conn, params={"e": exchange, "s": symbol, "t": timeframe})
    return df


def pick_btc_reference() -> tuple[str, str, str] | None:
    with session_scope() as ses:
        row = ses.execute(
            select(Market.exchange_code, Market.symbol)
            .where(Market.base_asset == "BTC", Market.quote_asset.in_(["USDT", "USD"]), Market.in_universe.is_(True))
            .order_by(Market.quote_volume_24h.desc())
        ).first()
    if not row:
        return None
    ex, sym = row
    return ex, sym, target_timeframe_for(ex)


def _latest_derivative_context() -> dict[tuple[str, str], dict[str, Any]]:
    from backend.core.models import DerivativeMetric

    out: dict[tuple[str, str], dict[str, Any]] = {}
    with session_scope() as ses:
        rows = ses.execute(
            select(DerivativeMetric).order_by(DerivativeMetric.ts.desc()).limit(500)
        ).scalars()
        for r in rows:
            key = (r.exchange_code, r.symbol)
            if key in out:
                continue
            out[key] = {
                "funding_rate": r.funding_rate,
                "open_interest": r.open_interest,
                "mark_price": r.mark_price,
                "index_price": r.index_price,
                "basis": r.basis,
            }
    return out


def build_all_features(force: bool = False, markets: int | None = None) -> dict[str, Any]:
    s = effective_settings()
    t0 = time.perf_counter()
    ref = pick_btc_reference()
    btc_rv_by_day: pd.Series | None = None
    if ref:
        ex, sym, tf = ref
        btc_daily = build_daily_features(load_ohlcv(ex, sym, tf), expected_bars_per_day(tf))
        if not btc_daily.empty:
            btc_rv_by_day = btc_daily.set_index("bar_date")["rv"]
            log.info(f"BTC RV reference: {ex}/{sym} ({len(btc_daily)} days)")

    with session_scope() as ses:
        mkts = (
            ses.execute(
                select(Market).where(Market.in_universe.is_(True)).order_by(Market.quote_volume_24h.desc())
            ).scalars().all()
        )
        targets = [
            (m.exchange_code, m.symbol, m.base_asset, m.quote_asset, m.market_type)
            for m in mkts
        ][: markets or s.model_market_limit]
    deriv_ctx = _latest_derivative_context()

    built = 0
    skipped: list[dict[str, str]] = []
    for ex, sym, base, quote, mtype in targets:
        tf = target_timeframe_for(ex, s.bar_timeframe)
        raw = load_ohlcv(ex, sym, tf)
        if raw.empty or len(raw) < 100:
            skipped.append({"market": f"{ex}:{sym}", "reason": "insufficient_ohlcv"})
            continue
        bars_per_day = expected_bars_per_day(tf)
        daily = build_daily_features(raw, bars_per_day, None if base == "BTC" else btc_rv_by_day)
        if daily.empty:
            skipped.append({"market": f"{ex}:{sym}", "reason": "no_complete_days"})
            continue
        # Only complete days may be used as forecast origins; the first day has
        # no previous close and therefore no daily return.
        daily = daily[(daily["completeness"] >= 0.8) & daily["ret_pct"].notna()].reset_index(drop=True)
        row_template = daily.to_dict("records")
        feat_rows: list[dict[str, Any]] = []
        deriv = deriv_ctx.get((ex, sym), {})
        for r in row_template:
            fjson = {k: (None if pd.isna(r.get(k)) else float(r[k])) for k in EXTENDED_FEATURES}
            feat_rows.append(
                {
                    "exchange_code": ex,
                    "symbol": sym,
                    "bar_date": r["bar_date"],
                    "close": float(r["close"]),
                    "ret_pct": float(r["ret_pct"]) if pd.notna(r["ret_pct"]) else np.nan,
                    "rv": float(r["rv"]),
                    "rv_w": _f(r.get("rv_w")),
                    "rv_m": _f(r.get("rv_m")),
                    "semivar_neg": _f(r.get("semivar_neg")),
                    "semivar_pos": _f(r.get("semivar_pos")),
                    "range_pct": _f(r.get("range_pct")),
                    "volume": _f(r.get("volume")),
                    "quote_volume": _f(r.get("quote_volume")),
                    "volume_z": _f(r.get("volume_z")),
                    "funding_rate": deriv.get("funding_rate"),
                    "open_interest": deriv.get("open_interest"),
                    "oi_change_7d": None,
                    "spread_bps": None,
                    "cross_btc_rv": _f(r.get("cross_btc_rv")),
                    "n_bars": int(r["n_bars"]),
                    "completeness": _f(r.get("completeness")),
                    "features_json": dumps({**fjson, "jump": _f(r.get("jump")), "rv_ann_vol_pct": _f(r.get("rv_ann_vol_pct"))}),
                    "computed_at": datetime.now(timezone.utc),
                }
            )
        with session_scope() as ses:
            ses.execute(
                delete(EngineeredFeature).where(
                    EngineeredFeature.exchange_code == ex, EngineeredFeature.symbol == sym
                )
            )
            for part in chunked(feat_rows, 500):
                upsert_rows(ses, EngineeredFeature.__table__, part, ["exchange_code", "symbol", "bar_date"])
            # realized targets for each horizon
            target_rows = []
            rv_series = daily.set_index("bar_date")["rv"]
            for h in s.horizon_list:
                tgt = make_target(rv_series, h, "mean")
                for day, val in tgt.items():
                    if pd.isna(val):
                        continue
                    target_rows.append(
                        {
                            "exchange_code": ex,
                            "symbol": sym,
                            "bar_date": day,
                            "horizon": h,
                            "target_rv": float(val),
                            "target_vol_annualized": float(annualized_vol_from_rv(val)),
                            "realized_at": datetime.now(timezone.utc),
                        }
                    )
            for part in chunked(target_rows, 500):
                upsert_rows(
                    ses, RealizedTarget.__table__, part, ["exchange_code", "symbol", "bar_date", "horizon"]
                )
        built += 1
        if built % 5 == 0:
            log.info(f"features built for {built} markets")

    # daily close column on markets (used by screener)
    with session_scope() as ses:
        for m in ses.execute(select(Market).where(Market.in_universe.is_(True))).scalars():
            last = ses.execute(
                select(EngineeredFeature.close)
                .where(EngineeredFeature.exchange_code == m.exchange_code, EngineeredFeature.symbol == m.symbol)
                .order_by(EngineeredFeature.bar_date.desc())
                .limit(1)
            ).scalar()
            if last:
                m.last_price = float(last)
    elapsed = time.perf_counter() - t0
    log.info(f"feature build finished in {elapsed:.1f}s")
    return {
        "markets_built": built,
        "skipped": skipped,
        "elapsed_seconds": round(elapsed, 1),
        "horizons": s.horizon_list,
    }


def _f(v: Any) -> float | None:
    try:
        if v is None or (isinstance(v, float) and not np.isfinite(v)):
            return None
        f = float(v)
        return f if np.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def load_feature_frame(exchange: str, symbol: str) -> pd.DataFrame:
    with session_scope() as ses:
        rows = ses.execute(
            select(EngineeredFeature)
            .where(EngineeredFeature.exchange_code == exchange, EngineeredFeature.symbol == symbol)
            .order_by(EngineeredFeature.bar_date)
        ).scalars().all()
    import json

    records = []
    for r in rows:
        extras = json.loads(r.features_json) if r.features_json else {}
        rec = {
            "bar_date": r.bar_date,
            "close": r.close,
            "ret_pct": r.ret_pct,
            "rv": r.rv,
            "rv_w": r.rv_w,
            "rv_m": r.rv_m,
            "semivar_neg": r.semivar_neg,
            "semivar_pos": r.semivar_pos,
            "range_pct": r.range_pct,
            "volume": r.volume,
            "quote_volume": r.quote_volume,
            "volume_z": r.volume_z,
            "funding_rate": r.funding_rate,
            "open_interest": r.open_interest,
            "cross_btc_rv": r.cross_btc_rv,
            "n_bars": r.n_bars,
            "completeness": r.completeness,
        }
        for k in ("jump", "semivar_neg_ratio", "jump_ratio", "rv_ratio", "ret_5", "ret_abs_5", "rv_ann_vol_pct"):
            rec[k] = extras.get(k)
        records.append(rec)
    df = pd.DataFrame(records)
    if not df.empty:
        df = df.sort_values("bar_date").reset_index(drop=True)
    return df


def export_parquet() -> dict[str, Any]:
    s = effective_settings()
    out_dir = Path(s.parquet_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    with session_scope() as ses:
        markets = ses.execute(select(Market).where(Market.in_universe.is_(True))).scalars().all()
    written = []
    for m in markets:
        df = load_feature_frame(m.exchange_code, m.symbol)
        if df.empty:
            continue
        path = out_dir / f"{m.exchange_code}_{m.symbol.replace('/', '_')}_daily.parquet"
        df.to_parquet(path, index=False)
        written.append(str(path))
    return {"files": len(written), "dir": str(out_dir)}


def feature_summary() -> dict[str, Any]:
    with session_scope() as ses:
        n = ses.execute(select(func.count()).select_from(EngineeredFeature)).scalar_one()
        markets = ses.execute(
            select(EngineeredFeature.exchange_code, EngineeredFeature.symbol, func.count(), func.min(EngineeredFeature.bar_date), func.max(EngineeredFeature.bar_date))
            .group_by(EngineeredFeature.exchange_code, EngineeredFeature.symbol)
        ).all()
    return {
        "rows": int(n),
        "markets": [
            {"exchange": e, "symbol": s, "days": int(c), "start": mn, "end": mx} for e, s, c, mn, mx in markets
        ],
    }

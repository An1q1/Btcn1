"""Realized-variance feature engineering (pure, testable functions).

Conventions (used consistently across features, models, targets and evaluation):
- Returns are in percent: r_t = 100 * ln(P_t / P_{t-1}).
- Realized variance RV_t = sum_j r_{t,j}^2 over intraday bars of UTC day t,
  so RV is expressed in "percent-squared per day".
- Realized volatility (daily, %) = sqrt(RV_t); annualized vol (%) = sqrt(365*RV_t).
- A day is a UTC calendar day (crypto trades 24/7); "5-day"/"22-day" windows are
  observation counts, not trading-day calendars.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

EPS_RV = 1e-10


def log_returns_pct(prices: np.ndarray | pd.Series) -> np.ndarray:
    p = np.asarray(prices, dtype=float)
    out = np.full(p.shape, np.nan)
    if p.size > 1:
        with np.errstate(divide="ignore", invalid="ignore"):
            out[1:] = 100.0 * np.log(p[1:] / p[:-1])
    return out


def realized_variance(intraday_returns: np.ndarray) -> float:
    r = np.asarray(intraday_returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size == 0:
        return float("nan")
    return float(np.sum(r**2))


def realized_semivariance(intraday_returns: np.ndarray) -> tuple[float, float]:
    r = np.asarray(intraday_returns, dtype=float)
    r = r[np.isfinite(r)]
    return float(np.sum(r[r < 0] ** 2)), float(np.sum(r[r > 0] ** 2))


def bipower_variation(intraday_returns: np.ndarray) -> float:
    r = np.asarray(intraday_returns, dtype=float)
    r = r[np.isfinite(r)]
    if r.size < 2:
        return float("nan")
    return float((np.pi / 2.0) * np.sum(np.abs(r[1:]) * np.abs(r[:-1])))


def build_daily_features(df: pd.DataFrame, bars_per_day: int, btc_rv: pd.Series | None = None) -> pd.DataFrame:
    """Aggregate intraday OHLCV into UTC-daily features.

    Required columns: ts (epoch ms, bar open), open, high, low, close, volume.
    Optional: quote_volume.
    """
    if df.empty:
        return pd.DataFrame()
    d = df.copy()
    d["ts"] = pd.to_datetime(d["ts"], unit="ms", utc=True)
    d = d.sort_values("ts").drop_duplicates("ts")
    d["bar_ret"] = log_returns_pct(d["close"].to_numpy())
    if "quote_volume" not in d.columns:
        d["quote_volume"] = np.nan
    d["quote_volume"] = pd.to_numeric(d["quote_volume"], errors="coerce")
    d["day"] = d["ts"].dt.strftime("%Y-%m-%d")

    rows: list[dict] = []
    for day, g in d.groupby("day", sort=True):
        if g.shape[0] < max(2, int(bars_per_day * 0.5)):
            continue
        rets = g["bar_ret"].to_numpy()
        rv = realized_variance(rets)
        sv_neg, sv_pos = realized_semivariance(rets)
        bv = bipower_variation(rets)
        close = float(g["close"].iloc[-1])
        vol = float(g["volume"].sum())
        qv = g["quote_volume"].sum(min_count=1)
        qv = float(qv) if pd.notna(qv) else vol * close
        rows.append(
            {
                "bar_date": day,
                "close": close,
                "high": float(g["high"].max()),
                "low": float(g["low"].min()),
                "open": float(g["open"].iloc[0]),
                "volume": vol,
                "quote_volume": qv,
                "rv": rv,
                "semivar_neg": sv_neg,
                "semivar_pos": sv_pos,
                "bipower": bv,
                "jump": max(0.0, rv - bv) if np.isfinite(bv) else np.nan,
                "n_bars": int(g.shape[0]),
                "last_bar_ts": int(g["ts"].iloc[-1].timestamp() * 1000),
            }
        )
    if not rows:
        return pd.DataFrame()
    daily = pd.DataFrame(rows).set_index("bar_date").sort_index()
    daily["completeness"] = (daily["n_bars"] / bars_per_day).clip(upper=1.0)
    daily["ret_pct"] = log_returns_pct(daily["close"].to_numpy())
    daily["range_pct"] = 100.0 * np.log(daily["high"] / daily["low"])
    daily["rv"] = daily["rv"].clip(lower=EPS_RV)
    daily["rv_w"] = daily["rv"].rolling(5, min_periods=5).mean()
    daily["rv_m"] = daily["rv"].rolling(22, min_periods=22).mean()
    daily["semivar_neg_ratio"] = daily["semivar_neg"] / daily["rv"]
    daily["ret_5"] = 100.0 * np.log(daily["close"] / daily["close"].shift(5))
    daily["ret_abs_5"] = daily["ret_pct"].abs().rolling(5, min_periods=5).mean()
    daily["rv_ratio"] = daily["rv_w"] / daily["rv_m"]
    daily["jump_ratio"] = daily["jump"] / daily["rv"]
    vol_mean = daily["volume"].rolling(22, min_periods=10).mean().shift(1)
    vol_std = daily["volume"].rolling(22, min_periods=10).std().shift(1)
    daily["volume_z"] = (daily["volume"] - vol_mean) / vol_std.replace(0, np.nan)
    daily["rv_ann_vol_pct"] = np.sqrt(daily["rv"] * 365.0)
    if btc_rv is not None and len(btc_rv):
        daily["cross_btc_rv"] = daily.index.map(lambda x: float(btc_rv.get(x, np.nan)))
    else:
        daily["cross_btc_rv"] = np.nan
    return daily.reset_index()


HAR_BASE_FEATURES = ["rv", "rv_w", "rv_m"]
EXTENDED_FEATURES = [
    "rv", "rv_w", "rv_m",
    "ret_pct", "ret_5", "ret_abs_5", "range_pct",
    "semivar_neg_ratio", "jump_ratio", "rv_ratio", "volume_z", "cross_btc_rv",
]


def make_target(rv: pd.Series, horizon: int, mode: str = "mean") -> pd.Series:
    """Target realized variance for horizon h.

    mode='mean': average daily RV over (t+1 .. t+h)  [default, used for all models]
    mode='sum' : sum of daily RV over the same window (reported for reference)
    """
    rv = rv.astype(float)
    fwd = rv.shift(-1).rolling(horizon, min_periods=horizon).mean().shift(-(horizon - 1)) if mode == "mean" else None
    if mode == "sum":
        fwd = rv.shift(-1).rolling(horizon, min_periods=horizon).sum().shift(-(horizon - 1))
    assert fwd is not None
    return fwd


def annualized_vol_from_rv(rv_pct2: float | np.ndarray) -> float | np.ndarray:
    return np.sqrt(np.asarray(rv_pct2) * 365.0)

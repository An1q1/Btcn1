"""Retention & archival maintenance.

Two jobs live here:

``prune_forecast_history``
    The forecast log is append-only *by design*: rows are never updated, and a
    re-run writes a new ``run_id``. To keep the research database small enough
    to move around, history older than ``retain_origins`` origins per
    (market, model, horizon) is exported to a compressed Parquet archive and
    then removed from SQLite. Superseded duplicate rows (same market/model/
    horizon/origin, older ``forecast_ts``) are handled the same way.

``vacuum``
    Reclaim space after a prune.

Everything is deterministic and re-runnable; the archive path is printed so the
dataset can be reconstructed or extended later.
"""
from __future__ import annotations

import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from backend.core.config import effective_settings
from backend.core.logging import get_logger

log = get_logger("maintenance")

FORECAST_COLUMNS = [
    "id", "exchange_code", "symbol", "model_name", "model_version", "horizon", "bar_date",
    "forecast_ts", "data_cutoff_ts", "target_start_date", "target_end_date",
    "predicted_rv", "predicted_vol_annualized", "actual_rv", "config_json",
    "data_quality", "run_id",
]


def _connect() -> sqlite3.Connection:
    path = effective_settings().database_url.replace("sqlite:///", "")
    con = sqlite3.connect(path)
    con.row_factory = sqlite3.Row
    return con


def prune_forecast_history(retain_origins: int = 150, archive: bool = True) -> dict[str, Any]:
    s = effective_settings()
    con = _connect()
    try:
        keep_sql = """
            SELECT id FROM forecasts f
            WHERE f.bar_date IN (
                SELECT bar_date FROM (
                    SELECT DISTINCT bar_date FROM forecasts g
                    WHERE g.exchange_code = f.exchange_code AND g.symbol = f.symbol
                      AND g.model_name = f.model_name AND g.horizon = f.horizon
                    ORDER BY bar_date DESC LIMIT :keep
                )
            )
        """
        keep_ids = {r[0] for r in con.execute(keep_sql, {"keep": retain_origins})}
        all_ids = {r[0] for r in con.execute("SELECT id FROM forecasts")}
        drop_ids = all_ids - keep_ids
        if not drop_ids:
            return {"status": "nothing_to_prune", "kept": len(keep_ids), "removed": 0}

        rows = con.execute(
            f"SELECT {', '.join(FORECAST_COLUMNS)} FROM forecasts WHERE id NOT IN "
            f"(SELECT value FROM json_each(:ids))",
            {"ids": "[" + ",".join(str(i) for i in drop_ids) + "]"},
        ).fetchall() if len(drop_ids) < 900_000 else []

        archive_path = None
        if archive and rows:
            out_dir = Path(s.parquet_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            archive_path = out_dir / f"forecast_archive_{stamp}.parquet"
            frame = pd.DataFrame([dict(r) for r in rows])
            frame.to_parquet(archive_path, compression="zstd", index=False)
            log.info(f"archived {len(frame)} forecast rows to {archive_path}")

        con.executemany("DELETE FROM forecasts WHERE id = ?", [(i,) for i in drop_ids])
        con.commit()
    finally:
        con.close()
    return {
        "status": "ok",
        "kept": len(keep_ids),
        "removed": len(drop_ids),
        "retain_origins": retain_origins,
        "archive": str(archive_path) if archive_path else None,
    }


def prune_duplicate_forecasts(archive: bool = True) -> dict[str, Any]:
    """Keep only the newest row for each (market, model, horizon, origin)."""
    s = effective_settings()
    con = _connect()
    try:
        dup_sql = """
            SELECT id FROM forecasts f
            WHERE EXISTS (
                SELECT 1 FROM forecasts g
                WHERE g.exchange_code = f.exchange_code AND g.symbol = f.symbol
                  AND g.model_name = f.model_name AND g.horizon = f.horizon
                  AND g.bar_date = f.bar_date
                  AND (g.forecast_ts > f.forecast_ts
                       OR (g.forecast_ts = f.forecast_ts AND g.id > f.id))
            )
        """
        ids = [r[0] for r in con.execute(dup_sql)]
        if not ids:
            return {"status": "nothing_to_prune", "removed": 0}
        rows = con.execute(
            f"SELECT {', '.join(FORECAST_COLUMNS)} FROM forecasts WHERE id IN ("
            + ",".join(str(i) for i in ids) + ")"
        ).fetchall()
        archive_path = None
        if archive and rows:
            out_dir = Path(s.parquet_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            archive_path = out_dir / f"forecast_superseded_{stamp}.parquet"
            pd.DataFrame([dict(r) for r in rows]).to_parquet(
                archive_path, compression="zstd", index=False
            )
        con.executemany("DELETE FROM forecasts WHERE id = ?", [(i,) for i in ids])
        con.commit()
    finally:
        con.close()
    return {"status": "ok", "removed": len(ids), "archive": str(archive_path) if archive_path else None}


def vacuum() -> dict[str, Any]:
    path = effective_settings().database_url.replace("sqlite:///", "")
    before = Path(path).stat().st_size if Path(path).exists() else 0
    con = _connect()
    try:
        con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        con.execute("VACUUM")
    finally:
        con.close()
    after = Path(path).stat().st_size if Path(path).exists() else 0
    return {"before_mb": round(before / 1e6, 1), "after_mb": round(after / 1e6, 1)}


VAR_COLUMNS = [
    "id", "exchange_code", "symbol", "asof_date", "model_name", "confidence", "horizon_days",
    "var_pct", "es_pct", "mu", "sigma", "threshold", "xi", "beta", "n_exceedances",
    "method_meta", "actual_loss_pct", "breach", "created_at",
]


def prune_var_history(retain_origins: int = 150, archive: bool = True) -> dict[str, Any]:
    """Same retention contract as forecasts, applied to VaR/ES estimates."""
    s = effective_settings()
    con = _connect()
    try:
        keep_sql = """
            SELECT id FROM var_es_estimates v
            WHERE v.asof_date IN (
                SELECT asof_date FROM (
                    SELECT DISTINCT asof_date FROM var_es_estimates g
                    WHERE g.exchange_code = v.exchange_code AND g.symbol = v.symbol
                      AND g.model_name = v.model_name AND g.confidence = v.confidence
                    ORDER BY asof_date DESC LIMIT :keep
                )
            )
        """
        keep_ids = {r[0] for r in con.execute(keep_sql, {"keep": retain_origins})}
        all_ids = {r[0] for r in con.execute("SELECT id FROM var_es_estimates")}
        drop_ids = all_ids - keep_ids
        if not drop_ids:
            return {"status": "nothing_to_prune", "kept": len(keep_ids), "removed": 0}
        rows = con.execute(
            f"SELECT {', '.join(VAR_COLUMNS)} FROM var_es_estimates WHERE id IN ("
            + ",".join(str(i) for i in drop_ids) + ")"
        ).fetchall()
        archive_path = None
        if archive and rows:
            out_dir = Path(s.parquet_dir)
            out_dir.mkdir(parents=True, exist_ok=True)
            stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
            archive_path = out_dir / f"var_archive_{stamp}.parquet"
            pd.DataFrame([dict(r) for r in rows]).to_parquet(
                archive_path, compression="zstd", index=False
            )
        con.executemany("DELETE FROM var_es_estimates WHERE id = ?", [(i,) for i in drop_ids])
        con.commit()
    finally:
        con.close()
    return {
        "status": "ok",
        "kept": len(keep_ids),
        "removed": len(drop_ids),
        "retain_origins": retain_origins,
        "archive": str(archive_path) if archive_path else None,
    }

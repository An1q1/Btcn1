"""Data-quality checks.

Rules are explicit and conservative: a 30% price move is treated as a genuine
market event and only flagged for review; it is never silently deleted. Only
records that are structurally invalid (duplicates, non-positive prices,
impossible OHLC relations) are dropped before persistence.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable

import numpy as np

from backend.exchanges.base import Candle
from backend.exchanges.symbols import timeframe_to_ms


@dataclass
class QualityReport:
    issues: list[dict[str, Any]] = field(default_factory=list)
    dropped: int = 0
    duplicates: int = 0
    gaps: int = 0
    max_gap_bars: int = 0
    cleaned: list[Candle] = field(default_factory=list)

    def add(self, event_type: str, severity: str, **details: Any) -> None:
        self.issues.append(
            {
                "event_type": event_type,
                "severity": severity,
                "details": details,
                "ts": datetime.now(timezone.utc).isoformat(),
            }
        )

    @property
    def ok(self) -> bool:
        return not any(i["severity"] == "critical" for i in self.issues)


def clean_candles(candles: Iterable[Candle], timeframe: str) -> QualityReport:
    tf_ms = timeframe_to_ms(timeframe)
    report = QualityReport()
    by_ts: dict[int, Candle] = {}
    for c in candles:
        if c.ts in by_ts:
            report.duplicates += 1
            continue
        if not all(np.isfinite([c.open, c.high, c.low, c.close, c.volume])):
            report.dropped += 1
            continue
        if min(c.open, c.high, c.low, c.close) <= 0 or c.volume < 0:
            report.dropped += 1
            continue
        if c.high < max(c.open, c.close) - 1e-12 or c.low > min(c.open, c.close) + 1e-12 or c.high < c.low:
            report.dropped += 1
            continue
        by_ts[c.ts] = c
    ordered = [by_ts[k] for k in sorted(by_ts)]
    # gap detection (missing bars)
    for prev, cur in zip(ordered, ordered[1:]):
        delta = cur.ts - prev.ts
        if delta > tf_ms:
            missing = int(delta // tf_ms) - 1
            report.gaps += missing
            report.max_gap_bars = max(report.max_gap_bars, missing)
    if report.duplicates:
        report.add("duplicate_records", "warning", count=report.duplicates)
    if report.dropped:
        report.add("invalid_ohlcv", "critical", count=report.dropped)
    if report.gaps:
        report.add(
            "missing_candles",
            "warning" if report.gaps < len(ordered) * 0.05 else "critical",
            missing=report.gaps,
            max_gap_bars=report.max_gap_bars,
        )
    returns = np.array([np.log(c.close / ordered[i - 1].close) for i, c in enumerate(ordered) if i > 0])
    if returns.size:
        jumps = np.abs(returns) > 0.5
        if jumps.any():
            report.add("large_moves_review", "info", count=int(jumps.sum()),
                       note="kept in dataset; genuine shocks are not removed")
        if (np.abs(returns) > 5).any():  # > 500% bar move -> almost certainly a data error
            report.add("implausible_return", "critical", count=int((np.abs(returns) > 5).sum()))
    vols = np.array([c.volume for c in ordered])
    if vols.size > 30:
        med = float(np.median(vols[-200:]))
        if med > 0:
            spiky = int((vols[-200:] > med * 50).sum())
            if spiky:
                report.add("volume_spike", "info", count=spiky, median_volume=med)
    report.cleaned = ordered
    return report


def cross_exchange_deviation(prices: dict[str, float]) -> dict[str, Any]:
    """prices: canonical-symbol -> latest price for the same base/quote pair."""
    vals = [p for p in prices.values() if p and p > 0]
    if len(vals) < 2:
        return {"ok": True, "max_deviation_pct": 0.0}
    med = float(np.median(vals))
    devs = {k: (v / med - 1) * 100 for k, v in prices.items() if v and v > 0}
    worst = max(devs.items(), key=lambda kv: abs(kv[1]))
    return {
        "ok": abs(worst[1]) < 2.0,
        "max_deviation_pct": round(float(worst[1]), 4),
        "worst_market": worst[0],
    }

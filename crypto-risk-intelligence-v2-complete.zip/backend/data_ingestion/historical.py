"""Historical ingestion with pagination, checkpoints, idempotent writes and DQ."""
from __future__ import annotations

import asyncio
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import func, select

from backend.core.config import effective_settings
from backend.core.db import dumps, session_scope, upsert_rows
from backend.core.logging import get_logger
from backend.core.models import DataQualityEvent, IngestionJob, Market, OHLCV
from backend.data_ingestion.quality import clean_candles, cross_exchange_deviation
from backend.data_ingestion.universe import expected_bars_per_day, target_timeframe_for
from backend.exchanges.registry import get_adapter
from backend.exchanges.symbols import timeframe_to_ms

log = get_logger("ingestion")


async def ingest_market(
    exchange_code: str,
    symbol: str,
    market_type: str,
    timeframe: str | None = None,
    lookback_days: int | None = None,
    incremental: bool = True,
) -> dict[str, Any]:
    s = effective_settings()
    timeframe = timeframe or target_timeframe_for(exchange_code, s.bar_timeframe)
    lookback_days = lookback_days or s.ingest_lookback_days
    adapter = get_adapter(exchange_code)
    now_ms = int(time.time() * 1000)
    tf_ms = timeframe_to_ms(timeframe)

    with session_scope() as ses:
        existing_max = ses.execute(
            select(func.max(OHLCV.ts)).where(
                OHLCV.exchange_code == exchange_code, OHLCV.symbol == symbol, OHLCV.timeframe == timeframe
            )
        ).scalar()
    start_ms = now_ms - lookback_days * 86_400_000
    if incremental and existing_max:
        start_ms = max(start_ms, int(existing_max) - 2 * tf_ms)

    job_id = f"ing-{uuid.uuid4().hex[:12]}"
    started = datetime.now(timezone.utc)
    with session_scope() as ses:
        ses.add(
            IngestionJob(
                id=job_id, kind="historical", exchange_code=exchange_code, symbol=symbol,
                timeframe=timeframe, status="running", started_at=started,
                checkpoint_json=dumps({"start_ms": start_ms, "end_ms": now_ms}),
            )
        )
    t0 = time.perf_counter()
    try:
        candles = await adapter.fetch_ohlcv(symbol, timeframe, start_ms, now_ms)
        report = clean_candles(candles, timeframe)
        rows = [
            {
                "exchange_code": exchange_code,
                "symbol": symbol,
                "timeframe": timeframe,
                "ts": c.ts,
                "open": c.open,
                "high": c.high,
                "low": c.low,
                "close": c.close,
                "volume": c.volume,
                "quote_volume": c.quote_volume,
                "is_final": bool(c.is_final),
                "source": "rest_historical",
                "ingested_at": datetime.now(timezone.utc),
            }
            for c in report.cleaned
            if c.ts < now_ms - tf_ms  # only closed bars are final
        ]
        with session_scope() as ses:
            written = upsert_rows(ses, OHLCV.__table__, rows, ["exchange_code", "symbol", "timeframe", "ts"])
            for issue in report.issues[:20]:
                ses.add(
                    DataQualityEvent(
                        exchange_code=exchange_code, symbol=symbol, timeframe=timeframe,
                        event_type=issue["event_type"], severity=issue["severity"],
                        details_json=dumps(issue["details"]),
                    )
                )
            job = ses.get(IngestionJob, job_id)
            if job:
                job.status = "success"
                job.finished_at = datetime.now(timezone.utc)
                job.rows_written = written
                job.checkpoint_json = dumps({"last_bar_ts": rows[-1]["ts"] if rows else None})
        elapsed = (time.perf_counter() - t0) * 1000
        log.info(
            f"ingested {symbol} {timeframe}: {len(rows)} bars",
            extra={"exchange": exchange_code, "symbol": symbol, "rows": len(rows), "duration_ms": round(elapsed, 1)},
        )
        return {
            "exchange": exchange_code, "symbol": symbol, "timeframe": timeframe,
            "bars": len(rows), "written": written, "gaps": report.gaps,
            "duplicates": report.duplicates, "dropped": report.dropped,
            "status": "success", "elapsed_ms": round(elapsed, 1),
        }
    except Exception as exc:  # noqa: BLE001
        with session_scope() as ses:
            job = ses.get(IngestionJob, job_id)
            if job:
                job.status = "failed"
                job.finished_at = datetime.now(timezone.utc)
                job.error = str(exc)[:1000]
        log.error(f"ingestion failed {exchange_code}/{symbol}: {exc}", extra={"exchange": exchange_code, "symbol": symbol})
        return {"exchange": exchange_code, "symbol": symbol, "timeframe": timeframe, "status": "failed", "error": str(exc)[:400]}


async def ingest_universe(lookback_days: int | None = None, limit: int | None = None) -> dict[str, Any]:
    s = effective_settings()
    with session_scope() as ses:
        markets = (
            ses.execute(select(Market).where(Market.in_universe.is_(True)).order_by(Market.quote_volume_24h.desc()))
            .scalars()
            .all()
        )
        targets = [(m.exchange_code, m.symbol, m.market_type) for m in markets][: limit or len(markets)]
    sem = asyncio.Semaphore(max(2, s.ingestion_concurrency))

    async def one(ex: str, sym: str, mt: str) -> dict[str, Any]:
        async with sem:
            return await ingest_market(ex, sym, mt, lookback_days=lookback_days)

    results = await asyncio.gather(*(one(*t) for t in targets))
    refresh_eligibility()
    check_cross_exchange_prices()
    ok = sum(1 for r in results if r["status"] == "success")
    return {
        "markets": len(results), "success": ok, "failed": len(results) - ok,
        "bars": sum(r.get("bars", 0) for r in results), "results": results,
    }


async def update_derivative_metrics() -> dict[str, Any]:
    """Snapshot funding/OI/mark/index for derivative markets (real endpoints only)."""
    from backend.core.models import DerivativeMetric

    s = effective_settings()
    with session_scope() as ses:
        markets = ses.execute(
            select(Market).where(
                Market.market_type.in_(["swap", "futures"]),
                Market.in_universe.is_(True),
            )
        ).scalars().all()
        targets = [(m.exchange_code, m.symbol) for m in markets]
    written = 0
    for ex, sym in targets:
        adapter = get_adapter(ex)
        try:
            snap = await adapter.fetch_derivative_snapshot(sym)
        except Exception as exc:  # noqa: BLE001
            log.warning(f"derivative snapshot failed {ex}/{sym}: {exc}")
            continue
        if snap is None:
            continue
        with session_scope() as ses:
            written += upsert_rows(
                ses,
                DerivativeMetric.__table__,
                [{
                    "exchange_code": ex, "symbol": sym, "ts": snap.ts,
                    "funding_rate": snap.funding_rate, "funding_next": snap.funding_next,
                    "open_interest": snap.open_interest, "open_interest_quote": snap.open_interest_quote,
                    "mark_price": snap.mark_price, "index_price": snap.index_price,
                    "basis": snap.basis, "source": "rest",
                }],
                ["exchange_code", "symbol", "ts"],
            )
    return {"derivative_snapshots": written}


def refresh_eligibility() -> dict[str, Any]:
    """Recompute history length/completeness and per-model eligibility reasons."""
    s = effective_settings()
    updated = 0
    with session_scope() as ses:
        markets = ses.execute(select(Market)).scalars().all()
        for m in markets:
            tf = target_timeframe_for(m.exchange_code, s.bar_timeframe)
            row = ses.execute(
                select(func.count(), func.min(OHLCV.ts), func.max(OHLCV.ts)).where(
                    OHLCV.exchange_code == m.exchange_code, OHLCV.symbol == m.symbol, OHLCV.timeframe == tf
                )
            ).one()
            count, min_ts, max_ts = row
            if not count or not min_ts:
                m.history_days_available = 0
                m.data_completeness = 0.0
                m.model_eligible = False
                m.in_universe = m.in_universe
                m.ineligible_reasons = dumps(
                    ["no_ohlcv_history"] if m.in_universe else ["not_selected_by_liquidity_filter"]
                )
                updated += 1
                continue
            span_days = (max_ts - min_ts) / 86_400_000
            expected = max(1, (max_ts - min_ts) / timeframe_to_ms(tf) + 1)
            completeness = float(count) / expected
            m.history_days_available = int(span_days)
            m.data_completeness = round(completeness, 4)
            reasons: list[str] = []
            if span_days < s.min_history_days:
                reasons.append(f"history_days<{s.min_history_days} (observed {int(span_days)})")
            n_days = int(span_days) - 1
            if n_days < s.min_observations:
                reasons.append(f"observations<{s.min_observations} (observed {n_days})")
            if completeness < s.min_data_completeness:
                reasons.append(f"completeness<{s.min_data_completeness:.2f} (observed {completeness:.3f})")
            if not m.in_universe:
                reasons.append("not_selected_by_liquidity_filter")
            m.model_eligible = len(reasons) == 0
            m.ineligible_reasons = dumps(reasons)
            m.eligibility = dumps(
                {
                    "bars": int(count),
                    "history_days": int(span_days),
                    "completeness": round(completeness, 4),
                    "timeframe": tf,
                    "expected_bars": int(expected),
                    "min_history_days": s.min_history_days,
                    "min_observations": s.min_observations,
                    "min_data_completeness": s.min_data_completeness,
                    "models": {
                        "har_rv": len(reasons) == 0,
                        "garch_normal": len(reasons) == 0,
                        "garch_t": len(reasons) == 0,
                        "xgb_har": len(reasons) == 0,
                        "xgb_extended": len(reasons) == 0,
                        "garch_evt": len(reasons) == 0,
                    },
                }
            )
            updated += 1
    return {"markets_updated": updated}


def check_cross_exchange_prices(threshold_pct: float = 2.0) -> dict[str, Any]:
    """Flag large price deviations between venues for the same base/quote."""
    from backend.core.models import MarketSnapshot  # noqa: F401  (schema import)

    with session_scope() as ses:
        markets = ses.execute(select(Market).where(Market.last_price.isnot(None))).scalars().all()
        groups: dict[tuple[str, str], dict[str, float]] = {}
        for m in markets:
            groups.setdefault((m.base_asset, m.quote_asset), {})[f"{m.exchange_code}:{m.symbol}"] = float(m.last_price)
        events = 0
        for key, prices in groups.items():
            if len(prices) < 2:
                continue
            res = cross_exchange_deviation(prices)
            if not res["ok"] and abs(res["max_deviation_pct"]) > threshold_pct:
                ses.add(
                    DataQualityEvent(
                        exchange_code="cross_exchange", symbol=f"{key[0]}/{key[1]}", timeframe=None,
                        event_type="cross_exchange_price_deviation", severity="warning",
                        details_json=dumps(res),
                    )
                )
                events += 1
    return {"cross_exchange_events": events}

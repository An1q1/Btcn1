"""Live market-data plane.

- WebSocket tickers for venues that expose them (OKX public tickers, Binance
  public mirror streams) with exponential-backoff reconnection.
- REST polling as a universal fallback (and the only path for Coinbase/Kraken
  ticker batches here).
- A per-market freshness classifier driven by *event time* and *receive time*.

Closed-bar OHLCV is written by the scheduled historical ingester; the live plane
only streams tickers/snapshots so a dropped socket cannot corrupt candle data.
"""
from __future__ import annotations

import asyncio
import json
import random
import time
from collections import deque
from datetime import datetime, timezone
from typing import Any, AsyncIterator

import websockets
from sqlalchemy import select

from backend.core.config import effective_settings
from backend.core.db import session_scope
from backend.core.logging import get_logger
from backend.core.models import Market, MarketSnapshot
from backend.data_ingestion.universe import refresh_latest_quotes
from backend.exchanges.registry import get_adapter

log = get_logger("live")


def _now() -> datetime:
    return datetime.now(timezone.utc)


class EventBus:
    def __init__(self, max_queue: int = 100):
        self._subscribers: list[asyncio.Queue] = []
        self._max = max_queue

    def subscribe(self) -> asyncio.Queue:
        q: asyncio.Queue = asyncio.Queue(maxsize=self._max)
        self._subscribers.append(q)
        return q

    def unsubscribe(self, q: asyncio.Queue) -> None:
        if q in self._subscribers:
            self._subscribers.remove(q)

    def publish(self, event: dict[str, Any]) -> None:
        for q in list(self._subscribers):
            try:
                q.put_nowait(event)
            except asyncio.QueueFull:
                try:
                    q.get_nowait()
                    q.put_nowait(event)
                except Exception:  # pragma: no cover
                    pass


BUS = EventBus()


class LiveState:
    def __init__(self) -> None:
        self.latest: dict[str, dict[str, Any]] = {}
        self.exchange_status: dict[str, dict[str, Any]] = {}
        self.started_at: datetime | None = None
        self.last_rest_poll: datetime | None = None
        self.last_ws_message: dict[str, datetime] = {}
        self.message_counts: dict[str, int] = {}
        self.errors: deque[dict[str, Any]] = deque(maxlen=50)
        self.snapshots_written = 0

    @staticmethod
    def key(exchange: str, symbol: str) -> str:
        return f"{exchange}:{symbol}"

    def update(self, exchange: str, symbol: str, payload: dict[str, Any], source: str) -> None:
        k = self.key(exchange, symbol)
        current = self.latest.get(k, {})
        current.update(payload)
        current.update(
            {
                "exchange": exchange,
                "symbol": symbol,
                "source": source,
                "received_at": _now().isoformat(),
            }
        )
        self.latest[k] = current
        self.message_counts[exchange] = self.message_counts.get(exchange, 0) + 1
        if source.startswith("ws"):
            self.last_ws_message[exchange] = _now()
        BUS.publish({"type": "ticker", "data": current})

    def status(self) -> dict[str, Any]:
        return {
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "last_rest_poll": self.last_rest_poll.isoformat() if self.last_rest_poll else None,
            "tracked_markets": len(self.latest),
            "message_counts": self.message_counts,
            "last_ws_message": {k: v.isoformat() for k, v in self.last_ws_message.items()},
            "exchanges": self.exchange_status,
            "recent_errors": list(self.errors)[-10:],
            "snapshots_written": self.snapshots_written,
        }

    def get_many(self, keys: list[str]) -> dict[str, dict[str, Any]]:
        return {k: self.latest[k] for k in keys if k in self.latest}


STATE = LiveState()


def classify_freshness(last_event_ts: datetime | None, received_at: datetime | None = None) -> str:
    s = effective_settings()
    now = _now()
    if last_event_ts is None:
        return "unknown"
    if last_event_ts.tzinfo is None:
        last_event_ts = last_event_ts.replace(tzinfo=timezone.utc)
    age = (now - last_event_ts).total_seconds()
    if age <= s.freshness_live_seconds:
        return "live"
    if age <= s.freshness_delayed_seconds:
        return "delayed"
    if age <= s.freshness_stale_seconds:
        return "stale"
    return "disconnected"


async def _okx_ws_loop(symbols: list[str]) -> None:
    url = "wss://ws.okx.com:8443/ws/v5/public"
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**22) as ws:
                await ws.send(json.dumps({"op": "subscribe", "args": [{"channel": "tickers", "instId": s} for s in symbols]}))
                STATE.exchange_status.setdefault("okx_ws", {})["connected"] = True
                backoff = 1.0
                log.info(f"OKX websocket connected ({len(symbols)} instruments)")
                async for raw in ws:
                    msg = json.loads(raw)
                    if msg.get("event") == "error":
                        STATE.errors.append({"exchange": "okx", "error": msg, "ts": _now().isoformat()})
                        continue
                    for row in msg.get("data", []) or []:
                        inst = row.get("instId")
                        if not inst:
                            continue
                        bid = float(row.get("bidPx") or 0) or None
                        ask = float(row.get("askPx") or 0) or None
                        last = float(row.get("last") or 0) or None
                        STATE.update(
                            "okx_swap" if inst.endswith("-SWAP") else "okx_spot",
                            inst,
                            {
                                "price": last,
                                "bid": bid,
                                "ask": ask,
                                "spread_bps": ((ask - bid) / ((ask + bid) / 2) * 10000) if bid and ask else None,
                                "event_ts": datetime.fromtimestamp(int(row.get("ts", 0)) / 1000, tz=timezone.utc),
                                "ws_connected": True,
                            },
                            source="ws_okx",
                        )
        except asyncio.CancelledError:
            STATE.exchange_status.setdefault("okx_ws", {})["connected"] = False
            raise
        except Exception as exc:  # noqa: BLE001
            STATE.exchange_status.setdefault("okx_ws", {}).update({"connected": False, "last_error": str(exc)[:200]})
            STATE.errors.append({"exchange": "okx_ws", "error": str(exc)[:200], "ts": _now().isoformat()})
            log.warning(f"OKX websocket error: {exc}; retry in {backoff:.1f}s")
            await asyncio.sleep(backoff + random.uniform(0, 0.5))
            backoff = min(backoff * 2, 60)


async def _binance_ws_loop(symbols: list[str]) -> None:
    streams = "/".join(f"{s.lower()}@miniTicker" for s in symbols)
    url = f"wss://data-stream.binance.vision/stream?streams={streams}"
    backoff = 1.0
    while True:
        try:
            async with websockets.connect(url, ping_interval=20, ping_timeout=20, max_size=2**23) as ws:
                STATE.exchange_status.setdefault("binance_ws", {})["connected"] = True
                backoff = 1.0
                log.info(f"Binance mirror websocket connected ({len(symbols)} streams)")
                async for raw in ws:
                    msg = json.loads(raw)
                    data = msg.get("data") or {}
                    sym = data.get("s")
                    if not sym:
                        continue
                    STATE.update(
                        "binance_spot",
                        sym,
                        {
                            "price": float(data.get("c") or 0) or None,
                            "quote_volume_24h": float(data.get("q") or 0) or None,
                            "event_ts": datetime.fromtimestamp(int(data.get("E", 0)) / 1000, tz=timezone.utc),
                            "ws_connected": True,
                        },
                        source="ws_binance",
                    )
        except asyncio.CancelledError:
            STATE.exchange_status.setdefault("binance_ws", {})["connected"] = False
            raise
        except Exception as exc:  # noqa: BLE001
            STATE.exchange_status.setdefault("binance_ws", {}).update({"connected": False, "last_error": str(exc)[:200]})
            STATE.errors.append({"exchange": "binance_ws", "error": str(exc)[:200], "ts": _now().isoformat()})
            log.warning(f"Binance websocket error: {exc}; retry in {backoff:.1f}s")
            await asyncio.sleep(backoff + random.uniform(0, 0.5))
            backoff = min(backoff * 2, 60)


class LiveIngestor:
    def __init__(self) -> None:
        self.settings = effective_settings()
        self._tasks: list[asyncio.Task] = []
        self._stop = asyncio.Event()
        self._last_snapshot_write = 0.0

    async def _selected_markets(self) -> list[Market]:
        with session_scope() as ses:
            return list(
                ses.execute(
                    select(Market)
                    .where(Market.in_universe.is_(True))
                    .order_by(Market.quote_volume_24h.desc())
                ).scalars()
            )

    async def _rest_poll_loop(self) -> None:
        while not self._stop.is_set():
            try:
                res = await refresh_latest_quotes(symbol_limit=self.settings.live_symbol_limit)
                STATE.last_rest_poll = _now()
                STATE.exchange_status.setdefault("rest", {})["last_poll"] = STATE.last_rest_poll.isoformat()
                await self._publish_from_db()
                if time.time() - self._last_snapshot_write > 300:
                    await asyncio.to_thread(self._write_snapshots)
                    self._last_snapshot_write = time.time()
                log.info(f"live REST poll updated {res['markets_updated']} markets")
            except Exception as exc:  # noqa: BLE001
                STATE.errors.append({"exchange": "rest", "error": str(exc)[:200], "ts": _now().isoformat()})
                log.warning(f"live REST poll failed: {exc}")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=self.settings.live_poll_seconds)
            except asyncio.TimeoutError:
                continue

    async def _publish_from_db(self) -> None:
        with session_scope() as ses:
            rows = ses.execute(
                select(Market).where(Market.in_universe.is_(True), Market.last_price.isnot(None))
            ).scalars()
            for m in rows:
                STATE.update(
                    m.exchange_code,
                    m.symbol,
                    {
                        "price": m.last_price,
                        "bid": m.bid,
                        "ask": m.ask,
                        "spread_bps": m.spread_bps,
                        "quote_volume_24h": m.quote_volume_24h,
                        "event_ts": m.last_update_ts,
                    },
                    source="rest_poll",
                )

    def _write_snapshots(self) -> None:
        with session_scope() as ses:
            rows = ses.execute(select(Market).where(Market.in_universe.is_(True))).scalars().all()
            payload = [
                {
                    "exchange_code": m.exchange_code,
                    "symbol": m.symbol,
                    "ts": _now(),
                    "price": m.last_price,
                    "bid": m.bid,
                    "ask": m.ask,
                    "spread_bps": m.spread_bps,
                    "quote_volume_24h": m.quote_volume_24h,
                    "source": "live_poll",
                }
                for m in rows
            ]
            if payload:
                ses.bulk_insert_mappings(MarketSnapshot, payload)
            STATE.snapshots_written += len(payload)

    async def start(self) -> None:
        if self._tasks:
            return
        STATE.started_at = _now()
        markets = await self._selected_markets()
        okx = [m.symbol for m in markets if m.exchange_code in ("okx_spot", "okx_swap")][:20]
        binance = [m.symbol for m in markets if m.exchange_code == "binance_spot"][:20]
        self._tasks.append(asyncio.create_task(self._rest_poll_loop(), name="live_rest"))
        if self.settings.enable_websocket:
            if okx:
                self._tasks.append(asyncio.create_task(_okx_ws_loop(okx), name="ws_okx"))
            if binance:
                self._tasks.append(asyncio.create_task(_binance_ws_loop(binance), name="ws_binance"))
        log.info(f"live ingestor started: {len(markets)} markets, {len(self._tasks)} tasks")

    async def stop(self) -> None:
        self._stop.set()
        for t in self._tasks:
            t.cancel()
        for t in self._tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self._tasks = []


INGESTOR = LiveIngestor()


async def event_stream(exchange_filter: str | None = None) -> AsyncIterator[dict[str, Any]]:
    q = BUS.subscribe()
    try:
        yield {"type": "hello", "data": STATE.status()}
        while True:
            try:
                event = await asyncio.wait_for(q.get(), timeout=20)
            except asyncio.TimeoutError:
                yield {"type": "heartbeat", "ts": _now().isoformat(), "data": STATE.status()}
                continue
            if exchange_filter and event.get("data", {}).get("exchange") != exchange_filter:
                continue
            yield event
    finally:
        BUS.unsubscribe(q)


def market_live_status(exchange: str, symbol: str, last_update: datetime | None) -> str:
    k = STATE.key(exchange, symbol)
    entry = STATE.latest.get(k)
    if entry:
        return classify_freshness(entry.get("event_ts") or entry.get("received_at"))
    return classify_freshness(last_update)

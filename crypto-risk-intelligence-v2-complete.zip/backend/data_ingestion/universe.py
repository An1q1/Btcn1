"""Market Universe Service: discovers tradable markets on every enabled venue,
normalizes them, applies quality filters and selects a deep-ingestion universe.

The selection is data-driven (24h quote volume, spread, base-asset diversification)
and never a hard-coded coin list. All discovered markets are persisted so the
screener can search hundreds of symbols; only the selected subset receives
intraday history and model coverage.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any

from sqlalchemy import select

from backend.core.config import effective_settings
from backend.core.db import dumps, session_scope, upsert_rows
from backend.core.logging import get_logger
from backend.core.models import Exchange, Market
from backend.exchanges.base import MarketInfo
from backend.exchanges.registry import enabled_adapters, get_adapter
from backend.exchanges.symbols import canonical_id, timeframe_to_ms

log = get_logger("universe")


def _market_row(info: MarketInfo, canonical: str, in_universe: bool) -> dict[str, Any]:
    meta = dict(info.meta or {})
    meta.update(
        {
            "canonical_symbol": canonical,
            "native_symbol": info.symbol,
            "exchange": info.exchange_code,
            "market_type": info.market_type,
        }
    )
    return {
        "exchange_code": info.exchange_code,
        "symbol": info.symbol,
        "canonical_symbol": canonical,
        "base_asset": info.base_asset,
        "quote_asset": info.quote_asset,
        "market_type": info.market_type,
        "contract_type": info.contract_type,
        "price_unit": info.price_unit,
        "status": info.status,
        "is_stable_pair": bool(meta.get("is_stable_pair")),
        "is_leveraged_token": bool(meta.get("is_leveraged_token")),
        "is_wrapped": bool(meta.get("is_wrapped")),
        "in_universe": in_universe,
        "model_eligible": False,
        "ineligible_reasons": dumps(["pending_history_check"]),
        "eligibility": None,
        "last_price": info.price,
        "quote_volume_24h": info.quote_volume_24h,
        "bid": info.bid,
        "ask": info.ask,
        "spread_bps": info.spread_bps,
        "price_change_24h_pct": info.price_change_24h_pct,
        "last_update_ts": info.last_update_ts or datetime.now(timezone.utc),
        "data_completeness": None,
        "history_days_available": None,
        "meta_json": dumps(meta),
        "discovered_at": datetime.now(timezone.utc),
        "updated_at": datetime.now(timezone.utc),
    }


class UniverseService:
    def __init__(self) -> None:
        self.settings = effective_settings()

    async def probe_exchanges(self) -> dict[str, dict[str, Any]]:
        adapters = enabled_adapters()
        results = await asyncio.gather(*(a.probe() for a in adapters.values()), return_exceptions=True)
        statuses: dict[str, dict[str, Any]] = {}
        rows = []
        for (code, adapter), res in zip(adapters.items(), results):
            if isinstance(res, Exception):  # pragma: no cover - defensive
                res = {"code": code, "name": adapter.name, "status": "error", "detail": str(res), "capabilities": adapter.capabilities}
            statuses[code] = res
            rows.append(
                {
                    "code": code,
                    "name": adapter.name,
                    "market_types": ",".join(adapter.market_types),
                    "enabled": True,
                    "rest_url": adapter.rest_url,
                    "ws_url": adapter.ws_url,
                    "status": res.get("status", "error"),
                    "status_detail": res.get("detail"),
                    "latency_ms": res.get("latency_ms"),
                    "time_skew_ms": None,
                    "last_checked_at": datetime.now(timezone.utc),
                    "capabilities": dumps(res.get("capabilities") or adapter.capabilities),
                    "notes": (adapter.capabilities or {}).get("notes"),
                }
            )
        with session_scope() as ses:
            upsert_rows(ses, Exchange.__table__, rows, ["code"])
        return statuses

    async def discover(self, persist: bool = True) -> dict[str, Any]:
        """Fetch markets from all enabled adapters concurrently."""
        adapters = enabled_adapters()
        discovered: list[tuple[str, MarketInfo]] = []
        failures: dict[str, str] = {}
        results = await asyncio.gather(*(a.fetch_markets() for a in adapters.values()), return_exceptions=True)
        for (code, _adapter), res in zip(adapters.items(), results):
            if isinstance(res, Exception):
                failures[code] = str(res)[:400]
                log.warning("universe discovery failed", extra={"exchange": code, "event": "discovery_error"})
                continue
            for m in res:
                discovered.append((code, m))
        log.info(f"discovered {len(discovered)} markets", extra={"event": "universe_discovered"})

        selected, selection_meta = self._select(discovered, self._existing_universe())
        selected_keys = {(m.exchange_code, m.symbol, m.market_type) for m in selected}

        if persist:
            self._persist(discovered, selected_keys)
        return {
            "discovered": len(discovered),
            "failures": failures,
            "selected": [
                {
                    "exchange": m.exchange_code,
                    "symbol": m.symbol,
                    "base": m.base_asset,
                    "quote": m.quote_asset,
                    "market_type": m.market_type,
                    "quote_volume_24h": m.quote_volume_24h,
                    "spread_bps": m.spread_bps,
                }
                for m in selected
            ],
            **selection_meta,
        }

    def _existing_universe(self) -> set[tuple[str, str, str]]:
        """Markets already in the universe, used to keep selection stable.

        Re-running discovery every few hours on a volume ranking alone would
        silently reshuffle the modelled universe: markets would drop out of the
        feature/forecast build and the comparison across runs would stop being
        like-for-like. The selection below therefore **carries over** every
        existing universe market that still passes the quality filters, and only
        fills the remaining slots with new candidates.
        """
        with session_scope() as ses:
            rows = ses.execute(
                select(Market.exchange_code, Market.symbol, Market.market_type).where(
                    Market.in_universe.is_(True)
                )
            ).all()
        return {(r[0], r[1], r[2]) for r in rows}

    # ------------------------------------------------------------------
    def _select(
        self,
        discovered: list[tuple[str, MarketInfo]],
        existing: set[tuple[str, str, str]] | None = None,
    ) -> tuple[list[MarketInfo], dict[str, Any]]:
        s = self.settings
        excluded = {"stable_pair": 0, "leveraged": 0, "low_volume": 0, "wide_spread": 0,
                    "quote": 0, "non_crypto": 0, "unconfirmed_asset": 0}
        # Assets explicitly classified as crypto by OKX, or listed on venues that
        # only serve crypto (Coinbase / Kraken), form the confirmed asset set.
        confirmed: set[str] = set()
        for code, m in discovered:
            ac = (m.meta or {}).get("asset_class")
            if ac == "crypto" or (ac is None and code in ("coinbase", "kraken")):
                confirmed.add(m.base_asset.upper())

        by_exchange: dict[str, list[MarketInfo]] = {}
        for _code, m in discovered:
            if m.quote_asset not in s.quote_list:
                excluded["quote"] += 1
                continue
            meta = m.meta or {}
            if meta.get("asset_class") not in (None, "crypto"):
                excluded["non_crypto"] += 1          # tokenized equities / commodities
                continue
            if meta.get("asset_class") is None and m.base_asset.upper() not in confirmed:
                excluded["unconfirmed_asset"] += 1   # isolated listings with no crypto cross-listing
                continue
            if s.exclude_stable_bases and meta.get("is_stable_pair"):
                excluded["stable_pair"] += 1
                continue
            if s.exclude_leveraged and meta.get("is_leveraged_token"):
                excluded["leveraged"] += 1
                continue
            if (m.quote_volume_24h or 0) < s.min_quote_volume_usd:
                excluded["low_volume"] += 1
                continue
            if m.spread_bps is not None and m.spread_bps > s.max_spread_bps:
                excluded["wide_spread"] += 1
                continue
            by_exchange.setdefault(m.exchange_code, []).append(m)

        for lst in by_exchange.values():
            lst.sort(key=lambda m: m.quote_volume_24h or 0, reverse=True)

        quotas = {"binance_spot": 12, "okx_spot": 6, "okx_swap": 9, "coinbase": 4, "kraken": 3,
                  "bybit_spot": 3, "bybit_linear": 3, "binance_futures": 4}
        per_base: dict[str, int] = {}
        per_base_exchange: set[tuple[str, str]] = set()
        selected: list[MarketInfo] = []

        # Round 0: keep markets that are already modelled (stability first).
        carried = 0
        if existing:
            pool = sorted(
                (m for lst in by_exchange.values() for m in lst),
                key=lambda m: m.quote_volume_24h or 0, reverse=True,
            )
            for m in pool:
                key = (m.exchange_code, m.symbol, m.market_type)
                if key not in existing:
                    continue
                if per_base.get(m.base_asset, 0) >= s.max_markets_per_base_asset:
                    continue
                if (m.base_asset, m.exchange_code) in per_base_exchange:
                    continue
                selected.append(m)
                per_base[m.base_asset] = per_base.get(m.base_asset, 0) + 1
                per_base_exchange.add((m.base_asset, m.exchange_code))
                carried += 1
            existing_keys = {(m.exchange_code, m.symbol, m.market_type) for m in selected}
        else:
            existing_keys = set()
        # Round 1: satisfy venue quotas from each venue's own ranking.
        for code, quota in quotas.items():
            takes = 0
            for m in by_exchange.get(code, []):
                if takes >= quota or len(selected) >= s.target_markets:
                    break
                if (m.exchange_code, m.symbol, m.market_type) in existing_keys:
                    continue
                if per_base.get(m.base_asset, 0) >= s.max_markets_per_base_asset:
                    continue
                if (m.base_asset, code) in per_base_exchange:
                    continue  # one quote per base per venue (BTCUSDT vs BTCUSDC)
                selected.append(m)
                per_base[m.base_asset] = per_base.get(m.base_asset, 0) + 1
                per_base_exchange.add((m.base_asset, code))
                takes += 1
        # Round 2: fill remaining slots by global volume, respecting base caps.
        if len(selected) < s.target_markets:
            pool = sorted((m for lst in by_exchange.values() for m in lst),
                          key=lambda m: m.quote_volume_24h or 0, reverse=True)
            for m in pool:
                if len(selected) >= s.target_markets:
                    break
                if m in selected or per_base.get(m.base_asset, 0) >= s.max_markets_per_base_asset:
                    continue
                if (m.base_asset, m.exchange_code) in per_base_exchange:
                    continue
                selected.append(m)
                per_base[m.base_asset] = per_base.get(m.base_asset, 0) + 1
                per_base_exchange.add((m.base_asset, m.exchange_code))
        meta = {
            "candidates": sum(len(v) for v in by_exchange.values()),
            "excluded": excluded,
            "selected_count": len(selected),
            "carried_over": carried,
            "new_entries": len(selected) - carried,
            "dropped": max(0, len(existing or ()) - carried),
            "by_exchange": {c: sum(1 for m in selected if m.exchange_code == c) for c in {m.exchange_code for m in selected}},
        }
        return selected, meta

    def _persist(self, discovered: list[tuple[str, MarketInfo]], selected_keys: set[tuple[str, str, str]]) -> None:
        rows = []
        seen: set[tuple[str, str, str]] = set()
        for code, m in discovered:
            key = (m.exchange_code, m.symbol, m.market_type)
            if key in seen:
                continue
            seen.add(key)
            canonical = (m.meta or {}).get("canonical") or canonical_id(
                m.exchange_code, m.market_type, m.base_asset, m.quote_asset, m.contract_type
            )
            rows.append(_market_row(m, canonical, key in selected_keys))
        with session_scope() as ses:
            # Eligibility is owned by the history check, not by discovery: a
            # 6-hourly re-discovery must not temporarily reset every market to
            # "not eligible" (that would blank the model universe in the UI).
            upsert_rows(
                ses,
                Market.__table__,
                rows,
                ["exchange_code", "symbol", "market_type"],
                skip_update=("model_eligible", "ineligible_reasons", "eligibility"),
            )
            # markets previously in the universe but no longer selected
            existing = ses.execute(select(Market)).scalars().all()
            for mk in existing:
                if (mk.exchange_code, mk.symbol, mk.market_type) not in seen:
                    mk.status = "delisted_or_unavailable"
                    mk.in_universe = False
                    mk.updated_at = datetime.now(timezone.utc)
        log.info(f"persisted {len(rows)} markets", extra={"event": "universe_persisted", "rows": len(rows)})


async def refresh_latest_quotes(symbol_limit: int | None = None) -> dict[str, int]:
    """Refresh prices/spreads/volume for all stored markets using batch tickers."""
    s = effective_settings()
    updated = 0
    with session_scope() as ses:
        markets = ses.execute(select(Market).where(Market.status == "active")).scalars().all()
        by_exchange: dict[str, list[Market]] = {}
        for m in markets:
            by_exchange.setdefault(m.exchange_code, []).append(m)
    for code, mks in by_exchange.items():
        try:
            adapter = get_adapter(code)
        except KeyError:
            continue
        cap = symbol_limit or s.live_symbol_limit
        if code == "coinbase":  # per-product endpoint: keep the fan-out small
            cap = min(cap, 12)
        # Always quote the modelled universe first: a per-exchange cap must never
        # starve in-universe markets in favour of long-tail listings.
        mks.sort(key=lambda m: (not m.in_universe, -(m.quote_volume_24h or 0)))
        symbols = [m.symbol for m in mks][:cap]
        try:
            tickers = await adapter.fetch_tickers(symbols)
        except Exception as exc:  # noqa: BLE001
            log.warning(f"ticker refresh failed for {code}: {exc}", extra={"exchange": code})
            continue
        updates = []
        meta_by_symbol = {m.symbol: m for m in mks}
        for sym, t in tickers.items():
            mk = meta_by_symbol.get(sym)
            if mk is None:
                continue
            updates.append(
                {
                    "exchange_code": code,
                    "symbol": sym,
                    "canonical_symbol": mk.canonical_symbol,
                    "base_asset": mk.base_asset,
                    "quote_asset": mk.quote_asset,
                    "market_type": mk.market_type,
                    "status": mk.status,
                    "last_price": t.price or mk.last_price,
                    "quote_volume_24h": t.quote_volume_24h or mk.quote_volume_24h,
                    "spread_bps": t.spread_bps if t.spread_bps is not None else mk.spread_bps,
                    "bid": t.bid,
                    "ask": t.ask,
                    "price_change_24h_pct": t.price_change_24h_pct if t.price_change_24h_pct is not None else mk.price_change_24h_pct,
                    "last_update_ts": datetime.now(timezone.utc),
                    "updated_at": datetime.now(timezone.utc),
                }
            )
        if updates:
            # Upsert only the mutable columns to avoid clobbering eligibility fields.
            with session_scope() as ses:
                for u in updates:
                    ses.execute(
                        Market.__table__.update()
                        .where(
                            (Market.exchange_code == u["exchange_code"])
                            & (Market.symbol == u["symbol"])
                            & (Market.market_type == u["market_type"])
                        )
                        .values(
                            last_price=u["last_price"],
                            quote_volume_24h=u["quote_volume_24h"],
                            spread_bps=u["spread_bps"],
                            bid=u["bid"],
                            ask=u["ask"],
                            price_change_24h_pct=u["price_change_24h_pct"],
                            last_update_ts=u["last_update_ts"],
                            updated_at=u["updated_at"],
                        )
                    )
            updated += len(updates)
    return {"markets_updated": updated}


def target_timeframe_for(exchange_code: str, default: str = "4h") -> str:
    """Coinbase only serves a fixed granularity set; record the actual bar."""
    if exchange_code == "coinbase":
        return "6h"
    return default


def expected_bars_per_day(timeframe: str) -> int:
    return max(1, int(86_400_000 / timeframe_to_ms(timeframe)))

"""REST API v1.

Errors use a single structured envelope:
    {"error": {"code": <http status>, "message": "...", "details": ...}}
"""
from __future__ import annotations

import asyncio
import json
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from backend.api.deps import require_token
from backend.core.config import effective_settings
from backend.data_ingestion.live import event_stream
from backend.services import market_service, model_service, risk_service, system_service
from backend.services.alert_service import acknowledge_alert, generate_alerts, list_alerts

router = APIRouter(prefix="/api/v1")


# ----------------------------------------------------------------- basics ---
@router.get("/health", tags=["system"])
def health() -> dict[str, Any]:
    return system_service.health()


@router.get("/system/status", tags=["system"])
def system_status() -> dict[str, Any]:
    return system_service.system_status()


@router.get("/exchanges", tags=["system"])
def exchanges() -> dict[str, Any]:
    return system_service.exchanges()


@router.get("/data-quality", tags=["system"])
def data_quality(
    severity: str | None = None,
    exchange: str | None = None,
    limit: int = Query(100, ge=1, le=500),
) -> dict[str, Any]:
    return system_service.data_quality(severity=severity, exchange=exchange, limit=limit)


@router.get("/stream", tags=["system"])
async def stream(request: Request, exchange: str | None = None) -> StreamingResponse:
    async def gen():
        yield "retry: 5000\n\n"
        async for ev in event_stream(exchange):
            if await request.is_disconnected():
                break
            payload = json.dumps(ev, default=str)
            yield f"event: {ev.get('type', 'message')}\ndata: {payload}\n\n"

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no", "Connection": "keep-alive"},
    )


# ---------------------------------------------------------------- markets ---
@router.get("/overview", tags=["markets"])
def overview() -> dict[str, Any]:
    return market_service.overview()


@router.get("/markets", tags=["markets"])
def markets(
    search: str | None = None,
    exchange: str | None = None,
    quote: str | None = None,
    market_type: str | None = None,
    min_volume: float | None = None,
    eligible_only: bool = False,
    regime: str | None = None,
    in_universe: bool | None = None,
    sort: str = "quote_volume",
    order: str = "desc",
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=500),
) -> dict[str, Any]:
    if sort not in market_service.SORT_FIELDS:
        raise HTTPException(status_code=422, detail=f"invalid sort field '{sort}'")
    if order not in ("asc", "desc"):
        raise HTTPException(status_code=422, detail="order must be 'asc' or 'desc'")
    return market_service.list_markets(
        search=search, exchange=exchange, quote=quote, market_type=market_type,
        min_volume=min_volume, eligible_only=eligible_only, regime=regime,
        in_universe=in_universe, sort=sort, order=order, page=page, page_size=page_size,
    )


@router.get("/markets/{exchange}/{symbol}", tags=["markets"])
def market_detail(exchange: str, symbol: str) -> dict[str, Any]:
    detail = market_service.asset_detail(exchange, symbol)
    if detail is None:
        raise HTTPException(status_code=404, detail=f"market '{exchange}:{symbol}' not found")
    return detail


@router.get("/markets/{exchange}/{symbol}/ohlcv", tags=["markets"])
def market_ohlcv(
    exchange: str, symbol: str, timeframe: str | None = None, limit: int = Query(400, ge=10, le=2000)
) -> dict[str, Any]:
    tf = timeframe or market_service.target_timeframe_for(exchange, effective_settings().bar_timeframe)
    data = market_service.ohlcv_series_safe(exchange, symbol, tf, limit)
    if not data:
        raise HTTPException(status_code=404, detail="no OHLCV data for this market")
    return {"exchange": exchange, "symbol": symbol, "timeframe": tf, "bars": len(data), "items": data}


@router.get("/markets/{exchange}/{symbol}/series", tags=["markets"])
def market_series(
    exchange: str, symbol: str, timeframe: str | None = None, limit: int = Query(400, ge=10, le=2000)
) -> dict[str, Any]:
    data = market_service.market_series_bundle(exchange, symbol, timeframe, limit)
    if not data.get("ohlcv"):
        raise HTTPException(status_code=404, detail="no OHLCV data for this market")
    return {"exchange": exchange, "symbol": symbol, **data}


@router.get("/markets/{exchange}/{symbol}/features", tags=["markets"])
def market_features(exchange: str, symbol: str, limit: int = Query(300, ge=10, le=1000)) -> dict[str, Any]:
    from backend.services.analytics import feature_series

    data = feature_series(exchange, symbol, limit)
    if not data:
        raise HTTPException(status_code=404, detail="no engineered features for this market")
    return {"exchange": exchange, "symbol": symbol, "items": data}


@router.get("/markets/{exchange}/{symbol}/forecasts", tags=["forecasts"])
def market_forecasts(
    exchange: str, symbol: str, horizon: int = 1, model: str = "har_rv", limit: int = Query(365, ge=10, le=2000)
) -> dict[str, Any]:
    from backend.services.analytics import forecast_history

    return {
        "exchange": exchange, "symbol": symbol, "horizon": horizon, "model": model,
        "items": forecast_history(exchange, symbol, horizon, model, limit),
    }


@router.get("/markets/{exchange}/{symbol}/risk", tags=["risk"])
def market_risk(exchange: str, symbol: str, confidence: float = Query(0.99, ge=0.5, le=0.9999)) -> dict[str, Any]:
    return risk_service.tail_detail(exchange, symbol, confidence)


@router.get("/markets/{exchange}/{symbol}/comparison", tags=["forecasts"])
def market_comparison(exchange: str, symbol: str, horizon: int = 1) -> dict[str, Any]:
    res = model_service.model_comparison(exchange, symbol, horizon)
    if res is None:
        raise HTTPException(status_code=404, detail="market not found")
    return res


# -------------------------------------------------------------- forecasts ---
@router.get("/forecasts", tags=["forecasts"])
def forecasts(
    horizon: int = 1,
    model: str | None = None,
    sort: str = "forecast_vol",
    limit: int = Query(100, ge=1, le=500),
) -> dict[str, Any]:
    return model_service.forecasts_table(horizon=horizon, model=model, sort=sort, limit=limit)


@router.get("/models", tags=["forecasts"])
def models() -> dict[str, Any]:
    return model_service.models_catalog()


# ------------------------------------------------------------------- risk ---
@router.get("/risk/var-es", tags=["risk"])
def var_es(confidence: float = Query(0.99, ge=0.5, le=0.9999)) -> dict[str, Any]:
    return risk_service.tail_risk_table(confidence)


@router.get("/risk/backtests", tags=["risk"])
def risk_backtests(confidence: float = Query(0.99, ge=0.5, le=0.9999)) -> dict[str, Any]:
    return risk_service.risk_backtests(confidence)


@router.get("/risk/overview", tags=["risk"])
def risk_overview() -> dict[str, Any]:
    return risk_service.risk_overview()


# -------------------------------------------------------------- research ---
@router.get("/backtests", tags=["research"])
def backtests() -> dict[str, Any]:
    return model_service.research_summary()


# ----------------------------------------------------------------- alerts ---
@router.get("/alerts", tags=["alerts"])
def alerts(
    severity: str | None = None,
    acknowledged: bool | None = None,
    active_only: bool = False,
    limit: int = Query(100, ge=1, le=500),
) -> dict[str, Any]:
    return list_alerts(
        severity=severity, acknowledged=acknowledged, active_only=active_only, limit=limit
    )


@router.post("/alerts/{alert_id}/ack", tags=["alerts"], dependencies=[Depends(require_token)])
def ack_alert(alert_id: int) -> dict[str, Any]:
    if not acknowledge_alert(alert_id):
        raise HTTPException(status_code=404, detail="alert not found")
    return {"ok": True, "id": alert_id}


# --------------------------------------------------------------- settings ---
class SettingsUpdate(BaseModel):
    values: dict[str, Any] = Field(default_factory=dict)


@router.get("/settings", tags=["settings"])
def get_settings_route() -> dict[str, Any]:
    return system_service.get_settings()


@router.put("/settings", tags=["settings"], dependencies=[Depends(require_token)])
def update_settings_route(payload: SettingsUpdate) -> dict[str, Any]:
    try:
        return system_service.update_settings(payload.values)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


# ------------------------------------------------------------------ admin ---
class RunTaskRequest(BaseModel):
    lookback_days: int | None = Field(default=None, ge=30, le=3000)
    market_limit: int | None = Field(default=None, ge=1, le=200)


@router.post("/admin/run/{task}", tags=["admin"], dependencies=[Depends(require_token)])
async def run_task(task: str, payload: RunTaskRequest | None = None) -> dict[str, Any]:
    """Trigger a pipeline task. Long tasks run in the background and are
    observable through /system/status (ModelRun / IngestionJob records)."""
    from backend.data_ingestion.historical import ingest_universe, refresh_eligibility, update_derivative_metrics
    from backend.data_ingestion.universe import UniverseService, refresh_latest_quotes
    from backend.features.pipeline import build_all_features
    from backend.quant.evaluation import run_evaluation
    from backend.quant.walkforward import run_forecast_pipeline
    from backend.risk.var_es import run_risk_pipeline

    body = payload or RunTaskRequest()
    if task == "discover":
        svc = UniverseService()
        await svc.probe_exchanges()
        res = await svc.discover()
        return {"task": task, "result": {k: res[k] for k in ("discovered", "selected_count", "by_exchange")}}
    if task == "ingest":
        res = await ingest_universe(lookback_days=body.lookback_days)
        refresh_eligibility()
        await refresh_latest_quotes(symbol_limit=60)
        return {"task": task, "result": {k: res[k] for k in ("markets", "success", "failed", "bars")}}
    if task == "derivatives":
        return {"task": task, "result": await update_derivative_metrics()}
    if task == "features":
        return {"task": task, "result": build_all_features()}
    if task == "forecast":
        return {"task": task, "result": run_forecast_pipeline(market_limit=body.market_limit)}
    if task == "risk":
        return {"task": task, "result": run_risk_pipeline(market_limit=body.market_limit)}
    if task == "evaluate":
        return {"task": task, "result": run_evaluation()}
    if task == "alerts":
        return {"task": task, "result": generate_alerts()}
    raise HTTPException(status_code=404, detail=f"unknown task '{task}'")

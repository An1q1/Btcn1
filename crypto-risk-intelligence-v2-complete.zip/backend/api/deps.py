"""API dependencies: optional bearer auth for mutating endpoints."""
from __future__ import annotations

from fastapi import Header, HTTPException

from backend.core.config import get_settings


async def require_token(authorization: str | None = Header(default=None)) -> None:
    token = get_settings().api_token
    if not token:
        return  # auth disabled (local research deployment)
    if not authorization or not authorization.lower().startswith("bearer "):
        raise HTTPException(status_code=401, detail="missing bearer token")
    if authorization.split(" ", 1)[1].strip() != token:
        raise HTTPException(status_code=403, detail="invalid token")

"""FastAPI application entry point.

Run locally:
    uvicorn backend.main:app --host 0.0.0.0 --port 8000
"""
from __future__ import annotations

import json
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.api.routes import router
from backend.core.config import BASE_DIR, get_settings
from backend.core.db import init_db
from backend.core.logging import configure_logging, get_logger
from backend.exchanges.registry import close_all
from backend.workers.scheduler import SCHEDULER

log = get_logger("api")
FRONTEND_DIR = BASE_DIR / "frontend"


@asynccontextmanager
async def lifespan(app: FastAPI):
    configure_logging(get_settings().log_level)
    init_db()
    log.info("api starting", extra={"event": "startup"})
    if get_settings().enable_background_jobs:
        try:
            await SCHEDULER.start()
        except Exception as exc:  # noqa: BLE001
            log.error(f"scheduler failed to start: {exc}")
    yield
    await SCHEDULER.stop()
    await close_all()
    log.info("api stopped", extra={"event": "shutdown"})


app = FastAPI(
    title="Crypto Risk Intelligence Platform API",
    version="1.0.0",
    description=(
        "Multi-exchange crypto volatility forecasting and tail-risk analytics. "
        "Public market data only; no trading endpoints. Research use."
    ),
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=get_settings().cors_list,
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "OPTIONS"],
    allow_headers=["*"],
)
app.include_router(router)


@app.middleware("http")
async def timing_middleware(request: Request, call_next):
    t0 = time.perf_counter()
    response = await call_next(request)
    elapsed = (time.perf_counter() - t0) * 1000
    response.headers["X-Response-Time-ms"] = f"{elapsed:.1f}"
    if request.url.path.startswith("/api/") and elapsed > 2000:
        log.warning(f"slow request {request.method} {request.url.path} {elapsed:.0f}ms")
    return response


@app.exception_handler(HTTPException)
async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    return JSONResponse(
        status_code=exc.status_code,
        content={"error": {"code": exc.status_code, "message": exc.detail, "path": request.url.path}},
    )


@app.exception_handler(RequestValidationError)
async def validation_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={
            "error": {
                "code": 422,
                "message": "request validation failed",
                "details": json.loads(json.dumps(exc.errors(), default=str)),
                "path": request.url.path,
            }
        },
    )


@app.exception_handler(Exception)
async def unhandled_handler(request: Request, exc: Exception) -> JSONResponse:
    log.exception(f"unhandled error on {request.url.path}: {exc}")
    return JSONResponse(
        status_code=500,
        content={"error": {"code": 500, "message": "internal server error", "path": request.url.path}},
    )


@app.get("/api/v1/meta", include_in_schema=False)
def meta() -> dict:
    return {
        "name": "Crypto Risk Intelligence Platform",
        "docs": "/api/docs",
        "frontend": "/",
        "data_policy": "public market data only; no fabricated values",
    }


if FRONTEND_DIR.exists():
    app.mount("/", StaticFiles(directory=str(FRONTEND_DIR), html=True), name="frontend")

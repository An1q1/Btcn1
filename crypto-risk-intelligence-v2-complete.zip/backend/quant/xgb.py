"""XGBoost volatility forecasters.

Two feature sets:
- `xgb_har`: exactly the HAR-RV inputs (rv_d, rv_w, rv_m) -> tests whether a
  flexible learner beats OLS on the same information set.
- `xgb_extended`: adds returns, range, semivariance share, jump share, RV term
  structure, volume z-score and cross-market (BTC) RV. Funding/OI are *not*
  included: historical depth from public endpoints is insufficient for a
  leakage-free walk-forward, so they are shown as current context only.
"""
from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd

from backend.core.config import effective_settings

EXT_FEATURE_COLUMNS = [
    "rv", "rv_w", "rv_m",
    "ret_pct", "ret_5", "ret_abs_5", "range_pct",
    "semivar_neg_ratio", "jump_ratio", "rv_ratio", "volume_z", "cross_btc_rv",
]


def xgb_params(overrides: dict[str, Any] | None = None) -> dict[str, Any]:
    s = effective_settings()
    params = {
        "n_estimators": s.xgb_n_estimators,
        "max_depth": s.xgb_max_depth,
        "learning_rate": s.xgb_learning_rate,
        "subsample": 0.8,
        "colsample_bytree": 0.8,
        "min_child_weight": 5,
        "reg_lambda": 1.0,
        "objective": "reg:squarederror",
        "tree_method": "hist",
        "n_jobs": 2,
        "random_state": 42,
        "verbosity": 0,
    }
    if overrides:
        params.update(overrides)
    return params


def fit_xgb(X: pd.DataFrame, y: np.ndarray, params: dict[str, Any] | None = None):
    from xgboost import XGBRegressor

    m = XGBRegressor(**xgb_params(params))
    Xv = X.to_numpy(dtype=float) if hasattr(X, "to_numpy") else np.asarray(X, dtype=float)
    m.fit(Xv, np.asarray(y, dtype=float), verbose=False)
    return m


def predict_xgb(model, X: pd.DataFrame, train_y: np.ndarray) -> np.ndarray:
    """Predict variance with a data-driven positive floor and sanity cap.

    Boosted trees are unconstrained regressors: they can and do emit negative
    values near distribution edges, and a prediction of ~0 makes QLIKE — and any
    risk number derived from it — explode. Variance is strictly positive, so
    predictions are floored at 2 % of the *training* median RV (never below
    1e-3 percent^2/day) and capped at 5x the training maximum. Both bounds use
    only information available at the origin.
    """
    Xv = X.to_numpy(dtype=float) if hasattr(X, "to_numpy") else np.asarray(X, dtype=float)
    pred = np.asarray(model.predict(Xv), dtype=float)
    pred = np.where(np.isfinite(pred), pred, np.nan)
    y = np.asarray(train_y, dtype=float)
    y = y[np.isfinite(y)]
    if y.size:
        floor = max(1e-3, 0.02 * float(np.nanmedian(y)))
        cap = float(np.nanmax(y) * 5)
        fill = float(np.nanmedian(y))
    else:
        floor, cap, fill = 1e-3, np.inf, 1e-3
    pred = np.where(np.isnan(pred), fill, pred)
    return np.clip(pred, floor, cap)


def feature_importance(model, columns: list[str]) -> dict[str, float]:
    try:
        gains = model.feature_importances_.astype(float)
    except Exception:
        return {}
    total = gains.sum() or 1.0
    return {c: round(float(g / total), 4) for c, g in sorted(zip(columns, gains), key=lambda x: -x[1])}

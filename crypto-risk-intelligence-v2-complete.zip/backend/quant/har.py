"""HAR-RV model (Corsi 2009) fitted by OLS.

x_t = b0 + b_d RV_t + b_w mean(RV_{t-4..t}) + b_m mean(RV_{t-21..t}) + e_t
Target: RV_{t+1} (h=1) or the mean daily RV over (t+1..t+h) for direct h-step
forecasts. All inputs are in percent-squared per day.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd


@dataclass
class LinearFit:
    intercept: float
    coefs: np.ndarray
    feature_names: list[str]
    n_obs: int
    r2: float
    residual_std: float
    coef_se: np.ndarray | None = None
    p_values: np.ndarray | None = None
    extra: dict = field(default_factory=dict)

    def predict(self, X: np.ndarray) -> np.ndarray:
        return self.intercept + np.asarray(X, dtype=float) @ self.coefs


def har_design(df: pd.DataFrame) -> tuple[np.ndarray, list[str]]:
    cols = ["rv", "rv_w", "rv_m"]
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise ValueError(f"missing HAR columns: {missing}")
    X = df[cols].to_numpy(dtype=float)
    return X, cols


def fit_ols(X: np.ndarray, y: np.ndarray, feature_names: list[str]) -> LinearFit:
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    mask = np.isfinite(y) & np.isfinite(X).all(axis=1)
    X, y = X[mask], y[mask]
    if X.shape[0] < len(feature_names) + 5:
        raise ValueError(f"insufficient observations for OLS: {X.shape[0]}")
    A = np.column_stack([np.ones(X.shape[0]), X])
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    resid = y - A @ coef
    dof = max(1, X.shape[0] - A.shape[1])
    sigma2 = float(resid @ resid) / dof
    try:
        cov = sigma2 * np.linalg.inv(A.T @ A)
        se = np.sqrt(np.clip(np.diag(cov), 0, None))
        with np.errstate(divide="ignore", invalid="ignore"):
            tstat = coef / se
        from scipy import stats

        pvals = 2 * (1 - stats.t.cdf(np.abs(tstat), dof))
    except np.linalg.LinAlgError:
        se, pvals = None, None
    ss_tot = float(((y - y.mean()) ** 2).sum())
    r2 = 1.0 - float((resid**2).sum()) / ss_tot if ss_tot > 0 else float("nan")
    return LinearFit(
        intercept=float(coef[0]),
        coefs=coef[1:],
        feature_names=feature_names,
        n_obs=int(X.shape[0]),
        r2=r2,
        residual_std=float(np.sqrt(sigma2)),
        coef_se=None if se is None else se[1:],
        p_values=None if pvals is None else pvals[1:],
    )


def fit_har(df: pd.DataFrame, target: pd.Series | np.ndarray) -> LinearFit:
    X, names = har_design(df)
    return fit_ols(X, np.asarray(target, dtype=float), names)


def clip_predictions(pred: np.ndarray, train_y: np.ndarray, floor: float = 1e-6) -> np.ndarray:
    """Keep variance forecasts strictly positive and within a sane envelope.

    The cap (5x the training maximum) only guards against pathological OLS
    extrapolation; it does not use future information.
    """
    y = np.asarray(train_y, dtype=float)
    y = y[np.isfinite(y)]
    cap = float(np.nanmax(y) * 5) if y.size else np.inf
    return np.clip(np.asarray(pred, dtype=float), floor, cap)

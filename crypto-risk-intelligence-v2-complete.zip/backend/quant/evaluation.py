"""Forecast evaluation: RMSE/MAE/QLIKE, Diebold-Mariano tests, regime splits."""
from __future__ import annotations

import uuid
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sqlalchemy import delete, select, text

from backend.core.db import dumps, get_engine, session_scope
from backend.core.logging import get_logger
from backend.core.models import BacktestResult, Forecast, Market, ModelRun

log = get_logger("evaluation")

EPS = 1e-10


def rmse(actual: np.ndarray, pred: np.ndarray) -> float:
    a, p = _clean(actual, pred)
    if a.size == 0:
        return float("nan")
    return float(np.sqrt(np.mean((a - p) ** 2)))


def mae(actual: np.ndarray, pred: np.ndarray) -> float:
    a, p = _clean(actual, pred)
    if a.size == 0:
        return float("nan")
    return float(np.mean(np.abs(a - p)))


def qlike(actual: np.ndarray, pred: np.ndarray) -> float:
    """QLIKE loss (positive, lower is better): a/p - ln(a/p) - 1.

    `actual` is the realized-variance proxy and `pred` the variance forecast,
    both in percent^2 per day. QLIKE is scale-free and robust to noise in the
    variance proxy, which is why it is the primary ranking criterion here.
    """
    a, p = _clean(actual, pred)
    if a.size == 0:
        return float("nan")
    a = np.clip(a, EPS, None)
    p = np.clip(p, EPS, None)
    ratio = a / p
    return float(np.mean(ratio - np.log(ratio) - 1.0))


def bias(actual: np.ndarray, pred: np.ndarray) -> float:
    a, p = _clean(actual, pred)
    return float(np.mean(p - a)) if a.size else float("nan")


def _clean(actual: np.ndarray, pred: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    a = np.asarray(actual, dtype=float)
    p = np.asarray(pred, dtype=float)
    m = np.isfinite(a) & np.isfinite(p) & (a > 0) & (p > 0)
    return a[m], p[m]


def qlike_losses(actual: np.ndarray, pred: np.ndarray) -> np.ndarray:
    a = np.clip(np.asarray(actual, dtype=float), EPS, None)
    p = np.clip(np.asarray(pred, dtype=float), EPS, None)
    r = a / p
    return r - np.log(r) - 1.0


def diebold_mariano(loss_a: np.ndarray, loss_b: np.ndarray, horizon: int = 1) -> tuple[float, float]:
    """DM test with Newey-West HAC variance (overlapping horizons) and the
    Harvey-Leybourne-Newbold small-sample correction.

    d_t = loss_a - loss_b. Negative DM favours model A (lower loss).
    Returns (statistic, two-sided p-value).
    """
    d = np.asarray(loss_a, dtype=float) - np.asarray(loss_b, dtype=float)
    d = d[np.isfinite(d)]
    n = d.size
    if n < 10:
        return float("nan"), float("nan")
    dbar = float(d.mean())
    dc = d - dbar
    gamma0 = float(np.mean(dc**2))
    var = gamma0
    for k in range(1, min(horizon, n - 1)):
        gk = float(np.mean(dc[k:] * dc[:-k]))
        var += 2 * (1 - k / horizon) * gk
    if var <= 0:
        # identical loss series: no differential, cannot reject equality
        return 0.0, 1.0
    dm = dbar / np.sqrt(var / n)
    hln = np.sqrt((n + 1 - 2 * horizon + horizon * (horizon - 1) / n) / n)
    stat = float(dm * hln)
    p = float(2 * (1 - stats.norm.cdf(abs(stat))))
    return stat, p


def model_metric_rows(actual: np.ndarray, pred: np.ndarray) -> dict[str, float]:
    return {
        "rmse": rmse(actual, pred),
        "mae": mae(actual, pred),
        "qlike": qlike(actual, pred),
        "bias": bias(actual, pred),
    }


def _load_forecast_df(run_id: str | None = None) -> pd.DataFrame:
    with session_scope() as ses:
        q = select(Forecast)
        if run_id:
            q = q.where(Forecast.run_id == run_id)
        rows = ses.execute(q).scalars().all()
        records = [
            {
                "exchange": r.exchange_code,
                "symbol": r.symbol,
                "model": r.model_name,
                "horizon": r.horizon,
                "bar_date": r.bar_date,
                "pred": r.predicted_rv,
                "actual": r.actual_rv,
                "run_id": r.run_id,
                "forecast_ts": r.forecast_ts,
            }
            for r in rows
        ]
    df = pd.DataFrame(records)
    if df.empty:
        return df
    # Forecasts are append-only; evaluation uses the newest stored forecast for
    # each (market, model, horizon, origin) so re-runs do not double-count.
    df = df.sort_values("forecast_ts").drop_duplicates(
        ["exchange", "symbol", "model", "horizon", "bar_date"], keep="last"
    )
    return df.sort_values(["exchange", "symbol", "horizon", "model", "bar_date"])


def _load_rv_series(exchange: str, symbol: str) -> pd.Series:
    """Daily RV at each origin, used to label regimes *without* look-ahead."""
    sql = text(
        """
        SELECT bar_date, rv FROM engineered_features
        WHERE exchange_code = :e AND symbol = :s ORDER BY bar_date
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"e": exchange, "s": symbol}).mappings().all()
    if not rows:
        return pd.Series(dtype=float)
    return pd.Series({r["bar_date"]: r["rv"] for r in rows}, dtype=float)


def run_evaluation(run_id: str | None = None, store: bool = True) -> dict[str, Any]:
    df = _load_forecast_df(run_id)
    if df.empty:
        return {"status": "no_forecasts"}
    df = df[df["actual"].notna()]
    eval_run = f"eval-{uuid.uuid4().hex[:10]}"
    rows: list[dict[str, Any]] = []
    pairwise: list[dict[str, Any]] = []

    for (ex, sym, h), grp in df.groupby(["exchange", "symbol", "horizon"]):
        models = sorted(grp["model"].unique())
        wide = grp.pivot_table(index="bar_date", columns="model", values="pred", aggfunc="last")
        actual = grp.groupby("bar_date")["actual"].last()
        idx = wide.index.intersection(actual.index)
        if len(idx) < 20:
            continue
        wide = wide.loc[idx]
        act = actual.loc[idx].to_numpy()
        for m in models:
            if m not in wide.columns:
                continue
            p = wide[m].to_numpy()
            mask = np.isfinite(p) & np.isfinite(act)
            if mask.sum() < 20:
                continue
            metrics = model_metric_rows(act[mask], p[mask])
            for metric, value in metrics.items():
                rows.append({
                    "run_id": eval_run, "scope": "asset", "exchange_code": ex, "symbol": sym,
                    "horizon": int(h), "model_name": m, "metric": metric, "value": value,
                    "n_obs": int(mask.sum()), "config_json": dumps({"bar_date_start": str(idx[0]), "bar_date_end": str(idx[-1])}),
                })
            # Diebold-Mariano against HAR-RV and against the naive random walk
            for base in ("har_rv", "naive"):
                if base not in wide.columns or base == m:
                    continue
                pb = wide[base].to_numpy()
                mask_b = mask & np.isfinite(pb) & (pb > 0)
                if mask_b.sum() < 20:
                    continue
                stat, pval = diebold_mariano(
                    qlike_losses(act[mask_b], p[mask_b]),
                    qlike_losses(act[mask_b], pb[mask_b]),
                    horizon=int(h),
                )
                pairwise.append({
                    "run_id": eval_run, "scope": "dm_test", "exchange_code": ex, "symbol": sym,
                    "horizon": int(h), "model_name": m, "metric": f"dm_qlike_vs_{base}",
                    "value": stat, "p_value": pval, "n_obs": int(mask_b.sum()),
                    "config_json": dumps({"loss": "qlike"}),
                })
        # Volatility regime at each origin from trailing RV quantiles known at the
        # origin (180 observations, min 60). Using the realized target to label
        # regimes would leak the outcome into the stratification.
        rv_hist = _load_rv_series(ex, sym)
        rv_origin = rv_hist.reindex(idx) if not rv_hist.empty else pd.Series(index=idx, dtype=float)
        q50 = rv_origin.rolling(180, min_periods=60).quantile(0.50)
        q80 = rv_origin.rolling(180, min_periods=60).quantile(0.80)
        q95 = rv_origin.rolling(180, min_periods=60).quantile(0.95)
        regime = np.where(
            rv_origin.isna() | q50.isna(), "insufficient_data",
            np.where(rv_origin >= q95, "extreme",
                     np.where(rv_origin >= q80, "high",
                              np.where(rv_origin >= q50, "normal", "low"))),
        )
        for m in models:
            if m not in wide.columns:
                continue
            p = wide[m].to_numpy()
            for reg in ("low", "normal", "high", "extreme"):
                mask = (regime == reg) & np.isfinite(p) & np.isfinite(act)
                if mask.sum() < 8:
                    continue
                rows.append({
                    "run_id": eval_run, "scope": "asset", "exchange_code": ex, "symbol": sym,
                    "horizon": int(h), "model_name": m, "metric": f"rmse_regime_{reg}",
                    "value": rmse(act[mask], p[mask]), "n_obs": int(mask.sum()),
                    "config_json": dumps({
                        "regime_definition": "trailing 180d RV quantiles at the forecast origin (p50/p80/p95)"
                    }),
                })

    # Cross-asset aggregates
    agg = pd.DataFrame(rows)
    if not agg.empty:
        for (h, m, metric), g in agg.groupby(["horizon", "model_name", "metric"]):
            if metric not in ("rmse", "mae", "qlike"):
                continue
            rows.append({
                "run_id": eval_run, "scope": "aggregate", "exchange_code": None, "symbol": None,
                "horizon": int(h), "model_name": m, "metric": f"{metric}_mean",
                "value": float(np.nanmean(g["value"])), "n_obs": int(g["n_obs"].sum()),
                "config_json": dumps({"aggregation": "unweighted mean across markets"}),
            })
            rows.append({
                "run_id": eval_run, "scope": "aggregate", "exchange_code": None, "symbol": None,
                "horizon": int(h), "model_name": m, "metric": f"{metric}_median",
                "value": float(np.nanmedian(g["value"])), "n_obs": int(g["n_obs"].sum()),
                "config_json": dumps({"aggregation": "median across markets"}),
            })

    if store and rows:
        with session_scope() as ses:
            ses.execute(delete(BacktestResult).where(BacktestResult.run_id == eval_run))
            all_rows = rows + pairwise
            for i in range(0, len(all_rows), 400):
                part = all_rows[i : i + 400]
                if part:
                    ses.bulk_insert_mappings(BacktestResult, part)
            ses.add(
                ModelRun(
                    id=eval_run, kind="evaluation", status="success",
                    finished_at=pd.Timestamp.utcnow().to_pydatetime(),
                    scope_json=dumps({"forecast_run": run_id}),
                    metrics_json=dumps({
                        "metric_rows": len(rows), "dm_rows": len(pairwise),
                        "markets": int(df.groupby(["exchange", "symbol"]).ngroups),
                    }),
                )
            )
    summary = _summarize(rows)
    return {"run_id": eval_run, "rows": len(rows), "dm_rows": len(pairwise), "summary": summary}


def _summarize(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    agg = pd.DataFrame([r for r in rows if r["scope"] == "asset" and r["metric"] in ("rmse", "qlike", "mae")])
    if agg.empty:
        return []
    out = []
    for (h, metric), g in agg.groupby(["horizon", "metric"]):
        best = g.groupby("model_name")["value"].mean().sort_values()
        out.append({
            "horizon": int(h), "metric": metric,
            "ranking": [{"model": k, "mean": round(float(v), 6)} for k, v in best.items()],
        })
    return out


def latest_eval_run() -> str | None:
    with session_scope() as ses:
        row = ses.execute(
            select(BacktestResult.run_id).where(BacktestResult.scope == "aggregate").order_by(BacktestResult.created_at.desc())
        ).first()
    return row[0] if row else None

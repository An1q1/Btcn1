"""Walk-forward volatility forecasting with strict purging.

Design (anti-leakage):
- Forecast origin t uses features computed from data up to the close of day t.
- Direct h-step targets use RV over (t+1 .. t+h). Training samples therefore
  require i + h <= t, i.e. the training target window is purged by h-1 days
  before the origin. Skipping this purge is the most common multi-step leakage.
- Models are refit on an expanding window every `refit_every` origins; between
  refits the *same* fitted model is applied to new features.
- Every prediction stores origin date, data cutoff, target window, config and
  the run id. Nothing is overwritten.
"""
from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd
from sqlalchemy import func, select, update

from backend.core.config import effective_settings
from backend.core.db import dumps, session_scope
from backend.core.logging import get_logger
from backend.core.models import Forecast, Market, ModelRegistry, ModelRun, RealizedTarget
from backend.features.pipeline import load_feature_frame
from backend.features.rv import annualized_vol_from_rv, make_target
from backend.quant.garch import fit_garch
from backend.quant.har import clip_predictions, fit_ols
from backend.quant.xgb import EXT_FEATURE_COLUMNS, feature_importance, fit_xgb, predict_xgb

log = get_logger("walkforward")

MODELS = ("naive", "har_rv", "garch_normal", "garch_t", "xgb_har", "xgb_extended")
MODEL_VERSIONS = {m: "1.0.0" for m in MODELS}
MODEL_FAMILIES = {
    "naive": "benchmark", "har_rv": "econometric", "garch_normal": "econometric",
    "garch_t": "econometric", "xgb_har": "machine_learning", "xgb_extended": "machine_learning",
}
TARGET_DEFINITION = (
    "target_rv(t,h) = mean(RV_{t+1..t+h}); RV = sum of squared 4h/6h log returns "
    "within the UTC day, returns in percent -> RV in percent^2 per day"
)


def register_models() -> None:
    with session_scope() as ses:
        for m in MODELS:
            exists = ses.execute(select(ModelRegistry).where(ModelRegistry.name == m, ModelRegistry.version == MODEL_VERSIONS[m])).scalars().first()
            if exists:
                continue
            ses.add(
                ModelRegistry(
                    name=m, version=MODEL_VERSIONS[m], family=MODEL_FAMILIES[m],
                    description={
                        "naive": "Random-walk variance: RV_{t+1..t+h} forecast = RV_t",
                        "har_rv": "HAR-RV (Corsi 2009), OLS on RV_d, RV_w(5), RV_m(22)",
                        "garch_normal": "GARCH(1,1) with constant mean and Normal innovations",
                        "garch_t": "GARCH(1,1) with constant mean and standardized Student-t innovations",
                        "xgb_har": "XGBoost on the HAR information set (rv_d, rv_w, rv_m)",
                        "xgb_extended": "XGBoost on HAR + returns, range, semivariance, jumps, volume z, BTC RV",
                    }[m],
                    params_json=dumps({"features": list(EXT_FEATURE_COLUMNS) if m == "xgb_extended" else ["rv", "rv_w", "rv_m"]}),
                    target_definition=TARGET_DEFINITION,
                    status="active",
                )
            )


def _prepare(exchange: str, symbol: str) -> pd.DataFrame:
    df = load_feature_frame(exchange, symbol)
    if df.empty:
        return df
    df = df.dropna(subset=["rv", "rv_w", "rv_m"]).reset_index(drop=True)
    for c in EXT_FEATURE_COLUMNS:
        if c not in df.columns:
            df[c] = np.nan
    return df


def backfill_actuals() -> int:
    """Attach realized outcomes to past forecasts (never modifies predictions)."""
    updated = 0
    with session_scope() as ses:
        targets = {
            (e, s, d, h): t
            for e, s, d, h, t in ses.execute(
                select(RealizedTarget.exchange_code, RealizedTarget.symbol, RealizedTarget.bar_date,
                       RealizedTarget.horizon, RealizedTarget.target_rv)
            ).all()
        }
        rows = ses.execute(select(Forecast).where(Forecast.actual_rv.is_(None))).scalars().all()
        for r in rows:
            val = targets.get((r.exchange_code, r.symbol, r.bar_date, r.horizon))
            if val is not None:
                r.actual_rv = float(val)
                updated += 1
    return updated


def _forecast_one_market(
    ex: str, sym: str, horizons: list[int], s, run_id: str
) -> dict[str, Any]:
    df = _prepare(ex, sym)
    n = len(df)
    stats: dict[str, Any] = {"market": f"{ex}:{sym}", "rows": 0, "status": "ok", "per_horizon": {}}
    if n < s.walkforward_min_train + 50:
        stats["status"] = "insufficient_history"
        stats["reason"] = f"{n} daily observations < {s.walkforward_min_train + 50}"
        return stats
    X_har = df[["rv", "rv_w", "rv_m"]].to_numpy(float)
    X_ext = df[EXT_FEATURE_COLUMNS].to_numpy(float)
    rv = df["rv"].to_numpy(float)
    rets = df["ret_pct"].to_numpy(float)
    dates = df["bar_date"].astype(str).to_numpy()
    max_test = 360
    out_rows: list[dict[str, Any]] = []
    # GARCH fits depend only on the return history through origin t, not on the
    # horizon, so they are computed once and shared across horizons.
    garch_cache: dict[int, tuple[Any, Any]] = {}
    garch_last_refit: int | None = None
    garch_fits: tuple[Any, Any] = (None, None)

    def garch_at(t: int) -> tuple[Any, Any]:
        nonlocal garch_last_refit, garch_fits
        if t in garch_cache:
            return garch_cache[t]
        if garch_last_refit is None or (t - garch_last_refit) >= s.walkforward_refit_every:
            ret_train = rets[: t + 1]
            garch_fits = (fit_garch(ret_train, "normal", s.garch_min_obs),
                          fit_garch(ret_train, "t", s.garch_min_obs))
            garch_last_refit = t
        garch_cache[t] = garch_fits
        return garch_fits

    for h in horizons:
        y = make_target(df["rv"], h, "mean").to_numpy(float)
        first_origin = max(s.walkforward_min_train + h - 1, n - 1 - max_test)
        origins = [t for t in range(first_origin, n)]
        if not origins:
            continue
        xgb_h = xgb_e = None
        har_fit = None
        n_done = 0
        for step, t in enumerate(origins):
            train_end = t - h + 1          # purge h-1 overlapping target days
            if train_end < s.walkforward_min_train:
                continue
            y_tr = y[:train_end]
            mask = np.isfinite(y_tr)
            if mask.sum() < s.walkforward_min_train:
                continue
            if step % s.walkforward_refit_every == 0:
                har_fit = fit_ols(X_har[:train_end][mask], y_tr[mask], ["rv", "rv_w", "rv_m"])
                xgb_h = fit_xgb(X_har[:train_end][mask], y_tr[mask])
                xgb_e = fit_xgb(X_ext[:train_end][mask], y_tr[mask])
            garch_n, garch_t = garch_at(t)
            if har_fit is None:
                continue
            cutoff_ts = int(pd.Timestamp(dates[t], tz="UTC").timestamp() * 1000)
            target_start = dates[t + 1] if t + 1 < n else None
            target_end = dates[min(t + h, n - 1)]
            base = {
                "exchange_code": ex, "symbol": sym, "horizon": int(h), "bar_date": dates[t],
                "forecast_ts": datetime.now(timezone.utc), "data_cutoff_ts": cutoff_ts,
                "target_start_date": target_start or dates[t], "target_end_date": target_end,
                "data_quality": "ok" if np.isfinite(rv[t]) else "missing_rv",
                "run_id": run_id,
            }
            actual = float(y[t]) if np.isfinite(y[t]) else None
            preds: dict[str, tuple[float, str]] = {}

            preds["naive"] = (float(rv[t]), dumps({"rule": "RV_t"}))
            p_har = clip_predictions(har_fit.predict(X_har[t : t + 1]), y_tr[mask])[0]
            preds["har_rv"] = (
                float(p_har),
                dumps({
                    "features": ["rv", "rv_w", "rv_m"],
                    "coef": [round(float(c), 6) for c in har_fit.coefs],
                    "intercept": round(har_fit.intercept, 6),
                    "train_obs": int(mask.sum()),
                }),
            )
            for name, fit in (("garch_normal", garch_n), ("garch_t", garch_t)):
                if fit is not None:
                    preds[name] = (
                        float(fit.forecast_target(h)),
                        dumps({
                            "mu": round(fit.mu, 6), "omega": round(fit.omega, 8),
                            "alpha": round(fit.alpha, 6), "beta": round(fit.beta, 6),
                            "persistence": round(fit.alpha + fit.beta, 6), "dist": fit.dist,
                            "train_obs": fit.n_obs,
                        }),
                    )
            if xgb_h is not None:
                ph = predict_xgb(xgb_h, X_har[t : t + 1], y_tr[mask])[0]
                preds["xgb_har"] = (float(ph), dumps({"features": ["rv", "rv_w", "rv_m"]}))
            if xgb_e is not None:
                pe = predict_xgb(xgb_e, X_ext[t : t + 1], y_tr[mask])[0]
                preds["xgb_extended"] = (float(pe), dumps({
                    "features": EXT_FEATURE_COLUMNS,
                    "importance": feature_importance(xgb_e, EXT_FEATURE_COLUMNS),
                }))
            for model, (pred, cfg) in preds.items():
                if not np.isfinite(pred) or pred <= 0:
                    continue
                out_rows.append({
                    **base,
                    "model_name": model,
                    "model_version": MODEL_VERSIONS[model],
                    "predicted_rv": float(pred),
                    "predicted_vol_annualized": float(annualized_vol_from_rv(pred)),
                    "actual_rv": actual,
                    "config_json": cfg,
                })
            n_done += 1
        stats["per_horizon"][str(h)] = n_done

    if out_rows:
        with session_scope() as ses:
            for i in range(0, len(out_rows), 600):
                ses.bulk_insert_mappings(Forecast, out_rows[i : i + 600])
        stats["rows"] = len(out_rows)
        stats["models"] = sorted({r["model_name"] for r in out_rows})
    else:
        stats["status"] = "no_forecasts"
    return stats


def run_forecast_pipeline(
    market_limit: int | None = None,
    horizons: list[int] | None = None,
    only_markets: list[str] | None = None,
) -> dict[str, Any]:
    """Run the walk-forward forecast for the model-eligible universe.

    `only_markets` (list of "exchange:symbol") restricts the run to markets that
    are not yet covered, so a top-up run does not duplicate an existing log.
    """
    s = effective_settings()
    horizons = horizons or s.horizon_list
    register_models()
    run_id = f"fc-{uuid.uuid4().hex[:10]}"
    started = datetime.now(timezone.utc)
    with session_scope() as ses:
        ses.add(ModelRun(id=run_id, kind="forecast", status="running", started_at=started,
                         scope_json=dumps({
                             "horizons": horizons, "market_limit": market_limit,
                             "only_markets": only_markets,
                         })))
        markets = ses.execute(
            select(Market).where(Market.in_universe.is_(True), Market.model_eligible.is_(True))
            .order_by(Market.quote_volume_24h.desc())
        ).scalars().all()
        targets = [(m.exchange_code, m.symbol, m.quote_volume_24h or 0) for m in markets]
    targets.sort(key=lambda x: x[2], reverse=True)
    if only_markets is not None:
        wanted = {m.strip() for m in only_markets}
        targets = [t for t in targets if f"{t[0]}:{t[1]}" in wanted]
    if market_limit:
        targets = targets[:market_limit]
    backfilled = backfill_actuals()
    t0 = time.perf_counter()
    stats: list[dict[str, Any]] = []
    total_rows = 0
    for i, (ex, sym, _v) in enumerate(targets, 1):
        try:
            st = _forecast_one_market(ex, sym, horizons, s, run_id)
        except Exception as exc:  # noqa: BLE001
            log.exception(f"forecast failed for {ex}:{sym}: {exc}")
            st = {"market": f"{ex}:{sym}", "status": "error", "error": str(exc)[:300], "rows": 0}
        stats.append(st)
        total_rows += st.get("rows", 0)
        log.info(f"[{i}/{len(targets)}] {ex}:{sym} -> {st.get('rows',0)} forecasts ({st['status']})")
    backfill_actuals()
    elapsed = time.perf_counter() - t0
    counts = pd.Series([st["status"] for st in stats]).value_counts().to_dict() if stats else {}
    with session_scope() as ses:
        run = ses.get(ModelRun, run_id)
        if run:
            run.status = "success"
            run.finished_at = datetime.now(timezone.utc)
            run.metrics_json = dumps({
                "markets": len(targets), "forecast_rows": total_rows,
                "status_counts": counts, "backfilled_actuals": backfilled,
                "elapsed_seconds": round(elapsed, 1),
                "per_market": stats,
            })
    return {
        "run_id": run_id, "markets": len(targets), "forecast_rows": total_rows,
        "elapsed_seconds": round(elapsed, 1), "status_counts": counts,
        "pending": [st for st in stats if st.get("status") != "ok"],
    }


def latest_run_id(kind: str = "forecast") -> str | None:
    with session_scope() as ses:
        row = ses.execute(
            select(ModelRun.id).where(ModelRun.kind == kind, ModelRun.status == "success")
            .order_by(ModelRun.finished_at.desc())
        ).first()
    return row[0] if row else None

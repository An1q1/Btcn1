"""GARCH(1,1) utilities built on `arch`.

Returns are percentages per day. Fitted variance is therefore in percent^2 per
day, exactly the unit of RV. Multi-step forecasts are aggregated to the same
target definition used by HAR/XGBoost: the *mean* conditional variance over
(t+1 .. t+h).
"""
from __future__ import annotations

import warnings
from dataclasses import dataclass, field
from typing import Any

import numpy as np

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)


@dataclass
class GarchFit:
    model_result: Any
    dist: str
    mu: float
    omega: float
    alpha: float
    beta: float
    sigma2_last: float
    resid_last: float
    n_obs: int
    converged: bool
    loglik: float | None = None
    meta: dict = field(default_factory=dict)

    def variance_path(self, horizon: int) -> np.ndarray:
        """Analytic GARCH(1,1) variance path sigma^2_{t+1..t+h} in %^2."""
        path = np.empty(horizon, dtype=float)
        s2 = self.omega + self.alpha * self.resid_last**2 + self.beta * self.sigma2_last
        path[0] = max(s2, 1e-10)
        for k in range(1, horizon):
            s2 = self.omega + (self.alpha + self.beta) * s2
            path[k] = max(s2, 1e-10)
        return path

    def forecast_target(self, horizon: int) -> float:
        return float(np.mean(self.variance_path(horizon)))

    def sigma_next(self) -> float:
        return float(np.sqrt(self.variance_path(1)[0]))

    def standardized_residuals(self) -> np.ndarray:
        r = self.model_result
        vol = np.asarray(r.conditional_volatility, dtype=float)
        resid = np.asarray(r.resid, dtype=float)
        with np.errstate(divide="ignore", invalid="ignore"):
            z = resid / vol
        return z[np.isfinite(z)]


def _check_arch_available() -> None:
    """Kiểm tra thư viện arch có khả dụng; ném lỗi rõ ràng nếu thiếu."""
    try:
        import arch  # noqa: F401
    except ImportError as exc:
        raise ImportError(
            "Thiếu thư viện 'arch' (pip install arch==8.0.0). "
            "GARCH không thể chạy khi thiếu dependency runtime. Vui lòng cài đặt đầy đủ requirements.txt và chạy lại, hoặc kiểm tra Docker build có cài arch."
        ) from exc


def fit_garch(returns: np.ndarray, dist: str = "normal", min_obs: int = 250) -> GarchFit | None:
    try:
        from arch import arch_model
    except ImportError as exc:
        # Không trả về volatility giả; báo lỗi rõ ràng để caller xử lý
        raise ImportError(
            "Thư viện 'arch' chưa được cài đặt — không thể khớp mô hình GARCH. "
            "Cài đặt: pip install -r requirements.txt (arch==8.0.0) hoặc kiểm tra Dockerfile."
        ) from exc

    y = np.asarray(returns, dtype=float)
    y = y[np.isfinite(y)]
    if y.size < min_obs:
        return None
    # A constant mean is estimated; zero-variance series are rejected.
    if np.std(y) < 1e-8:
        return None
    model = arch_model(y, mean="Constant", vol="Garch", p=1, q=1, dist=dist, rescale=False)
    try:
        res = model.fit(disp="off", show_warning=False)
    except Exception:
        try:
            res = model.fit(disp="off", show_warning=False, starting_values=[np.var(y), 0.05, 0.9, 0.0])
        except Exception:
            return None
    names = {str(k): float(v) for k, v in dict(res.params).items()}
    # arch names GARCH(1,1) parameters exactly as mu/omega/alpha[1]/beta[1].
    omega = names.get("omega", names.get("Omega", float("nan")))
    alpha = names.get("alpha[1]", names.get("alpha", 0.0))
    beta = names.get("beta[1]", names.get("beta", 0.0))
    mu = names.get("mu", names.get("Const", names.get("const", 0.0)))
    if not np.isfinite([omega, alpha, beta, mu]).all() or omega <= 0:
        return None
    converged = bool(getattr(res, "convergence_flag", 1) == 0)
    if not converged:
        # Non-converged fits are rejected: they must not seed VaR estimates.
        return None
    sigma2 = float(np.asarray(res.conditional_volatility)[-1] ** 2)
    resid_last = float(np.asarray(res.resid)[-1])
    return GarchFit(
        model_result=res,
        dist=dist,
        mu=mu,
        omega=omega,
        alpha=alpha,
        beta=beta,
        sigma2_last=sigma2,
        resid_last=resid_last,
        n_obs=int(y.size),
        converged=converged,
        loglik=float(getattr(res, "loglikelihood", np.nan)),
        meta={"persistence": alpha + beta, "aic": float(getattr(res, "aic", np.nan))},
    )


def garch_volatility_forecast(returns: np.ndarray, horizon: int = 1, dist: str = "t") -> dict[str, float]:
    """Convenience helper used by unit tests and the API."""
    fit = fit_garch(returns, dist=dist)
    if fit is None:
        return {"sigma": float("nan"), "target_rv": float("nan")}
    return {
        "sigma": fit.sigma_next(),
        "target_rv": fit.forecast_target(horizon),
        "mu": fit.mu,
        "persistence": fit.alpha + fit.beta,
    }

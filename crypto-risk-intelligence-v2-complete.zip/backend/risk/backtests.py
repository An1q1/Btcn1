"""VaR/ES backtests.

- Kupiec (1995) unconditional coverage (POF).
- Christoffersen (1998) independence and conditional coverage.
- ES backtest: exceedance-ratio test restricted to breach days, with a
  bootstrap confidence interval (documented; not labelled as Acerbi-Szekely).
- Quantile (tick) loss as a scoring rule.

All losses are positive percentages. A breach is L_t > VaR_t.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy import stats


@dataclass
class CoverageResult:
    n_obs: int
    n_breaches: int
    expected_breaches: float
    breach_rate: float
    kupiec_lr: float
    kupiec_pvalue: float
    christoffersen_ind_lr: float | None
    christoffersen_ind_pvalue: float | None
    christoffersen_cc_lr: float | None
    christoffersen_cc_pvalue: float | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "n_obs": self.n_obs, "n_breaches": self.n_breaches,
            "expected_breaches": round(self.expected_breaches, 3),
            "breach_rate": round(self.breach_rate, 6),
            "kupiec_lr": self.kupiec_lr, "kupiec_pvalue": self.kupiec_pvalue,
            "christoffersen_ind_lr": self.christoffersen_ind_lr,
            "christoffersen_ind_pvalue": self.christoffersen_ind_pvalue,
            "christoffersen_cc_lr": self.christoffersen_cc_lr,
            "christoffersen_cc_pvalue": self.christoffersen_cc_pvalue,
        }


def kupiec_pof(breaches: np.ndarray, confidence: float) -> tuple[float, float]:
    x = np.asarray(breaches, dtype=bool).astype(int)
    n = int(x.size)
    k = int(x.sum())
    p = 1.0 - confidence
    if n == 0:
        return float("nan"), float("nan")
    if k == 0:
        lr = -2.0 * (n * np.log(1 - p))
    elif k == n:
        lr = -2.0 * (n * np.log(p))
    else:
        pi = k / n
        ll_null = (n - k) * np.log(1 - p) + k * np.log(p)
        ll_alt = (n - k) * np.log(1 - pi) + k * np.log(pi)
        lr = -2.0 * (ll_null - ll_alt)
    lr = max(lr, 0.0)
    return float(lr), float(1 - stats.chi2.cdf(lr, df=1))


def christoffersen_independence(breaches: np.ndarray) -> tuple[float, float] | tuple[None, None]:
    x = np.asarray(breaches, dtype=bool).astype(int)
    if x.size < 10:
        return None, None
    prev, cur = x[:-1], x[1:]
    n00 = int(((prev == 0) & (cur == 0)).sum())
    n01 = int(((prev == 0) & (cur == 1)).sum())
    n10 = int(((prev == 1) & (cur == 0)).sum())
    n11 = int(((prev == 1) & (cur == 1)).sum())
    denom1, denom2 = n00 + n01, n10 + n11
    if denom1 == 0 or denom2 == 0:
        return None, None
    pi01 = n01 / denom1
    pi11 = n11 / denom2
    pi = (n01 + n11) / (denom1 + denom2)
    def ll(k, p):
        if p <= 0 or p >= 1:
            return 0.0
        return k * np.log(p)
    ll_ind = ll(n01, pi01) + ll(n00, 1 - pi01) + ll(n11, pi11) + ll(n10, 1 - pi11)
    ll_hom = ll(n01 + n11, pi) + ll(n00 + n10, 1 - pi)
    lr = max(-2.0 * (ll_hom - ll_ind), 0.0)
    return float(lr), float(1 - stats.chi2.cdf(lr, df=1))


def coverage_tests(losses: np.ndarray, var: np.ndarray, confidence: float) -> CoverageResult | None:
    l = np.asarray(losses, dtype=float)
    v = np.asarray(var, dtype=float)
    mask = np.isfinite(l) & np.isfinite(v)
    l, v = l[mask], v[mask]
    if l.size < 20:
        return None
    br = (l > v).astype(int)
    lr_uc, p_uc = kupiec_pof(br, confidence)
    lr_ind, p_ind = christoffersen_independence(br)
    if lr_ind is not None:
        lr_cc = lr_uc + lr_ind
        p_cc = float(1 - stats.chi2.cdf(lr_cc, df=2))
    else:
        lr_cc, p_cc = None, None
    return CoverageResult(
        n_obs=int(l.size), n_breaches=int(br.sum()),
        expected_breaches=float(l.size * (1 - confidence)),
        breach_rate=float(br.mean()), kupiec_lr=lr_uc, kupiec_pvalue=p_uc,
        christoffersen_ind_lr=lr_ind, christoffersen_ind_pvalue=p_ind,
        christoffersen_cc_lr=lr_cc, christoffersen_cc_pvalue=p_cc,
    )


def es_ratio_test(losses: np.ndarray, var: np.ndarray, es: np.ndarray, n_bootstrap: int = 500, seed: int = 7) -> dict[str, Any]:
    """Compare realized breach losses with predicted ES.

    ratio = mean(L | breach) / mean(ES | breach). Under a correct model ratio~1.
    A two-sided t-test of mean(L-ES|breach)=0 and a bootstrap CI are reported.
    """
    l = np.asarray(losses, dtype=float)
    v = np.asarray(var, dtype=float)
    e = np.asarray(es, dtype=float)
    mask = np.isfinite(l) & np.isfinite(v) & np.isfinite(e)
    l, v, e = l[mask], v[mask], e[mask]
    breach = l > v
    n = int(breach.sum())
    if n < 5:
        return {"n_breaches": n, "status": "insufficient_breaches"}
    excess = l[breach] - e[breach]
    ratio = float(l[breach].mean() / e[breach].mean()) if e[breach].mean() > 0 else float("nan")
    try:
        tstat, pval = stats.ttest_1samp(excess, 0.0)
        tstat, pval = float(tstat), float(pval)
    except Exception:
        tstat, pval = float("nan"), float("nan")
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_bootstrap):
        idx = rng.integers(0, n, n)
        denom = e[breach][idx].mean()
        if denom > 0:
            boots.append(l[breach][idx].mean() / denom)
    lo, hi = (np.percentile(boots, [2.5, 97.5]).tolist() if boots else [None, None])
    return {
        "n_breaches": n, "es_ratio": ratio, "mean_excess_loss": float(excess.mean()),
        "t_stat": tstat, "p_value": pval, "bootstrap_ci_95": [lo, hi], "status": "ok",
    }


def quantile_loss(losses: np.ndarray, var: np.ndarray, confidence: float) -> float:
    """Tick loss for the alpha-quantile: rho(x) = (I{x>VaR} - (1-alpha)) * (x - VaR)."""
    l = np.asarray(losses, dtype=float)
    v = np.asarray(var, dtype=float)
    mask = np.isfinite(l) & np.isfinite(v)
    l, v = l[mask], v[mask]
    if l.size == 0:
        return float("nan")
    alpha = confidence
    return float(np.mean(((l > v).astype(float) - (1 - alpha)) * (l - v)))


def breach_clusters(breaches: np.ndarray) -> dict[str, Any]:
    b = np.asarray(breaches, dtype=bool).astype(int)
    clusters = []
    start = None
    for i, val in enumerate(b):
        if val and start is None:
            start = i
        if not val and start is not None:
            clusters.append((start, i - 1))
            start = None
    if start is not None:
        clusters.append((start, len(b) - 1))
    lengths = [e - s + 1 for s, e in clusters]
    return {
        "n_clusters": len(clusters),
        "max_cluster_length": max(lengths) if lengths else 0,
        "clusters": [{"start_index": int(s), "end_index": int(e), "length": int(e - s + 1)} for s, e in clusters][-25:],
    }

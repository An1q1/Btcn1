"""Extreme Value Theory: Peaks-Over-Threshold with a Generalized Pareto tail.

Applied to GARCH-standardized *loss* residuals (z_loss = -residual/sigma), so
the conditional mean and scale are removed before tail estimation. The resulting
tail quantile q_alpha is mapped back with VaR = -mu + sigma_{t+1} * q_alpha.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
from scipy import stats


@dataclass
class GPDFit:
    threshold: float
    xi: float
    beta: float
    n_total: int
    n_exceed: int
    tail_fraction: float
    method: str
    converged: bool
    mean_excess: float

    @property
    def tail_prob(self) -> float:
        return self.n_exceed / max(self.n_total, 1)

    @property
    def es_finite(self) -> bool:
        return self.xi < 1.0

    def as_dict(self) -> dict[str, Any]:
        return {
            "threshold": self.threshold, "xi": self.xi, "beta": self.beta,
            "n_total": self.n_total, "n_exceed": self.n_exceed,
            "tail_prob": round(self.tail_prob, 6), "tail_fraction": self.tail_fraction,
            "method": self.method, "converged": self.converged,
            "mean_excess": self.mean_excess, "es_finite": self.es_finite,
        }


def select_threshold(losses: np.ndarray, tail_fraction: float = 0.10, min_exceed: int = 25) -> tuple[float, int, float]:
    """Pick a threshold with a target exceedance fraction, raising it until at
    least `min_exceed` observations remain. No future data is used."""
    x = np.asarray(losses, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 50:
        return float("nan"), 0, float("nan")
    frac = tail_fraction
    for _ in range(5):
        u = float(np.quantile(x, 1 - frac))
        n_exc = int((x > u).sum())
        if n_exc >= min_exceed:
            return u, n_exc, frac
        frac *= 1.5
    u = float(np.quantile(x, 1 - frac))
    return u, int((x > u).sum()), frac


def fit_gpd(exceedances: np.ndarray) -> tuple[float, float, bool, str]:
    """MLE first, method-of-moments fallback. Returns (xi, beta, converged, method)."""
    y = np.asarray(exceedances, dtype=float)
    y = y[np.isfinite(y) & (y > 0)]
    if y.size < 10:
        return float("nan"), float("nan"), False, "insufficient_exceedances"
    try:
        xi, loc, beta = stats.genpareto.fit(y, floc=0.0)
        if np.isfinite(xi) and np.isfinite(beta) and beta > 0:
            return float(xi), float(beta), True, "mle"
    except Exception:
        pass
    # method of moments (requires xi < 0.5)
    m, v = float(y.mean()), float(y.var())
    if m > 0 and v > 0:
        xi = 0.5 * (1 - m * m / v)
        beta = 0.5 * m * (m * m / v + 1)
        if beta > 0:
            return float(xi), float(beta), True, "mom_fallback"
    return float("nan"), float("nan"), False, "fit_failed"


def fit_pot(losses: np.ndarray, tail_fraction: float = 0.10, min_exceed: int = 25) -> GPDFit | None:
    x = np.asarray(losses, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 100:
        return None
    u, n_exc, frac = select_threshold(x, tail_fraction, min_exceed)
    if not np.isfinite(u) or n_exc < 10:
        return None
    exc = x[x > u] - u
    xi, beta, converged, method = fit_gpd(exc)
    if not np.isfinite(xi) or not np.isfinite(beta):
        return None
    return GPDFit(
        threshold=u, xi=xi, beta=beta, n_total=int(x.size), n_exceed=int(n_exc),
        tail_fraction=frac, method=method, converged=converged, mean_excess=float(exc.mean()),
    )


def gpd_quantile(fit: GPDFit, confidence: float) -> float:
    """Quantile of the loss distribution at `confidence` (e.g. 0.99)."""
    if fit is None or not np.isfinite(fit.xi) or fit.beta <= 0:
        return float("nan")
    tail_p = 1.0 - confidence
    zeta = fit.tail_prob
    if tail_p >= zeta:  # not in the tail: fall back to empirical threshold
        return float(fit.threshold)
    if abs(fit.xi) < 1e-6:
        return float(fit.threshold + fit.beta * np.log(zeta / tail_p))
    return float(fit.threshold + (fit.beta / fit.xi) * ((tail_p / zeta) ** (-fit.xi) - 1.0))


def gpd_es(fit: GPDFit, confidence: float) -> float | None:
    """Expected shortfall of the loss distribution. Infinite when xi >= 1."""
    if fit is None or fit.xi >= 1.0:
        return None
    var = gpd_quantile(fit, confidence)
    if not np.isfinite(var):
        return None
    if abs(fit.xi) < 1e-6:
        return float(var + fit.beta)
    return float((var + fit.beta - fit.xi * fit.threshold) / (1.0 - fit.xi))


def mean_excess_curve(losses: np.ndarray, quantiles: list[float] | None = None) -> list[dict[str, float]]:
    """Mean-excess diagnostics for threshold stability (plotted in the UI)."""
    x = np.asarray(losses, dtype=float)
    x = np.sort(x[np.isfinite(x)])
    if x.size < 100:
        return []
    qs = quantiles or [0.80, 0.85, 0.90, 0.925, 0.95, 0.96, 0.97, 0.98, 0.99]
    out = []
    for q in qs:
        u = float(np.quantile(x, q))
        exc = x[x > u] - u
        if exc.size < 5:
            continue
        out.append({
            "quantile": q, "threshold": u, "n_exceed": int(exc.size),
            "mean_excess": float(exc.mean()),
        })
    return out


def threshold_sensitivity(losses: np.ndarray, confidences: list[float], min_exceed: int = 25) -> list[dict[str, Any]]:
    """Refit GPD at several thresholds and report VaR/ES stability."""
    rows: list[dict[str, Any]] = []
    for frac in (0.05, 0.075, 0.10, 0.15, 0.20, 0.25):
        fit = fit_pot(losses, tail_fraction=frac, min_exceed=min_exceed)
        if fit is None:
            rows.append({"tail_fraction": frac, "status": "insufficient_data"})
            continue
        row: dict[str, Any] = {"tail_fraction": frac, **fit.as_dict()}
        for c in confidences:
            row[f"var_{int(c * 1000)}"] = gpd_quantile(fit, c)
            row[f"es_{int(c * 1000)}"] = gpd_es(fit, c)
        rows.append(row)
    return rows

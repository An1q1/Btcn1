"""Tail-risk engine: Historical VaR, GARCH-Normal, GARCH-Student-t, GARCH-EVT.

Sign convention: returns r are signed percentages; loss L = -r (positive).
VaR_alpha and ES_alpha are reported as positive loss percentages.
Conditional model: r_t = mu + sigma_t z_t, so
    VaR_alpha(L) = -mu + sigma_{t+1} * q_alpha(z_loss)
    ES_alpha(L)  = -mu + sigma_{t+1} * ES_alpha(z_loss)
with q_alpha of the *loss-side* standardized distribution. For symmetric
innovations q_alpha(z_loss) equals the alpha-quantile of z.
"""
from __future__ import annotations

import time
import uuid
from datetime import datetime, timezone
from typing import Any

import numpy as np
import pandas as pd
from scipy import stats
from sqlalchemy import select

from backend.core.config import effective_settings
from backend.core.db import dumps, session_scope, upsert_rows
from backend.core.logging import get_logger
from backend.core.models import BacktestResult, Market, ModelRun, VarEsEstimate
from backend.features.pipeline import load_feature_frame
from backend.quant.garch import GarchFit, fit_garch
from backend.risk.backtests import (
    breach_clusters,
    coverage_tests,
    es_ratio_test,
    quantile_loss,
)
from backend.risk.evt import fit_pot, gpd_es, gpd_quantile, mean_excess_curve, threshold_sensitivity

log = get_logger("risk")

METHODS = ("historical", "garch_normal", "garch_t", "garch_evt")


def normal_var_es(mu: float, sigma: float, confidence: float) -> tuple[float, float]:
    z = stats.norm.ppf(confidence)
    var = -mu + sigma * z
    es = -mu + sigma * stats.norm.pdf(z) / (1 - confidence)
    return float(var), float(es)


def student_t_var_es(mu: float, sigma: float, confidence: float, nu: float) -> tuple[float, float]:
    nu = max(float(nu), 2.5)
    scale = np.sqrt((nu - 2) / nu)
    q = stats.t.ppf(confidence, nu)
    var = -mu + sigma * q * scale
    es_raw = stats.t.pdf(q, nu) * (nu + q**2) / ((nu - 1) * (1 - confidence))
    es = -mu + sigma * es_raw * scale
    return float(var), float(es)


def historical_var_es(losses: np.ndarray, confidence: float) -> tuple[float | None, float | None]:
    x = np.asarray(losses, dtype=float)
    x = x[np.isfinite(x)]
    if x.size < 50:
        return None, None
    var = float(np.quantile(x, confidence))
    tail = x[x >= var]
    es = float(tail.mean()) if tail.size >= 3 else None
    return var, es


def garch_evt_var_es(fit: GarchFit, confidence: float, tail_fraction: float, min_exceed: int) -> dict[str, Any]:
    z = fit.standardized_residuals()
    z_loss = -z  # positive loss side
    pot = fit_pot(z_loss, tail_fraction=tail_fraction, min_exceed=min_exceed)
    if pot is None:
        return {"status": "gpd_fit_failed"}
    q = gpd_quantile(pot, confidence)
    es_q = gpd_es(pot, confidence)
    sigma = fit.sigma_next()
    return {
        "status": "ok",
        "var": -fit.mu + sigma * q,
        "es": None if es_q is None else -fit.mu + sigma * es_q,
        "threshold": pot.threshold,
        "xi": pot.xi,
        "beta": pot.beta,
        "n_exceed": pot.n_exceed,
        "meta": pot.as_dict(),
    }


def _risk_rows_for_market(
    ex: str, sym: str, df: pd.DataFrame, s, run_id: str
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    rets = df["ret_pct"].to_numpy(float)
    dates = df["bar_date"].astype(str).to_numpy()
    n = len(df)
    if n < s.risk_min_train + 30:
        return [], {"market": f"{ex}:{sym}", "status": "insufficient_history", "n": n}
    window = 500
    rows: list[dict[str, Any]] = []
    fit_n: GarchFit | None = None
    fit_t: GarchFit | None = None
    latest_fits: dict[str, Any] = {}
    start = max(s.risk_min_train, 250, n - 1 - 320)
    steps = 0
    for t in range(start - 1, n - 1):
        if steps % s.risk_refit_every == 0:
            ret_train = rets[: t + 1]
            fit_n = fit_garch(ret_train, "normal", s.garch_min_obs)
            fit_t = fit_garch(ret_train, "t", s.garch_min_obs)
            latest_fits = {"normal": fit_n, "t": fit_t}
        actual_loss = float(-rets[t + 1]) if np.isfinite(rets[t + 1]) else None
        hist = -rets[max(0, t + 1 - window) : t + 1]
        hist = hist[np.isfinite(hist)]
        sigma_n = fit_n.sigma_next() if fit_n else None
        sigma_t = fit_t.sigma_next() if fit_t else None
        for conf in s.confidence_list:
            est: dict[str, dict[str, Any]] = {}
            hv, he = historical_var_es(hist, conf)
            est["historical"] = {"var": hv, "es": he, "meta": {"window": int(min(window, hist.size))}}
            if fit_n is not None and sigma_n:
                v, e = normal_var_es(fit_n.mu, sigma_n, conf)
                est["garch_normal"] = {"var": v, "es": e, "sigma": sigma_n, "mu": fit_n.mu,
                                       "meta": {"persistence": round(fit_n.alpha + fit_n.beta, 6)}}
            if fit_t is not None and sigma_t:
                nu = float(dict(fit_t.model_result.params).get("nu", 8.0))
                v, e = student_t_var_es(fit_t.mu, sigma_t, conf, nu)
                est["garch_t"] = {"var": v, "es": e, "sigma": sigma_t, "mu": fit_t.mu,
                                  "meta": {"nu": round(nu, 3), "persistence": round(fit_t.alpha + fit_t.beta, 6)}}
            if fit_n is not None:
                evt = garch_evt_var_es(fit_n, conf, s.evt_tail_fraction, s.evt_min_exceedances)
                if evt.get("status") == "ok":
                    est["garch_evt"] = {
                        "var": evt["var"], "es": evt["es"], "sigma": sigma_n, "mu": fit_n.mu,
                        "threshold": evt["threshold"], "xi": evt["xi"], "beta": evt["beta"],
                        "n_exceed": evt["n_exceed"], "meta": evt["meta"],
                    }
            for method, payload in est.items():
                var = payload.get("var")
                if var is None or not np.isfinite(var):
                    continue
                rows.append({
                    "exchange_code": ex, "symbol": sym, "asof_date": dates[t], "model_name": method,
                    "confidence": float(conf), "horizon_days": 1,
                    "var_pct": float(var), "es_pct": (None if payload.get("es") is None else float(payload["es"])),
                    "mu": payload.get("mu"), "sigma": payload.get("sigma"),
                    "threshold": payload.get("threshold"), "xi": payload.get("xi"), "beta": payload.get("beta"),
                    "n_exceedances": payload.get("n_exceed"),
                    "method_meta": dumps(payload.get("meta", {})),
                    "actual_loss_pct": actual_loss,
                    "breach": (None if actual_loss is None else bool(actual_loss > var)),
                    "created_at": datetime.now(timezone.utc),
                })
        steps += 1
    # threshold sensitivity at the latest origin (diagnostic, stored separately)
    sensitivity = []
    if latest_fits.get("normal") is not None:
        z_loss = -latest_fits["normal"].standardized_residuals()
        sensitivity = threshold_sensitivity(z_loss, s.confidence_list, s.evt_min_exceedances)
    diag = {
        "market": f"{ex}:{sym}", "status": "ok", "rows": len(rows),
        "garch_normal": _fit_diag(latest_fits.get("normal")),
        "garch_t": _fit_diag(latest_fits.get("t")),
        "evt_sensitivity": sensitivity,
        "mean_excess": mean_excess_curve(-latest_fits["normal"].standardized_residuals())
        if latest_fits.get("normal") is not None else [],
    }
    return rows, diag


def _fit_diag(fit: GarchFit | None) -> dict[str, Any] | None:
    if fit is None:
        return None
    return {
        "dist": fit.dist, "mu": round(fit.mu, 6), "omega": round(fit.omega, 8),
        "alpha": round(fit.alpha, 6), "beta": round(fit.beta, 6),
        "persistence": round(fit.alpha + fit.beta, 6), "n_obs": fit.n_obs,
        "loglik": None if fit.loglik is None or not np.isfinite(fit.loglik) else round(fit.loglik, 3),
    }


def run_risk_pipeline(market_limit: int | None = None, only_markets: list[str] | None = None) -> dict[str, Any]:
    s = effective_settings()
    run_id = f"risk-{uuid.uuid4().hex[:10]}"
    t0 = time.perf_counter()
    with session_scope() as ses:
        ses.add(ModelRun(id=run_id, kind="risk", status="running", started_at=datetime.now(timezone.utc),
                         scope_json=dumps({"market_limit": market_limit})))
        markets = ses.execute(
            select(Market).where(Market.in_universe.is_(True), Market.model_eligible.is_(True))
            .order_by(Market.quote_volume_24h.desc())
        ).scalars().all()
        targets = [(m.exchange_code, m.symbol, m.quote_volume_24h or 0) for m in markets]
    targets.sort(key=lambda x: x[2], reverse=True)
    if only_markets is not None:
        wanted = {m.strip() for m in only_markets}
        targets = [t for t in targets if f"{t[0]}:{t[1]}" in wanted]
    if market_limit:
        targets = targets[:market_limit]

    stats = []
    diagnostics: list[dict[str, Any]] = []
    total_rows = 0
    for i, (ex, sym, _v) in enumerate(targets, 1):
        df = load_feature_frame(ex, sym)
        if df.empty or len(df) < s.risk_min_train:
            stats.append({"market": f"{ex}:{sym}", "status": "insufficient_history"})
            continue
        try:
            rows, diag = _risk_rows_for_market(ex, sym, df, s, run_id)
        except Exception as exc:  # noqa: BLE001
            log.exception(f"risk pipeline failed for {ex}:{sym}: {exc}")
            stats.append({"market": f"{ex}:{sym}", "status": "error", "error": str(exc)[:300]})
            continue
        if rows:
            with session_scope() as ses:
                for j in range(0, len(rows), 500):
                    upsert_rows(
                        ses, VarEsEstimate.__table__, rows[j : j + 500],
                        ["exchange_code", "symbol", "asof_date", "model_name", "confidence"],
                    )
        total_rows += len(rows)
        diagnostics.append(diag)
        stats.append({"market": f"{ex}:{sym}", "status": diag.get("status"), "rows": len(rows)})
        log.info(f"[{i}/{len(targets)}] risk {ex}:{sym} -> {len(rows)} estimates")

    # ---- backtests on the freshly stored estimates -----------------------
    bt_rows = _backtest_estimates(run_id, s)
    elapsed = time.perf_counter() - t0
    with session_scope() as ses:
        run = ses.get(ModelRun, run_id)
        if run:
            run.status = "success"
            run.finished_at = datetime.now(timezone.utc)
            run.metrics_json = dumps({
                "markets": len(targets), "estimate_rows": total_rows,
                "backtest_rows": len(bt_rows), "elapsed_seconds": round(elapsed, 1),
                "diagnostics": diagnostics, "per_market": stats,
            })
    return {
        "run_id": run_id, "markets": len(targets), "estimate_rows": total_rows,
        "backtest_rows": len(bt_rows), "elapsed_seconds": round(elapsed, 1),
    }


def _load_estimates() -> pd.DataFrame:
    with session_scope() as ses:
        rows = ses.execute(select(VarEsEstimate)).scalars().all()
        recs = [
            {
                "exchange": r.exchange_code, "symbol": r.symbol, "asof": r.asof_date,
                "model": r.model_name, "confidence": r.confidence, "var": r.var_pct,
                "es": r.es_pct, "actual_loss": r.actual_loss_pct,
            }
            for r in rows
        ]
    return pd.DataFrame(recs)


def _backtest_estimates(run_id: str, s) -> list[dict[str, Any]]:
    df = _load_estimates()
    if df.empty:
        return []
    rows: list[dict[str, Any]] = []
    for (ex, sym, model, conf), g in df.groupby(["exchange", "symbol", "model", "confidence"]):
        g = g.sort_values("asof")
        g = g[g["actual_loss"].notna()]
        if len(g) < 30:
            continue
        losses = g["actual_loss"].to_numpy(float)
        var = g["var"].to_numpy(float)
        es = g["es"].to_numpy(float)
        cov = coverage_tests(losses, var, float(conf))
        if cov is None:
            continue
        base = {"run_id": run_id, "scope": "asset", "exchange_code": ex, "symbol": sym,
                "horizon": 1, "model_name": model, "n_obs": cov.n_obs,
                "config_json": dumps({"confidence": float(conf)})}
        rows.append({**base, "metric": "var_coverage", "value": cov.breach_rate})
        rows.append({**base, "metric": "n_breaches", "value": float(cov.n_breaches)})
        rows.append({**base, "metric": "kupiec_pvalue", "value": cov.kupiec_pvalue, "p_value": cov.kupiec_pvalue})
        rows.append({**base, "metric": "christoffersen_ind_pvalue", "value": cov.christoffersen_ind_pvalue})
        rows.append({**base, "metric": "christoffersen_cc_pvalue", "value": cov.christoffersen_cc_pvalue})
        rows.append({**base, "metric": "quantile_loss", "value": quantile_loss(losses, var, float(conf))})
        if np.isfinite(es).sum() > 30:
            es_res = es_ratio_test(losses, var, es)
            if es_res.get("status") == "ok":
                rows.append({**base, "metric": "es_ratio", "value": es_res["es_ratio"],
                             "p_value": es_res["p_value"], "config_json": dumps({**es_res, "confidence": float(conf)})})
        clusters = breach_clusters(losses > var)
        rows.append({**base, "metric": "breach_clusters", "value": float(clusters["n_clusters"]),
                     "config_json": dumps({"confidence": float(conf), **clusters})})
    # aggregate comparison across markets
    agg_df = pd.DataFrame([r for r in rows if r["metric"] in ("var_coverage", "kupiec_pvalue", "es_ratio", "quantile_loss")])
    if not agg_df.empty:
        for (model, metric), g in agg_df.groupby(["model_name", "metric"]):
            conf_vals = [__import__("json").loads(c).get("confidence") for c in g["config_json"]]
            g = g.assign(confidence=conf_vals)
            for conf, gg in g.groupby("confidence"):
                rows.append({
                    "run_id": run_id, "scope": "aggregate", "exchange_code": None, "symbol": None,
                    "horizon": 1, "model_name": model, "metric": f"{metric}_mean",
                    "value": float(np.nanmean(gg["value"].astype(float))), "n_obs": int(gg["n_obs"].sum()),
                    "config_json": dumps({"confidence": conf, "aggregation": "unweighted mean across markets"}),
                })
    if rows:
        with session_scope() as ses:
            for i in range(0, len(rows), 400):
                ses.bulk_insert_mappings(BacktestResult, rows[i : i + 400])
    return rows

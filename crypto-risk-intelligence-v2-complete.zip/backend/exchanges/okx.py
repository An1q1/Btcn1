"""OKX spot and swap adapters (public endpoints, verified reachable)."""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Iterable

from backend.exchanges.base import BaseAdapter, Candle, DerivativeSnapshot, ExchangeError, MarketInfo
from backend.exchanges.symbols import (
    canonical_id,
    is_leveraged_token,
    is_stable_pair,
    is_wrapped,
    normalize_asset,
    timeframe_to_ms,
)

TF_MAP = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "1H", "2h": "2H", "4h": "4H", "6h": "6H", "12h": "12H", "1d": "1D"}
QUOTES = {"USDT", "USDC", "USD"}


class OKXBase(BaseAdapter):
    rest_url = "https://www.okx.com"
    ws_url = "wss://ws.okx.com:8443/ws/v5/public"
    rate_per_second = 6.0
    inst_type = "SPOT"
    market_type = "spot"
    capabilities = {
        "ohlcv": True,
        "trades": True,
        "orderbook": True,
        "funding": None,
        "open_interest": None,
        "mark_price": None,
        "liquidation": False,
        "websocket": True,
    }

    async def fetch_markets(self) -> list[MarketInfo]:
        inst = await self.get_json(f"{self.rest_url}/api/v5/public/instruments", {"instType": self.inst_type})
        tickers_raw = await self.get_json(f"{self.rest_url}/api/v5/market/tickers", {"instType": self.inst_type})
        if inst.get("code") != "0":
            raise ExchangeError(f"OKX instruments error: {inst.get('msg')}", exchange=self.code)
        tickers = {t["instId"]: t for t in tickers_raw.get("data", [])}
        out: list[MarketInfo] = []
        for i in inst.get("data", []):
            if i.get("state") != "live":
                continue
            quote = normalize_asset(i.get("quoteCcy") or i.get("settleCcy") or "")
            base = normalize_asset(i.get("baseCcy") or i.get("ctValCcy") or "")
            if quote not in QUOTES or not base:
                continue
            t = tickers.get(i["instId"], {})
            price = float(t.get("last", 0) or 0) or None
            vol_ccy = float(t.get("volCcy24h", 0) or 0)
            if self.inst_type == "SPOT":
                quote_vol = vol_ccy if vol_ccy else None  # spot volCcy24h is already quote-currency volume
            else:
                quote_vol = (vol_ccy * price) if (vol_ccy and price) else None
            out.append(
                MarketInfo(
                    exchange_code=self.code,
                    symbol=i["instId"],
                    base_asset=base,
                    quote_asset=quote,
                    market_type=self.market_type,
                    contract_type=("perpetual" if self.inst_type == "SWAP" else i.get("alias") or None),
                    status="active",
                    price=price,
                    quote_volume_24h=quote_vol,
                    bid=float(t.get("bidPx", 0) or 0) or None,
                    ask=float(t.get("askPx", 0) or 0) or None,
                    price_change_24h_pct=None,
                    last_update_ts=datetime.now(timezone.utc),
                    meta={
                        "canonical": canonical_id(
                            self.code, self.market_type, base, quote, "perpetual" if self.inst_type == "SWAP" else None
                        ),
                        "is_stable_pair": is_stable_pair(base, quote),
                        "is_leveraged_token": is_leveraged_token(base),
                        "is_wrapped": is_wrapped(base),
                        "list_time": i.get("listTime"),
                        "ct_val": i.get("ctVal"),
                        "ct_val_ccy": i.get("ctValCcy"),
                        "inst_category": i.get("instCategory"),
                        "asset_class": "crypto" if i.get("instCategory") == "1" else (
                            "tokenized_equity" if i.get("instCategory") == "3" else "commodity"
                        ),
                    },
                )
            )
        return out

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        bar = TF_MAP.get(timeframe)
        if not bar:
            raise ExchangeError(f"unsupported timeframe {timeframe}", exchange=self.code)
        tf_ms = timeframe_to_ms(timeframe)
        candles: dict[int, Candle] = {}
        after = end_ms
        guard = 0
        while guard < 80:
            guard += 1
            params: dict[str, Any] = {"instId": symbol, "bar": bar, "limit": 100}
            # OKX 'after' returns records strictly older than the timestamp
            params["after"] = after
            payload = await self.get_json(f"{self.rest_url}/api/v5/market/history-candles", params)
            if payload.get("code") != "0":
                raise ExchangeError(f"OKX candles error {payload.get('code')}: {payload.get('msg')}", exchange=self.code)
            rows = payload.get("data", [])
            if not rows:
                break
            for r in rows:
                ts = int(r[0])
                if ts < start_ms:
                    continue
                candles[ts] = Candle(
                    ts=ts,
                    open=float(r[1]),
                    high=float(r[2]),
                    low=float(r[3]),
                    close=float(r[4]),
                    volume=float(r[5]),
                    quote_volume=float(r[7]) if len(r) > 7 and r[7] else None,
                    is_final=(r[8] == "1") if len(r) > 8 else True,
                )
            oldest = min(int(r[0]) for r in rows)
            if oldest <= start_ms:
                break
            after = oldest
            if len(rows) < 100:
                # keep paging; history endpoint may return short pages near listing date
                if oldest <= start_ms + tf_ms * 2:
                    break
        return [candles[k] for k in sorted(candles)]

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        payload = await self.get_json(f"{self.rest_url}/api/v5/market/tickers", {"instType": self.inst_type})
        out: dict[str, MarketInfo] = {}
        for t in payload.get("data", []):
            if symbols is not None and t["instId"] not in symbols:
                continue
            last = float(t.get("last", 0) or 0) or None
            vol_ccy = float(t.get("volCcy24h", 0) or 0) or None
            if self.inst_type == "SWAP":
                # swap volCcy24h is base-currency volume -> convert to quote terms
                quote_vol = (vol_ccy * last) if (vol_ccy and last) else vol_ccy
            else:
                quote_vol = vol_ccy
            out[t["instId"]] = MarketInfo(
                exchange_code=self.code,
                symbol=t["instId"],
                base_asset="",
                quote_asset="",
                price=last,
                bid=float(t.get("bidPx", 0) or 0) or None,
                ask=float(t.get("askPx", 0) or 0) or None,
                quote_volume_24h=quote_vol,
                last_update_ts=datetime.now(timezone.utc),
            )
        return out

    async def server_time_ms(self) -> int | None:
        payload = await self.get_json(f"{self.rest_url}/api/v5/public/time")
        try:
            return int(payload["data"][0]["ts"])
        except (KeyError, IndexError, ValueError):
            return None


class OKXSpotAdapter(OKXBase):
    code = "okx_spot"
    name = "OKX Spot"
    inst_type = "SPOT"
    market_type = "spot"
    market_types = ("spot",)


class OKXSwapAdapter(OKXBase):
    code = "okx_swap"
    name = "OKX Perpetual Swaps"
    inst_type = "SWAP"
    market_type = "swap"
    market_types = ("swap",)
    capabilities = {
        "ohlcv": True,
        "trades": True,
        "orderbook": True,
        "funding": True,
        "open_interest": True,
        "mark_price": True,
        "liquidation": False,
        "websocket": True,
    }

    async def fetch_derivative_snapshot(self, symbol: str) -> DerivativeSnapshot | None:
        ts = int(time.time() * 1000)
        snap = DerivativeSnapshot(ts=ts)
        try:
            fr = await self.get_json(f"{self.rest_url}/api/v5/public/funding-rate", {"instId": symbol})
            row = (fr.get("data") or [{}])[0]
            snap.funding_rate = float(row.get("fundingRate", 0) or 0)
            snap.funding_next = float(row.get("nextFundingTime", 0) or 0) or None
        except ExchangeError:
            pass
        try:
            oi = await self.get_json(f"{self.rest_url}/api/v5/public/open-interest", {"instType": "SWAP", "instId": symbol})
            row = (oi.get("data") or [{}])[0]
            snap.open_interest = float(row.get("oi", 0) or 0) or None
            oi_base = float(row.get("oiCcy", 0) or 0) or None
            snap.method_open_interest_base = oi_base  # kept out of the public dataclass
        except ExchangeError:
            pass
        try:
            mp = await self.get_json(f"{self.rest_url}/api/v5/public/mark-price", {"instType": "SWAP", "instId": symbol})
            row = (mp.get("data") or [{}])[0]
            snap.mark_price = float(row.get("markPx", 0) or 0) or None
        except ExchangeError:
            pass
        try:
            idx = await self.get_json(f"{self.rest_url}/api/v5/market/index-tickers", {"instId": symbol.replace("-SWAP", "")})
            row = (idx.get("data") or [{}])[0]
            snap.index_price = float(row.get("idxPx", 0) or 0) or None
        except ExchangeError:
            pass
        if snap.mark_price and snap.index_price:
            snap.basis = snap.mark_price / snap.index_price - 1
        oi_base = getattr(snap, "method_open_interest_base", None)
        if oi_base and snap.mark_price:
            snap.open_interest_quote = oi_base * snap.mark_price
        if hasattr(snap, "method_open_interest_base"):
            delattr(snap, "method_open_interest_base")
        if snap.funding_rate is None and snap.open_interest is None:
            return None
        return snap

    async def fetch_funding_history(self, symbol: str, limit: int = 100) -> list[tuple[int, float]]:
        payload = await self.get_json(
            f"{self.rest_url}/api/v5/public/funding-rate-history", {"instId": symbol, "limit": min(limit, 100)}
        )
        out: list[tuple[int, float]] = []
        for row in payload.get("data", []):
            try:
                out.append((int(row["fundingTime"]), float(row["fundingRate"])))
            except (KeyError, ValueError):
                continue
        return sorted(out)

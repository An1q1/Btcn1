"""Binance adapters.

Environment note (verified 2026-10-20): `api.binance.com` and `fapi.binance.com`
return HTTP 451 from the current sandbox region. Binance publishes a public
market-data mirror `data-api.binance.vision` which is reachable and serves the
same /api/v3 market data (klines, tickers, exchangeInfo). The adapter therefore
tries the mirror first and falls back to the primary host. USDⓈ-M futures have
no such mirror, so that adapter reports `blocked` instead of inventing data.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable

from backend.exchanges.base import BaseAdapter, Candle, DerivativeSnapshot, ExchangeError, MarketInfo
from backend.exchanges.symbols import (
    canonical_id,
    is_leveraged_token,
    is_stable_pair,
    is_wrapped,
    normalize_asset,
    timeframe_to_ms,
)

TF_MAP = {"1m": "1m", "5m": "5m", "15m": "15m", "1h": "1h", "2h": "2h", "4h": "4h", "6h": "6h", "12h": "12h", "1d": "1d"}
MAX_LIMIT = 1000


class _BinanceBase(BaseAdapter):
    quote_whitelist = {"USDT", "USDC", "USD", "FDUSD", "BUSD", "TUSD"}

    def _parse_klines(self, raw: list[list[Any]]) -> list[Candle]:
        out: list[Candle] = []
        for k in raw:
            try:
                out.append(
                    Candle(
                        ts=int(k[0]),
                        open=float(k[1]),
                        high=float(k[2]),
                        low=float(k[3]),
                        close=float(k[4]),
                        volume=float(k[5]),
                        quote_volume=float(k[7]) if k[7] not in (None, "") else None,
                        is_final=True,
                    )
                )
            except (TypeError, ValueError, IndexError):
                continue
        return out

    async def _klines_paginated(
        self, url: str, symbol: str, interval: str, start_ms: int, end_ms: int, params_extra: dict | None = None
    ) -> list[Candle]:
        candles: dict[int, Candle] = {}
        cursor = start_ms
        guard = 0
        while cursor < end_ms and guard < 60:
            guard += 1
            params = {"symbol": symbol, "interval": interval, "startTime": cursor, "endTime": end_ms, "limit": MAX_LIMIT}
            if params_extra:
                params.update(params_extra)
            raw = await self.get_json(url, params)
            if not isinstance(raw, list) or not raw:
                break
            batch = self._parse_klines(raw)
            if not batch:
                break
            for c in batch:
                candles[c.ts] = c
            next_cursor = max(c.ts for c in batch) + timeframe_to_ms(interval)
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            if len(batch) < MAX_LIMIT:
                break
        return [candles[k] for k in sorted(candles)]

    async def _markets_from_exchange_info(
        self, base_url: str, info_path: str, ticker_path: str, book_path: str | None, market_type: str
    ) -> list[MarketInfo]:
        info = await self.get_json(f"{base_url}{info_path}")
        symbols = info.get("symbols", [])
        try:
            tickers = {t["symbol"]: t for t in await self.get_json(f"{base_url}{ticker_path}")}
        except ExchangeError:
            tickers = {}
        books: dict[str, dict] = {}
        if book_path:
            try:
                books = {b["symbol"]: b for b in await self.get_json(f"{base_url}{book_path}")}
            except ExchangeError:
                books = {}
        out: list[MarketInfo] = []
        for s in symbols:
            if s.get("status") not in ("TRADING", "SETTLING") or s.get("status") != "TRADING":
                continue
            base = normalize_asset(s.get("baseAsset", ""))
            quote = normalize_asset(s.get("quoteAsset", ""))
            if quote not in self.quote_whitelist:
                continue
            if s.get("isSpotTradingAllowed") is False and market_type == "spot":
                continue
            tk = tickers.get(s.get("symbol"), {})
            bk = books.get(s.get("symbol"), {})
            price = float(tk.get("lastPrice", 0) or 0) or None
            qv = float(tk.get("quoteVolume", 0) or 0) or None
            out.append(
                MarketInfo(
                    exchange_code=self.code,
                    symbol=s["symbol"],
                    base_asset=base,
                    quote_asset=quote,
                    market_type=market_type,
                    contract_type=s.get("contractType") if market_type != "spot" else None,
                    status="active",
                    price=price,
                    quote_volume_24h=qv,
                    bid=float(bk.get("bidPrice", 0) or 0) or None,
                    ask=float(bk.get("askPrice", 0) or 0) or None,
                    price_change_24h_pct=float(tk.get("priceChangePercent", 0) or 0) or None,
                    last_update_ts=datetime.now(timezone.utc),
                    meta={
                        "canonical": canonical_id(
                            self.code, market_type, base, quote,
                            s.get("contractType") if market_type != "spot" else None,
                        ),
                        "is_stable_pair": is_stable_pair(base, quote),
                        "is_leveraged_token": is_leveraged_token(base),
                        "is_wrapped": is_wrapped(base),
                        "tick_size": s.get("filters", [{}])[0].get("tickSize") if s.get("filters") else None,
                    },
                )
            )
        return out


class BinanceSpotAdapter(_BinanceBase):
    code = "binance_spot"
    name = "Binance Spot (public data mirror)"
    market_types = ("spot",)
    rest_url = "https://data-api.binance.vision"
    fallback_url = "https://api.binance.com"
    ws_url = "wss://data-stream.binance.vision/ws"
    rate_per_second = 8.0
    capabilities = {
        "ohlcv": True,
        "trades": False,
        "orderbook": False,
        "funding": False,
        "open_interest": False,
        "mark_price": False,
        "liquidation": False,
        "websocket": True,
        "notes": "Primary host geo-blocked; using Binance's official public market-data mirror.",
    }

    def _base(self) -> str:
        return self.rest_url

    async def fetch_markets(self) -> list[MarketInfo]:
        try:
            return await self._markets_from_exchange_info(
                self._base(), "/api/v3/exchangeInfo", "/api/v3/ticker/24hr", "/api/v3/ticker/bookTicker", "spot"
            )
        except ExchangeError:
            if self._base() != self.fallback_url:
                self.rest_url = self.fallback_url
                return await self._markets_from_exchange_info(
                    self.fallback_url, "/api/v3/exchangeInfo", "/api/v3/ticker/24hr", "/api/v3/ticker/bookTicker", "spot"
                )
            raise

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        interval = TF_MAP.get(timeframe)
        if not interval:
            raise ExchangeError(f"unsupported timeframe {timeframe}", exchange=self.code)
        return await self._klines_paginated(f"{self._base()}/api/v3/klines", symbol, interval, start_ms, end_ms)

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        tickers = await self.get_json(f"{self._base()}/api/v3/ticker/24hr")
        books = {b["symbol"]: b for b in await self.get_json(f"{self._base()}/api/v3/ticker/bookTicker")}
        out: dict[str, MarketInfo] = {}
        for t in tickers:
            sym = t["symbol"]
            if symbols is not None and sym not in symbols:
                continue
            bk = books.get(sym, {})
            out[sym] = MarketInfo(
                exchange_code=self.code,
                symbol=sym,
                base_asset="",
                quote_asset="",
                price=float(t["lastPrice"]),
                quote_volume_24h=float(t["quoteVolume"]),
                bid=float(bk.get("bidPrice", 0) or 0) or None,
                ask=float(bk.get("askPrice", 0) or 0) or None,
                price_change_24h_pct=float(t.get("priceChangePercent", 0)),
                last_update_ts=datetime.now(timezone.utc),
            )
        return out

    async def server_time_ms(self) -> int | None:
        data = await self.get_json(f"{self._base()}/api/v3/time")
        return int(data.get("serverTime", 0)) or None


class BinanceFuturesAdapter(_BinanceBase):
    code = "binance_futures"
    name = "Binance USDⓈ-M Futures"
    market_types = ("swap", "futures")
    rest_url = "https://fapi.binance.com"
    ws_url = "wss://fstream.binance.com/ws"
    rate_per_second = 5.0
    capabilities = {
        "ohlcv": True,
        "funding": True,
        "open_interest": True,
        "mark_price": True,
        "liquidation": False,
        "websocket": True,
        "notes": "HTTP 451 in this environment; adapter present but reported as blocked/unavailable.",
    }

    async def fetch_markets(self) -> list[MarketInfo]:
        return await self._markets_from_exchange_info(
            self.rest_url, "/fapi/v1/exchangeInfo", "/fapi/v1/ticker/24hr", "/fapi/v1/ticker/bookTicker", "swap"
        )

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        interval = TF_MAP.get(timeframe)
        if not interval:
            raise ExchangeError(f"unsupported timeframe {timeframe}", exchange=self.code)
        return await self._klines_paginated(
            f"{self.rest_url}/fapi/v1/klines", symbol, interval, start_ms, end_ms, {"contractType": "PERPETUAL"}
        )

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        tickers = await self.get_json(f"{self.rest_url}/fapi/v1/ticker/24hr")
        out: dict[str, MarketInfo] = {}
        for t in tickers:
            sym = t["symbol"]
            if symbols is not None and sym not in symbols:
                continue
            out[sym] = MarketInfo(
                exchange_code=self.code,
                symbol=sym,
                base_asset="",
                quote_asset="",
                price=float(t["lastPrice"]),
                quote_volume_24h=float(t["quoteVolume"]),
                price_change_24h_pct=float(t.get("priceChangePercent", 0)),
                last_update_ts=datetime.now(timezone.utc),
            )
        return out

    async def fetch_derivative_snapshot(self, symbol: str) -> DerivativeSnapshot | None:
        import time

        fr = await self.get_json(f"{self.rest_url}/fapi/v1/premiumIndex", {"symbol": symbol})
        oi = await self.get_json(f"{self.rest_url}/fapi/v1/openInterest", {"symbol": symbol})
        mark = float(fr.get("markPrice", 0) or 0) or None
        index = float(fr.get("indexPrice", 0) or 0) or None
        return DerivativeSnapshot(
            ts=int(time.time() * 1000),
            funding_rate=float(fr.get("lastFundingRate", 0) or 0) or None,
            funding_next=float(fr.get("nextFundingTime", 0) or 0) or None,
            open_interest=float(oi.get("openInterest", 0) or 0) or None,
            mark_price=mark,
            index_price=index,
            basis=(mark / index - 1) if mark and index else None,
        )

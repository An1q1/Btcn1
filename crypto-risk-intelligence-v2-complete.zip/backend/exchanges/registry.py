"""Adapter registry: builds enabled adapters once per process."""
from __future__ import annotations

from functools import lru_cache

from backend.core.config import get_settings
from backend.core.logging import get_logger
from backend.exchanges.base import BaseAdapter
from backend.exchanges.binance import BinanceFuturesAdapter, BinanceSpotAdapter
from backend.exchanges.bybit import BybitLinearAdapter, BybitSpotAdapter
from backend.exchanges.coinbase import CoinbaseAdapter
from backend.exchanges.kraken import KrakenAdapter
from backend.exchanges.okx import OKXSpotAdapter, OKXSwapAdapter

log = get_logger("registry")

ADAPTERS: dict[str, type[BaseAdapter]] = {
    "binance_spot": BinanceSpotAdapter,
    "binance_futures": BinanceFuturesAdapter,
    "okx_spot": OKXSpotAdapter,
    "okx_swap": OKXSwapAdapter,
    "bybit_spot": BybitSpotAdapter,
    "bybit_linear": BybitLinearAdapter,
    "coinbase": CoinbaseAdapter,
    "kraken": KrakenAdapter,
}


@lru_cache
def _instances() -> dict[str, BaseAdapter]:
    return {code: cls() for code, cls in ADAPTERS.items()}


def get_adapter(code: str) -> BaseAdapter:
    inst = _instances().get(code)
    if inst is None:
        raise KeyError(f"unknown exchange adapter '{code}'")
    return inst


def enabled_adapters() -> dict[str, BaseAdapter]:
    settings = get_settings()
    return {c: get_adapter(c) for c in settings.exchange_list if c in ADAPTERS}


def adapter_metadata() -> list[dict]:
    out = []
    for code, cls in ADAPTERS.items():
        out.append(
            {
                "code": code,
                "name": cls.name,
                "market_types": list(cls.market_types),
                "rest_url": cls.rest_url,
                "ws_url": cls.ws_url,
                "capabilities": cls.capabilities,
                "rate_per_second": cls.rate_per_second,
                "timeout_s": cls.timeout,
            }
        )
    return out


async def close_all() -> None:
    for adapter in _instances().values():
        await adapter.close()

"""Kraken public adapter.

Kraken's OHLC endpoint returns at most 720 candles per interval. With a 4h bar
that is ~120 days, which is below the modelling minimum; the ingestion layer
records the observed history length and marks such markets ineligible instead
of silently substituting daily bars for intraday RV.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Iterable

from backend.exchanges.base import BaseAdapter, Candle, ExchangeError, MarketInfo
from backend.exchanges.symbols import (
    canonical_id,
    is_leveraged_token,
    is_stable_pair,
    is_wrapped,
    normalize_asset,
)

INTERVAL = {"1m": 1, "5m": 5, "15m": 15, "1h": 60, "4h": 240, "1d": 1440}


class KrakenAdapter(BaseAdapter):
    code = "kraken"
    name = "Kraken"
    market_types = ("spot",)
    rest_url = "https://api.kraken.com"
    ws_url = "wss://ws.kraken.com/v2"
    rate_per_second = 1.2
    capabilities = {
        "ohlcv": True,
        "trades": True,
        "orderbook": True,
        "funding": False,
        "open_interest": False,
        "mark_price": False,
        "liquidation": False,
        "websocket": True,
        "ohlc_history_candles": 720,
    }

    async def fetch_markets(self) -> list[MarketInfo]:
        pairs = await self.get_json(f"{self.rest_url}/0/public/AssetPairs")
        if pairs.get("error"):
            raise ExchangeError(f"Kraken AssetPairs: {pairs['error']}", exchange=self.code)
        result: dict[str, Any] = pairs["result"]
        tickers: dict[str, Any] = {}
        try:
            tk = await self.get_json(f"{self.rest_url}/0/public/Ticker")
            tickers = tk.get("result", {})
        except ExchangeError:
            tickers = {}
        out: list[MarketInfo] = []
        for key, p in result.items():
            wsname = p.get("wsname", "")
            if "/" not in wsname:
                continue
            raw_base, raw_quote = wsname.split("/", 1)
            quote = normalize_asset(p.get("quote", raw_quote), self.code)
            base = normalize_asset(p.get("base", raw_base), self.code)
            if quote not in ("USD", "USDT", "USDC"):
                continue
            t = tickers.get(key, {})
            price = float(t.get("c", [0])[0]) if t.get("c") else None
            bid = float(t.get("b", [0])[0]) if t.get("b") else None
            ask = float(t.get("a", [0])[0]) if t.get("a") else None
            volume_base = float(t.get("v", [0, 0])[1]) if t.get("v") else None
            vwap = float(t.get("p", [0, 0])[1]) if t.get("p") else None
            quote_vol = volume_base * vwap if volume_base and vwap else None
            out.append(
                MarketInfo(
                    exchange_code=self.code,
                    symbol=key,
                    base_asset=base,
                    quote_asset=quote,
                    market_type="spot",
                    status="active" if p.get("status") == "online" else "inactive",
                    price=price,
                    quote_volume_24h=quote_vol,
                    bid=bid,
                    ask=ask,
                    last_update_ts=datetime.now(timezone.utc),
                    meta={
                        "canonical": canonical_id(self.code, "spot", base, quote),
                        "wsname": wsname,
                        "is_stable_pair": is_stable_pair(base, quote),
                        "is_leveraged_token": is_leveraged_token(base),
                        "is_wrapped": is_wrapped(base),
                        "pair_decimals": p.get("pair_decimals"),
                        "lot_decimals": p.get("lot_decimals"),
                    },
                )
            )
        return [m for m in out if m.status == "active"]

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        interval = INTERVAL.get(timeframe)
        if not interval:
            raise ExchangeError(f"unsupported timeframe {timeframe}", exchange=self.code)
        payload = await self.get_json(
            f"{self.rest_url}/0/public/OHLC",
            {"pair": symbol, "interval": interval, "since": start_ms // 1000},
        )
        if payload.get("error"):
            raise ExchangeError(f"Kraken OHLC: {payload['error']}", exchange=self.code)
        result = payload.get("result", {})
        rows = next((v for k, v in result.items() if k != "last" and isinstance(v, list)), [])
        out: list[Candle] = []
        for r in rows:
            ts = int(r[0]) * 1000
            if ts < start_ms or ts > end_ms:
                continue
            out.append(
                Candle(
                    ts=ts,
                    open=float(r[1]),
                    high=float(r[2]),
                    low=float(r[3]),
                    close=float(r[4]),
                    volume=float(r[6]),
                    quote_volume=None,
                    is_final=True,
                )
            )
        return sorted(out, key=lambda c: c.ts)

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        params = {"pair": ",".join(symbols)} if symbols else {}
        payload = await self.get_json(f"{self.rest_url}/0/public/Ticker", params)
        out: dict[str, MarketInfo] = {}
        for key, t in payload.get("result", {}).items():
            if symbols is not None and key not in symbols:
                continue
            out[key] = MarketInfo(
                exchange_code=self.code,
                symbol=key,
                base_asset="",
                quote_asset="",
                price=float(t["c"][0]),
                bid=float(t["b"][0]),
                ask=float(t["a"][0]),
                quote_volume_24h=None,
                last_update_ts=datetime.now(timezone.utc),
            )
        return out

"""Exchange adapter contract + shared HTTP/rate-limit plumbing.

Adapters are deliberately thin: they translate native payloads into a small
normalized vocabulary. No adapter fabricates fields the venue does not serve;
missing capabilities are declared in `capabilities` and surfaced in the API.
"""
from __future__ import annotations

import asyncio
import random
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Iterable

import httpx

from backend.core.config import get_settings
from backend.core.logging import get_logger

log = get_logger("exchange")


class ExchangeError(RuntimeError):
    def __init__(self, message: str, *, exchange: str, retryable: bool = False, status: int | None = None):
        super().__init__(message)
        self.exchange = exchange
        self.retryable = retryable
        self.status = status


class RateLimited(ExchangeError):
    def __init__(self, message: str, *, exchange: str, retry_after: float = 1.0):
        super().__init__(message, exchange=exchange, retryable=True, status=429)
        self.retry_after = retry_after


@dataclass
class MarketInfo:
    exchange_code: str
    symbol: str
    base_asset: str
    quote_asset: str
    market_type: str = "spot"
    contract_type: str | None = None
    status: str = "active"
    price: float | None = None
    quote_volume_24h: float | None = None
    bid: float | None = None
    ask: float | None = None
    price_change_24h_pct: float | None = None
    last_update_ts: datetime | None = None
    price_unit: str = "quote"
    meta: dict[str, Any] = field(default_factory=dict)

    @property
    def spread_bps(self) -> float | None:
        if self.bid and self.ask and self.bid > 0 and self.ask >= self.bid:
            return (self.ask - self.bid) / ((self.ask + self.bid) / 2) * 10_000
        return None


@dataclass
class Candle:
    ts: int
    open: float
    high: float
    low: float
    close: float
    volume: float
    quote_volume: float | None = None
    is_final: bool = True


@dataclass
class DerivativeSnapshot:
    ts: int
    funding_rate: float | None = None
    funding_next: float | None = None
    open_interest: float | None = None
    open_interest_quote: float | None = None
    mark_price: float | None = None
    index_price: float | None = None
    basis: float | None = None


class TokenBucket:
    """Simple async token bucket; `rate` requests per second, small burst."""

    def __init__(self, rate: float, burst: int = 3):
        self.rate = max(rate, 0.1)
        self.capacity = max(burst, 1)
        self.tokens = float(self.capacity)
        self.updated = time.monotonic()
        self._lock = asyncio.Lock()

    async def acquire(self) -> None:
        async with self._lock:
            while True:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.updated) * self.rate)
                self.updated = now
                if self.tokens >= 1:
                    self.tokens -= 1
                    return
                await asyncio.sleep((1 - self.tokens) / self.rate)


class BaseAdapter(ABC):
    code: str = "base"
    name: str = "Base"
    market_types: tuple[str, ...] = ("spot",)
    rest_url: str = ""
    ws_url: str | None = None
    capabilities: dict[str, Any] = {}
    rate_per_second: float = 5.0
    timeout: float = 25.0

    def __init__(self, client: httpx.AsyncClient | None = None):
        self.settings = get_settings()
        self._client = client
        self._own_client = client is None
        self._client_loop: asyncio.AbstractEventLoop | None = None
        self.bucket = TokenBucket(self.rate_per_second, burst=4)
        self.stats: dict[str, Any] = {
            "requests": 0,
            "errors": 0,
            "rate_limited": 0,
            "last_latency_ms": None,
            "last_error": None,
            "last_success_at": None,
        }

    # ---- lifecycle --------------------------------------------------------
    async def client(self) -> httpx.AsyncClient:
        """Lazily create the HTTP client, rebinding when the event loop changes.

        Adapter instances are process-wide singletons (see ``registry``), while
        ``asyncio.run`` creates and closes a fresh loop per call. An httpx client
        and an ``asyncio.Lock`` are both bound to the loop they were first used
        on, so they must be recycled when a different loop starts driving the
        adapter -- otherwise every request fails with "Event loop is closed".
        """
        loop = asyncio.get_running_loop()
        if self._client_loop is not loop:
            if self._client is not None and self._own_client:
                try:
                    await self._client.aclose()
                except Exception:  # noqa: BLE001 - old loop may already be closed
                    pass
                self._client = None
            self._client_loop = loop
            self.bucket = TokenBucket(self.rate_per_second, burst=4)
        if self._client is None:
            self._client = httpx.AsyncClient(
                timeout=self.timeout,
                headers={"User-Agent": self.settings.user_agent, "Accept": "application/json"},
                follow_redirects=True,
            )
        return self._client

    async def close(self) -> None:
        if self._client is not None and self._own_client:
            try:
                await self._client.aclose()
            except Exception:  # noqa: BLE001
                pass
            self._client = None
            self._client_loop = None

    # ---- http -------------------------------------------------------------
    async def _request(self, method: str, url: str, **kwargs: Any) -> Any:
        attempt = 0
        last_exc: Exception | None = None
        while attempt < 4:
            await self.bucket.acquire()
            t0 = time.perf_counter()
            try:
                client = await self.client()
                resp = await client.request(method, url, **kwargs)
                latency = (time.perf_counter() - t0) * 1000
                self.stats["requests"] += 1
                self.stats["last_latency_ms"] = round(latency, 1)
                if resp.status_code == 429:
                    self.stats["rate_limited"] += 1
                    retry_after = float(resp.headers.get("Retry-After", 2 ** attempt))
                    raise RateLimited(f"{self.code} rate limited", exchange=self.code, retry_after=retry_after)
                if resp.status_code >= 500:
                    raise ExchangeError(
                        f"{self.code} HTTP {resp.status_code}", exchange=self.code, retryable=True, status=resp.status_code
                    )
                if resp.status_code in (403, 451):
                    body = resp.text[:300].replace("\n", " ")
                    raise ExchangeError(
                        f"{self.code} blocked in this environment (HTTP {resp.status_code}): {body}",
                        exchange=self.code,
                        retryable=False,
                        status=resp.status_code,
                    )
                if resp.status_code >= 400:
                    raise ExchangeError(
                        f"{self.code} HTTP {resp.status_code}: {resp.text[:200]}",
                        exchange=self.code,
                        retryable=False,
                        status=resp.status_code,
                    )
                self.stats["last_success_at"] = datetime.now(timezone.utc).isoformat()
                return resp.json()
            except (RateLimited, ExchangeError) as exc:
                last_exc = exc
                self.stats["errors"] += 1
                self.stats["last_error"] = str(exc)[:300]
                if isinstance(exc, ExchangeError) and not exc.retryable:
                    raise
                delay = getattr(exc, "retry_after", 2 ** attempt) if isinstance(exc, RateLimited) else 2 ** attempt
                await asyncio.sleep(min(delay, 20) + random.uniform(0, 0.4))
                attempt += 1
            except (httpx.TimeoutException, httpx.TransportError) as exc:
                last_exc = exc
                self.stats["errors"] += 1
                self.stats["last_error"] = f"{type(exc).__name__}: {exc}"[:300]
                await asyncio.sleep(min(2 ** attempt, 15) + random.uniform(0, 0.5))
                attempt += 1
        raise ExchangeError(f"{self.code} request failed after retries: {last_exc}", exchange=self.code)

    async def get_json(self, url: str, params: dict[str, Any] | None = None) -> Any:
        return await self._request("GET", url, params=params)

    # ---- contract ---------------------------------------------------------
    @abstractmethod
    async def fetch_markets(self) -> list[MarketInfo]:
        ...

    @abstractmethod
    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        ...

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        raise NotImplementedError(f"{self.code} does not implement batch tickers")

    async def fetch_derivative_snapshot(self, symbol: str) -> DerivativeSnapshot | None:
        return None

    async def fetch_funding_history(self, symbol: str, limit: int = 100) -> list[tuple[int, float]]:
        return []

    async def server_time_ms(self) -> int | None:
        return None

    # ---- discovery helpers ------------------------------------------------
    async def probe(self) -> dict[str, Any]:
        """Connectivity/geo probe used by the Exchange Monitor."""
        start = time.perf_counter()
        out: dict[str, Any] = {"code": self.code, "name": self.name, "rest_url": self.rest_url}
        try:
            markets = await asyncio.wait_for(self.fetch_markets(), timeout=min(self.timeout, 20))
            out.update(
                status="ok" if markets else "degraded",
                detail=f"{len(markets)} markets",
                markets=len(markets),
                latency_ms=round((time.perf_counter() - start) * 1000, 1),
            )
        except Exception as exc:  # noqa: BLE001 - surfaced to UI
            status = "blocked" if isinstance(exc, ExchangeError) and exc.status in (403, 451) else "error"
            out.update(status=status, detail=str(exc)[:400], markets=0,
                       latency_ms=round((time.perf_counter() - start) * 1000, 1))
        out["capabilities"] = self.capabilities
        out["stats"] = self.stats
        return out

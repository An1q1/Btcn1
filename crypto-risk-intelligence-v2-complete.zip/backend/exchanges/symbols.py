"""Symbol standardization.

A market is identified by (exchange, market_type, base, quote, contract_type).
Ticker strings are never used alone to join data across venues; every adapter
returns structured base/quote metadata and a canonical id is built from it.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

LEVERAGED_SUFFIX = re.compile(r"(3L|3S|5L|5S|2L|2S|UP|DOWN|BULL|BEAR)$")
STABLES = {
    "USDT", "USDC", "USD", "BUSD", "DAI", "TUSD", "FDUSD", "USDD", "PYUSD",
    "USDP", "GUSD", "FRAX", "LUSD", "USD1", "EURC", "EUR", "GBP", "TRY", "BRL",
    "AUD", "JPY", "KRW", "RUB", "UAH", "NGN", "ZAR", "PLN", "ARS", "MXN",
}
WRAPPED_PREFIXES = ("WBTC", "WETH", "WBNB", "WSOL", "STETH", "WSTETH", "CBBTC", "RETH", "CBETH", "WBTC")


@dataclass(frozen=True)
class CanonicalSymbol:
    exchange: str
    market_type: str
    base: str
    quote: str
    contract_type: str | None = None

    @property
    def id(self) -> str:
        suffix = f":{self.contract_type}" if self.contract_type else ""
        return f"{self.exchange.upper()}:{self.market_type}:{self.base}/{self.quote}{suffix}"


def canonical_id(exchange: str, market_type: str, base: str, quote: str, contract_type: str | None = None) -> str:
    return CanonicalSymbol(exchange, market_type, base.upper(), quote.upper(), contract_type).id


def is_stable_pair(base: str, quote: str) -> bool:
    return base.upper() in STABLES and quote.upper() in STABLES


def is_leveraged_token(symbol: str) -> bool:
    return bool(LEVERAGED_SUFFIX.search(symbol.upper()))


def is_wrapped(base: str) -> bool:
    b = base.upper()
    return any(b.startswith(p) for p in WRAPPED_PREFIXES) or b.endswith("BULL") or b.endswith("BEAR")


def normalize_asset(asset: str, exchange_code: str = "") -> str:
    """Map venue-specific asset codes to a common ticker."""
    a = asset.upper().strip()
    if exchange_code == "kraken":
        mapping = {
            "XBT": "BTC", "XXBT": "BTC", "XETH": "ETH", "XDG": "DOGE",
            "ZUSD": "USD", "ZEUR": "EUR", "ZGBP": "GBP", "ZAUD": "AUD",
            "ZCAD": "CAD", "ZJPY": "JPY", "ZCHF": "CHF",
        }
        a = mapping.get(a, a)
        if len(a) == 4 and a.startswith("X"):
            a = a[1:]
    a = a.replace("XBT", "BTC")
    # Binance/Bybit/OKX list 1000x contracts (1000PEPE, 1000SHIB, kPEPE). The price
    # unit differs by 1000, so the ticker is normalized to the underlying asset and
    # the multiplier must be carried separately (price_unit / meta) — never merged
    # with the underlying price series.
    for prefix in ("1000000", "10000", "1000", "1M"):
        if a.startswith(prefix) and len(a) > len(prefix) + 1:
            a = a[len(prefix):]
            break
    if a.startswith("K") and len(a) > 4 and not a.startswith(("KAVA", "KSM")):
        a = a[1:].lstrip("1") or a
    return a


def timeframe_to_ms(tf: str) -> int:
    tf = tf.strip().lower()
    unit = tf[-1]
    value = int(tf[:-1])
    return {"m": 60_000, "h": 3_600_000, "d": 86_400_000}[unit] * value


def ms_to_date(ts: int) -> str:
    from datetime import datetime, timezone

    return datetime.fromtimestamp(ts / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


def date_to_ms(date_str: str) -> int:
    from datetime import datetime, timezone

    dt = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=timezone.utc)
    return int(dt.timestamp() * 1000)

"""Bybit v5 adapter (spot + linear perpetuals).

Verified 2026-10-20: api.bybit.com returns HTTP 403 (CloudFront country block)
from this environment. The adapter is functional code, but discovery/probe will
report `blocked`; no data is fabricated or substituted.
"""
from __future__ import annotations

import time
from datetime import datetime, timezone
from typing import Any, Iterable

from backend.exchanges.base import BaseAdapter, Candle, DerivativeSnapshot, ExchangeError, MarketInfo
from backend.exchanges.symbols import (
    canonical_id,
    is_leveraged_token,
    is_stable_pair,
    is_wrapped,
    normalize_asset,
    timeframe_to_ms,
)

TF_MAP = {"1m": "1", "5m": "5", "15m": "15", "1h": "60", "4h": "240", "1d": "D"}


class BybitBase(BaseAdapter):
    rest_url = "https://api.bybit.com"
    ws_url = "wss://stream.bybit.com/v5/public/spot"
    rate_per_second = 5.0
    category = "spot"
    market_type = "spot"

    async def fetch_markets(self) -> list[MarketInfo]:
        inst = await self.get_json(f"{self.rest_url}/v5/market/instruments-info", {"category": self.category, "limit": 1000})
        if inst.get("retCode") not in (0, None):
            raise ExchangeError(f"Bybit instruments: {inst.get('retMsg')}", exchange=self.code)
        rows = inst.get("result", {}).get("list", [])
        try:
            tick = await self.get_json(f"{self.rest_url}/v5/market/tickers", {"category": self.category})
            tickers = {t["symbol"]: t for t in tick.get("result", {}).get("list", [])}
        except ExchangeError:
            tickers = {}
        out: list[MarketInfo] = []
        for i in rows:
            if i.get("status") != "Trading":
                continue
            base = normalize_asset(i.get("baseCoin", ""))
            quote = normalize_asset(i.get("quoteCoin", ""))
            if quote not in ("USDT", "USDC", "USD"):
                continue
            t = tickers.get(i["symbol"], {})
            price = float(t.get("lastPrice", 0) or 0) or None
            out.append(
                MarketInfo(
                    exchange_code=self.code,
                    symbol=i["symbol"],
                    base_asset=base,
                    quote_asset=quote,
                    market_type=self.market_type,
                    contract_type=i.get("contractType") if self.market_type != "spot" else None,
                    price=price,
                    quote_volume_24h=float(t.get("turnover24h", 0) or 0) or None,
                    bid=float(t.get("bid1Price", 0) or 0) or None,
                    ask=float(t.get("ask1Price", 0) or 0) or None,
                    price_change_24h_pct=float(t.get("price24hPcnt", 0) or 0) * 100 or None,
                    last_update_ts=datetime.now(timezone.utc),
                    meta={
                        "canonical": canonical_id(
                            self.code, self.market_type, base, quote,
                            "perpetual" if self.market_type == "swap" else None,
                        ),
                        "is_stable_pair": is_stable_pair(base, quote),
                        "is_leveraged_token": is_leveraged_token(base),
                        "is_wrapped": is_wrapped(base),
                    },
                )
            )
        return out

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        interval = TF_MAP.get(timeframe)
        if not interval:
            raise ExchangeError(f"unsupported timeframe {timeframe}", exchange=self.code)
        tf_ms = timeframe_to_ms(timeframe)
        candles: dict[int, Candle] = {}
        cursor_end = end_ms
        guard = 0
        while cursor_end > start_ms and guard < 60:
            guard += 1
            payload = await self.get_json(
                f"{self.rest_url}/v5/market/kline",
                {"category": self.category, "symbol": symbol, "interval": interval,
                 "start": max(start_ms, cursor_end - tf_ms * 1000), "end": cursor_end, "limit": 1000},
            )
            rows = payload.get("result", {}).get("list", [])
            if not rows:
                break
            for r in rows:
                ts = int(r[0])
                candles[ts] = Candle(
                    ts=ts, open=float(r[1]), high=float(r[2]), low=float(r[3]),
                    close=float(r[4]), volume=float(r[5]), quote_volume=float(r[6]) or None,
                )
            oldest = min(int(r[0]) for r in rows)
            if oldest <= start_ms:
                break
            cursor_end = oldest - tf_ms
        return [candles[k] for k in sorted(candles)]

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        payload = await self.get_json(f"{self.rest_url}/v5/market/tickers", {"category": self.category})
        out: dict[str, MarketInfo] = {}
        for t in payload.get("result", {}).get("list", []):
            if symbols is not None and t["symbol"] not in symbols:
                continue
            out[t["symbol"]] = MarketInfo(
                exchange_code=self.code, symbol=t["symbol"], base_asset="", quote_asset="",
                price=float(t.get("lastPrice", 0) or 0) or None,
                bid=float(t.get("bid1Price", 0) or 0) or None,
                ask=float(t.get("ask1Price", 0) or 0) or None,
                quote_volume_24h=float(t.get("turnover24h", 0) or 0) or None,
                last_update_ts=datetime.now(timezone.utc),
            )
        return out


class BybitSpotAdapter(BybitBase):
    code = "bybit_spot"
    name = "Bybit Spot"
    category = "spot"
    market_type = "spot"
    market_types = ("spot",)
    capabilities = {"ohlcv": True, "funding": False, "open_interest": False, "websocket": True,
                    "notes": "HTTP 403 in this environment (CloudFront country block)."}


class BybitLinearAdapter(BybitBase):
    code = "bybit_linear"
    name = "Bybit Linear Perpetuals"
    category = "linear"
    market_type = "swap"
    market_types = ("swap",)
    ws_url = "wss://stream.bybit.com/v5/public/linear"
    capabilities = {"ohlcv": True, "funding": True, "open_interest": True, "websocket": True,
                    "notes": "HTTP 403 in this environment (CloudFront country block)."}

    async def fetch_derivative_snapshot(self, symbol: str) -> DerivativeSnapshot | None:
        payload = await self.get_json(f"{self.rest_url}/v5/market/tickers", {"category": "linear", "symbol": symbol})
        rows = payload.get("result", {}).get("list", [])
        if not rows:
            return None
        t = rows[0]
        mark = float(t.get("markPrice", 0) or 0) or None
        index = float(t.get("indexPrice", 0) or 0) or None
        return DerivativeSnapshot(
            ts=int(time.time() * 1000),
            funding_rate=float(t.get("fundingRate", 0) or 0) or None,
            open_interest=float(t.get("openInterest", 0) or 0) or None,
            open_interest_quote=float(t.get("openInterestValue", 0) or 0) or None,
            mark_price=mark,
            index_price=index,
            basis=(mark / index - 1) if mark and index else None,
        )

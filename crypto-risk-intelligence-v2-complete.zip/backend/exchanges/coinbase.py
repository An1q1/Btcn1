"""Coinbase Exchange (public) adapter. Intraday granularity is restricted to
{60, 300, 900, 3600, 21600, 86400} seconds and max 300 candles per request, so
the configured 4h bar is served as 6h; the pipeline records the actual bar size
per market and never mixes bar sizes inside one feature series.
"""
from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Iterable

from backend.exchanges.base import BaseAdapter, Candle, ExchangeError, MarketInfo
from backend.exchanges.symbols import (
    canonical_id,
    is_leveraged_token,
    is_stable_pair,
    is_wrapped,
    normalize_asset,
)

GRANULARITY = {"1m": 60, "5m": 300, "15m": 900, "1h": 3600, "6h": 21600, "1d": 86400}
MAX_PAGE = 300


class CoinbaseAdapter(BaseAdapter):
    code = "coinbase"
    name = "Coinbase Exchange"
    market_types = ("spot",)
    rest_url = "https://api.exchange.coinbase.com"
    ws_url = "wss://ws-feed.exchange.coinbase.com"
    rate_per_second = 5.0
    capabilities = {
        "ohlcv": True,
        "trades": True,
        "orderbook": True,
        "funding": False,
        "open_interest": False,
        "mark_price": False,
        "liquidation": False,
        "websocket": True,
        "max_candles_per_request": MAX_PAGE,
    }

    async def fetch_markets(self) -> list[MarketInfo]:
        products = await self.get_json(f"{self.rest_url}/products")
        stats: dict[str, dict] = {}
        try:
            raw = await self.get_json(f"{self.rest_url}/products/stats")
            stats = raw if isinstance(raw, dict) else {r.get("id", ""): r for r in raw}
        except ExchangeError:
            stats = {}
        out: list[MarketInfo] = []
        for p in products:
            if p.get("quote_currency") not in ("USD", "USDT", "USDC"):
                continue
            if p.get("status") != "online" or p.get("trading_disabled"):
                continue
            base = normalize_asset(p.get("base_currency", ""))
            quote = normalize_asset(p.get("quote_currency", ""))
            st = stats.get(p["id"], {}) or {}
            day = st.get("stats_24hour", {}) or {}
            last_price = float(day.get("last", 0) or 0) or None
            vol_base = float(day.get("volume", 0) or 0) or None
            out.append(
                MarketInfo(
                    exchange_code=self.code,
                    symbol=p["id"],
                    base_asset=base,
                    quote_asset=quote,
                    market_type="spot",
                    status="active",
                    price=last_price,
                    quote_volume_24h=(vol_base * last_price) if (vol_base and last_price) else None,
                    bid=None,
                    ask=None,
                    last_update_ts=datetime.now(timezone.utc),
                    meta={
                        "canonical": canonical_id(self.code, "spot", base, quote),
                        "is_stable_pair": is_stable_pair(base, quote),
                        "is_leveraged_token": is_leveraged_token(base),
                        "is_wrapped": is_wrapped(base),
                        "quote_increment": p.get("quote_increment"),
                        "volume_30day": (st.get("stats_30day", {}) or {}).get("volume"),
                        "volume_unit": "base_asset",
                        "day_open": day.get("open"),
                        "day_high": day.get("high"),
                        "day_low": day.get("low"),
                    },
                )
            )
        return out

    async def enrich_tickers(self, markets: list[MarketInfo], limit: int = 45) -> list[MarketInfo]:
        """Product tickers are per-product; only enrich the shortlist."""
        sem = asyncio.Semaphore(4)

        async def one(m: MarketInfo) -> None:
            async with sem:
                try:
                    t = await self.get_json(f"{self.rest_url}/products/{m.symbol}/ticker")
                    m.price = float(t.get("price", 0) or 0) or None
                    m.bid = float(t.get("bid", 0) or 0) or None
                    m.ask = float(t.get("ask", 0) or 0) or None
                    vol = float(t.get("volume", 0) or 0)
                    if m.quote_volume_24h is None and m.price:
                        m.quote_volume_24h = vol * m.price
                except ExchangeError:
                    pass

        await asyncio.gather(*[one(m) for m in markets[:limit]])
        return markets

    async def fetch_ohlcv(self, symbol: str, timeframe: str, start_ms: int, end_ms: int) -> list[Candle]:
        gran = GRANULARITY.get(timeframe)
        if not gran:
            raise ExchangeError(f"unsupported timeframe {timeframe} for Coinbase", exchange=self.code)
        candles: dict[int, Candle] = {}
        end = end_ms
        guard = 0
        page_span = gran * MAX_PAGE * 1000
        while end > start_ms and guard < 40:
            guard += 1
            start = max(start_ms, end - page_span)
            raw = await self.get_json(
                f"{self.rest_url}/products/{symbol}/candles",
                {"granularity": gran, "start": _iso(start), "end": _iso(end)},
            )
            if not isinstance(raw, list) or not raw:
                break
            for r in raw:
                ts = int(r[0]) * 1000
                candles[ts] = Candle(
                    ts=ts,
                    open=float(r[3]),
                    high=float(r[2]),
                    low=float(r[1]),
                    close=float(r[4]),
                    volume=float(r[5]),
                    quote_volume=float(r[5]) * float(r[4]),
                    is_final=True,
                )
            oldest = min(int(r[0]) for r in raw) * 1000
            if oldest <= start_ms:
                break
            end = oldest - gran * 1000
        return [candles[k] for k in sorted(candles)]

    async def fetch_tickers(self, symbols: Iterable[str] | None = None) -> dict[str, MarketInfo]:
        symbols = set(symbols) if symbols else None
        if not symbols:
            return {}
        out: dict[str, MarketInfo] = {}
        for sym in symbols:
            try:
                t = await self.get_json(f"{self.rest_url}/products/{sym}/ticker")
            except ExchangeError:
                continue
            out[sym] = MarketInfo(
                exchange_code=self.code,
                symbol=sym,
                base_asset="",
                quote_asset="",
                price=float(t.get("price", 0) or 0) or None,
                bid=float(t.get("bid", 0) or 0) or None,
                ask=float(t.get("ask", 0) or 0) or None,
                quote_volume_24h=float(t.get("volume", 0) or 0) * float(t.get("price", 0) or 0) or None,
                last_update_ts=datetime.now(timezone.utc),
            )
        return out


def _iso(ms: int) -> str:
    return datetime.fromtimestamp(ms / 1000, tz=timezone.utc).isoformat()

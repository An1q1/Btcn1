"""Tail-Risk Center read models."""
from __future__ import annotations

import json
from collections import defaultdict
from typing import Any

from sqlalchemy import func, select, text

from backend.core.config import effective_settings
from backend.core.db import get_engine, session_scope
from backend.core.models import BacktestResult, Market, ModelRun, VarEsEstimate
from backend.risk.backtests import breach_clusters, coverage_tests, es_ratio_test, quantile_loss
from backend.services.analytics import (
    METHOD_LABELS,
    finite,
    latest_var_es,
    load_universe_metrics,
    var_es_history,
)


def latest_risk_run() -> ModelRun | None:
    with session_scope() as ses:
        return ses.execute(
            select(ModelRun).where(ModelRun.kind == "risk", ModelRun.status == "success")
            .order_by(ModelRun.finished_at.desc()).limit(1)
        ).scalars().first()


def tail_risk_table(confidence: float = 0.99) -> dict[str, Any]:
    var_map = latest_var_es()
    metrics = load_universe_metrics()
    with session_scope() as ses:
        markets = ses.execute(select(Market).where(Market.in_universe.is_(True))).scalars().all()
        meta = {(m.exchange_code, m.symbol): m for m in markets}
    items = []
    for (ex, sym, conf), methods in var_map.items():
        if abs(conf - confidence) > 1e-9:
            continue
        m = meta.get((ex, sym))
        if m is None:
            continue
        base = methods.get("garch_evt") or methods.get("garch_t") or methods.get("historical") or {}
        items.append({
            "exchange": ex, "symbol": sym, "base_asset": m.base_asset,
            "quote_volume_24h": finite(m.quote_volume_24h),
            "asof_date": base.get("asof_date"),
            "rv": (metrics.get(f"{ex}:{sym}") or {}).get("rv"),
            "regime": (metrics.get(f"{ex}:{sym}") or {}).get("regime"),
            "methods": methods,
            "var_99": base.get("var_pct"), "es_99": base.get("es_pct"),
            "var_evt": (methods.get("garch_evt") or {}).get("var_pct"),
            "es_evt": (methods.get("garch_evt") or {}).get("es_pct"),
            "var_hist": (methods.get("historical") or {}).get("var_pct"),
            "xi": (methods.get("garch_evt") or {}).get("xi"),
            "n_exceedances": (methods.get("garch_evt") or {}).get("n_exceedances"),
        })
    items.sort(key=lambda r: r["es_99"] or 0, reverse=True)
    return {
        "confidence": confidence,
        "items": items,
        "method_labels": METHOD_LABELS,
        "sign_convention": "VaR/ES are positive loss percentages (loss = -return).",
    }


def risk_backtests(confidence: float = 0.99) -> dict[str, Any]:
    notes = [
        "Kupiec (1995) unconditional coverage LR test, chi-square(1).",
        "Christoffersen (1998) independence and conditional coverage tests.",
        "ES ratio test compares mean breach loss with predicted ES (bootstrap CI); "
        "it is an approximation, not the Acerbi-Szekely Z2 statistic.",
        "A non-rejection is not proof of a correct model; n_obs and breach counts are reported alongside p-values.",
    ]
    run = latest_risk_run()
    if run is None:
        # keep the response shape stable so clients never have to special-case it
        return {
            "status": "no_risk_run", "aggregate": [], "by_market": [], "confidence": confidence,
            "method_labels": METHOD_LABELS, "sign_convention": "VaR/ES are positive loss percentages.",
            "notes": notes,
        }
    with session_scope() as ses:
        rows = ses.execute(
            select(BacktestResult).where(BacktestResult.run_id == run.id)
        ).scalars().all()
    out_rows = []
    for r in rows:
        cfg = json.loads(r.config_json) if r.config_json else {}
        if abs(float(cfg.get("confidence", -1)) - confidence) > 1e-9:
            continue
        out_rows.append({
            "scope": r.scope, "exchange": r.exchange_code, "symbol": r.symbol,
            "model": r.model_name, "metric": r.metric, "value": r.value,
            "p_value": r.p_value, "n_obs": r.n_obs, "config": cfg,
        })
    aggregate = [r for r in out_rows if r["scope"] == "aggregate"]
    by_market = [r for r in out_rows if r["scope"] == "asset"]
    return {
        "run_id": run.id,
        "confidence": confidence,
        "aggregate": aggregate,
        "by_market": by_market,
        "method_labels": METHOD_LABELS,
        "notes": notes,
    }


def tail_detail(exchange: str, symbol: str, confidence: float = 0.99) -> dict[str, Any]:
    s = effective_settings()
    series = {m: var_es_history(exchange, symbol, confidence, m, limit=400) for m in METHOD_LABELS}
    # recompute tests from the stored series for the requested confidence
    tests: dict[str, Any] = {}
    for method, hist in series.items():
        if not hist:
            continue
        losses = [h["actual_loss_pct"] for h in hist if h["actual_loss_pct"] is not None]
        var = [h["var_pct"] for h in hist if h["actual_loss_pct"] is not None]
        es = [h["es_pct"] for h in hist if h["actual_loss_pct"] is not None]
        cov = coverage_tests(losses, var, confidence) if len(losses) >= 20 else None
        tests[method] = {
            "coverage": cov.as_dict() if cov else None,
            "quantile_loss": quantile_loss(losses, var, confidence) if losses else None,
            "es_test": es_ratio_test(losses, var, es) if len(losses) >= 20 else None,
            "clusters": breach_clusters([l > v for l, v in zip(losses, var)]) if losses else None,
        }
    run = latest_risk_run()
    diagnostics = None
    sensitivity = None
    mean_excess = None
    if run and run.metrics_json:
        try:
            payload = json.loads(run.metrics_json)
        except ValueError:
            payload = {}
        for diag in payload.get("diagnostics", []):
            if diag.get("market") == f"{exchange}:{symbol}":
                diagnostics = {k: v for k, v in diag.items() if k not in ("evt_sensitivity", "mean_excess")}
                sensitivity = diag.get("evt_sensitivity")
                mean_excess = diag.get("mean_excess")
                break
    if sensitivity is None:
        # fall back to the latest fit's stored meta (no recomputation here)
        sensitivity = []
    return {
        "exchange": exchange,
        "symbol": symbol,
        "confidence": confidence,
        "series": series,
        "tests": tests,
        "diagnostics": diagnostics,
        "threshold_sensitivity": sensitivity,
        "mean_excess": mean_excess,
        "method_labels": METHOD_LABELS,
        "confidences": s.confidence_list,
    }


def risk_overview() -> dict[str, Any]:
    s = effective_settings()
    run = latest_risk_run()
    out: dict[str, Any] = {"run_id": run.id if run else None, "confidences": {}}
    sql = text(
        """
        SELECT exchange_code, symbol, model_name, confidence, asof_date, var_pct, es_pct, actual_loss_pct
        FROM var_es_estimates
        WHERE actual_loss_pct IS NOT NULL
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql).mappings().all()
    df_rows = [
        (r["exchange_code"], r["symbol"], r["model_name"], r["confidence"], r["asof_date"],
         r["var_pct"], r["es_pct"], r["actual_loss_pct"])
        for r in rows
    ]
    grouped: dict[tuple[str, float], list] = defaultdict(list)
    for r in df_rows:
        grouped[(r[2], r[3])].append(r)
    for conf in s.confidence_list:
        table = []
        for method in METHOD_LABELS:
            data = [r for r in grouped.get((method, conf), []) if r[7] is not None]
            if not data:
                continue
            losses = [r[7] for r in data]
            var = [r[5] for r in data]
            es = [r[6] for r in data]
            cov = coverage_tests(losses, var, conf)
            table.append({
                "model": method, "label": METHOD_LABELS[method],
                "n_obs": cov.n_obs if cov else 0,
                "n_breaches": cov.n_breaches if cov else 0,
                "expected_breaches": cov.expected_breaches if cov else None,
                "breach_rate": cov.breach_rate if cov else None,
                "kupiec_pvalue": cov.kupiec_pvalue if cov else None,
                "christoffersen_cc_pvalue": cov.christoffersen_cc_pvalue if cov else None,
                "es_ratio": (es_ratio_test(losses, var, es).get("es_ratio") if cov else None),
                "quantile_loss": quantile_loss(losses, var, conf),
                "mean_var": sum(var) / len(var) if var else None,
                "mean_es": sum(v for v in es if v is not None) / max(1, len([v for v in es if v is not None])) if es else None,
            })
        out["confidences"][str(conf)] = table
    return out

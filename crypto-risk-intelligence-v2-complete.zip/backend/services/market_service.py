"""Market Overview / Screener / Asset Detail read models."""
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select, text

from backend.core.config import effective_settings
from backend.core.db import get_engine, session_scope
from backend.core.models import (
    Alert,
    DataQualityEvent,
    DerivativeMetric,
    Forecast,
    IngestionJob,
    Market,
    ModelRun,
    VarEsEstimate,
)
from backend.data_ingestion.live import STATE
from backend.data_ingestion.universe import target_timeframe_for
from backend.services.analytics import (
    CACHE,
    _iso,
    consensus_forecast,
    feature_series,
    finite,
    latest_forecasts,
    latest_var_es,
    live_quote,
    load_universe_metrics,
    market_freshness,
    pct,
)

SORT_FIELDS = {
    "quote_volume": "quote_volume_24h",
    "volume": "quote_volume_24h",
    "rv": "rv",
    "realized_vol": "rv",
    "forecast_vol": "forecast_vol",
    "var": "var_99",
    "es": "es_99",
    "spread": "spread_bps",
    "price": "price",
    "change": "price_change_24h_pct",
}


def _market_base_row(m: Market) -> dict[str, Any]:
    return {
        "exchange": m.exchange_code,
        "symbol": m.symbol,
        "canonical_symbol": m.canonical_symbol,
        "base_asset": m.base_asset,
        "quote_asset": m.quote_asset,
        "market_type": m.market_type,
        "contract_type": m.contract_type,
        "status": m.status,
        "price": finite(m.last_price),
        "quote_volume_24h": finite(m.quote_volume_24h),
        "spread_bps": finite(m.spread_bps),
        "price_change_24h_pct": finite(m.price_change_24h_pct),
        "model_eligible": bool(m.model_eligible),
        "in_universe": bool(m.in_universe),
        "ineligible_reasons": json.loads(m.ineligible_reasons) if m.ineligible_reasons else [],
        "history_days": m.history_days_available,
        "data_completeness": finite(m.data_completeness),
        "last_update": m.last_update_ts.isoformat() if m.last_update_ts else None,
    }


def _enrich(row: dict[str, Any], metrics: dict[str, dict], forecasts: dict, var_map: dict) -> dict[str, Any]:
    key = f"{row['exchange']}:{row['symbol']}"
    met = metrics.get(key, {})
    row["rv"] = met.get("rv")
    row["rv_ann_vol"] = met.get("rv_ann_vol")
    row["ret_pct"] = met.get("ret_pct")
    row["regime"] = met.get("regime", "not_modelled" if not row["model_eligible"] else "insufficient_data")
    row["regime_percentile"] = met.get("rv_percentile")
    row["feature_date"] = met.get("bar_date")
    row["funding_rate"] = met.get("funding_rate")
    row["open_interest"] = met.get("open_interest")
    f1 = (forecasts.get((row["exchange"], row["symbol"], 1)) or {})
    cons = consensus_forecast(f1)
    row["forecast_vol"] = cons["predicted_vol_annualized"] if cons else None
    row["forecast_rv"] = cons["predicted_rv_median"] if cons else None
    row["forecast_models"] = len(cons["models"]) if cons else 0
    row["forecast_dispersion"] = cons["dispersion"] if cons else None
    var99 = var_map.get((row["exchange"], row["symbol"], 0.99)) or {}
    evt = var99.get("garch_evt") or var99.get("garch_t") or var99.get("historical") or {}
    row["var_99"] = evt.get("var_pct")
    row["es_99"] = evt.get("es_pct")
    row["var_method"] = "garch_evt" if var99.get("garch_evt") else ("garch_t" if var99.get("garch_t") else "historical")
    row["freshness"] = market_freshness(row["exchange"], row["symbol"], _parse_dt(row["last_update"]))
    row["last_update"] = row["last_update"]
    return row


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def list_markets(
    search: str | None = None,
    exchange: str | None = None,
    quote: str | None = None,
    market_type: str | None = None,
    min_volume: float | None = None,
    eligible_only: bool = False,
    regime: str | None = None,
    in_universe: bool | None = None,
    sort: str = "quote_volume",
    order: str = "desc",
    page: int = 1,
    page_size: int = 50,
) -> dict[str, Any]:
    metrics = load_universe_metrics()
    forecasts = latest_forecasts()
    var_map = latest_var_es()
    with session_scope() as ses:
        q = select(Market).where(Market.status == "active")
        if exchange:
            q = q.where(Market.exchange_code.in_(exchange.split(",")))
        if quote:
            q = q.where(Market.quote_asset.in_(quote.split(",")))
        if market_type:
            q = q.where(Market.market_type == market_type)
        if min_volume:
            q = q.where(Market.quote_volume_24h >= min_volume)
        if eligible_only:
            q = q.where(Market.model_eligible.is_(True))
        if in_universe is not None:
            q = q.where(Market.in_universe.is_(in_universe))
        if search:
            like = f"%{search.strip().upper()}%"
            q = q.where(
                (func.upper(Market.symbol).like(like))
                | (func.upper(Market.base_asset).like(like))
                | (func.upper(Market.canonical_symbol).like(like))
            )
        markets = ses.execute(q).scalars().all()
        rows = [_enrich(_market_base_row(m), metrics, forecasts, var_map) for m in markets]

    if regime:
        rows = [r for r in rows if r["regime"] == regime]
    field = SORT_FIELDS.get(sort, "quote_volume_24h")
    reverse = order != "asc"

    def key(r: dict[str, Any]):
        v = r.get(field)
        if v is None:
            # keep missing values last in both directions
            return float("-inf") if reverse else float("inf")
        return v

    rows.sort(key=key, reverse=reverse)
    total = len(rows)
    page = max(1, page)
    page_size = min(max(1, page_size), 500)
    start = (page - 1) * page_size
    items = rows[start : start + page_size]
    exchanges = sorted({r["exchange"] for r in rows})
    quotes = sorted({r["quote_asset"] for r in rows})
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "pages": math.ceil(total / page_size) if page_size else 0,
        "filters": {
            "exchanges": exchanges,
            "quotes": quotes,
            "market_types": ["spot", "swap", "futures"],
            "regimes": ["low", "normal", "high", "extreme", "insufficient_data", "not_modelled"],
            "sort_fields": sorted(SORT_FIELDS.keys()),
        },
        "data_as_of": _latest_feature_date(metrics),
    }


def _latest_feature_date(metrics: dict[str, dict]) -> str | None:
    dates = [m["bar_date"] for m in metrics.values() if m.get("bar_date")]
    return max(dates) if dates else None


def overview() -> dict[str, Any]:
    metrics = load_universe_metrics()
    forecasts = latest_forecasts()
    var_map = latest_var_es()
    now = datetime.now(timezone.utc)
    with session_scope() as ses:
        markets = ses.execute(select(Market).where(Market.status == "active")).scalars().all()
        rows = [_enrich(_market_base_row(m), metrics, forecasts, var_map) for m in markets if m.in_universe]
        markets_total = ses.execute(select(func.count()).select_from(Market)).scalar_one()
        ex_rows = ses.execute(text("SELECT code, name, status, latency_ms, last_checked_at FROM exchanges")).mappings().all()
        active_alerts = ses.execute(
            select(func.count()).select_from(Alert).where(
                Alert.acknowledged.is_(False), Alert.resolved_at.is_(None)
            )
        ).scalar_one()
        latest_runs = {}
        for kind in ("forecast", "risk", "evaluation", "ingestion"):
            r = ses.execute(
                select(ModelRun).where(ModelRun.kind == kind).order_by(ModelRun.started_at.desc()).limit(1)
            ).scalars().first()
            if r:
                latest_runs[kind] = {
                    "id": r.id, "status": r.status,
                    "started_at": r.started_at.isoformat() if r.started_at else None,
                    "finished_at": r.finished_at.isoformat() if r.finished_at else None,
                    "metrics": json.loads(r.metrics_json) if r.metrics_json else None,
                }
        ingestion = ses.execute(
            select(IngestionJob.status, func.count()).group_by(IngestionJob.status)
        ).all()
        last_ingest = ses.execute(select(func.max(IngestionJob.finished_at))).scalar()
        dq_24h = ses.execute(
            select(func.count()).select_from(DataQualityEvent).where(
                DataQualityEvent.ts >= now - timedelta(hours=24)
            )
        ).scalar_one()
        forecast_count = ses.execute(select(func.count()).select_from(Forecast)).scalar_one()
        var_count = ses.execute(select(func.count()).select_from(VarEsEstimate)).scalar_one()

    high_vol = sorted(
        [r for r in rows if r["regime"] in ("high", "extreme")],
        key=lambda r: r.get("rv") or 0, reverse=True,
    )[:6]
    tail = _tail_risk_movers()
    movers = sorted(
        [r for r in rows if r.get("price_change_24h_pct") is not None],
        key=lambda r: abs(r["price_change_24h_pct"]), reverse=True,
    )[:6]
    top_volume = sorted(rows, key=lambda r: r.get("quote_volume_24h") or 0, reverse=True)[:12]
    regime_counts: dict[str, int] = {}
    for r in rows:
        regime_counts[r["regime"]] = regime_counts.get(r["regime"], 0) + 1
    live = STATE.status()
    return {
        "kpis": {
            "tracked_markets": len(rows),
            "tracked_assets": len({r["base_asset"] for r in rows}),
            "exchanges_total": len(ex_rows),
            "exchanges_connected": sum(1 for e in ex_rows if e["status"] == "ok"),
            "model_eligible": sum(1 for r in rows if r["model_eligible"]),
            "high_volatility_assets": len(high_vol),
            "active_alerts": active_alerts,
            "forecasts_stored": int(forecast_count),
            "var_es_estimates": int(var_count),
            "optimal_models_available": len({m for f in forecasts.values() for h in f.values() for m in h}),
            "data_quality_events_24h": int(dq_24h),
            "last_ingestion": last_ingest.isoformat() if last_ingest else None,
            "live_tracked": live.get("tracked_markets", 0),
            "live_last_poll": live.get("last_rest_poll"),
        },
        "pipeline": {"runs": latest_runs, "ingestion_jobs": {k: int(v) for k, v in ingestion}},
        "regime_distribution": regime_counts,
        "high_volatility": high_vol,
        "tail_risk_movers": tail,
        "top_movers": movers,
        "markets": top_volume,
        "exchanges": [
            {
                "code": e["code"], "name": e["name"], "status": e["status"],
                "latency_ms": finite(e["latency_ms"]),
                "last_checked": _iso(e["last_checked_at"]),
            }
            for e in ex_rows
        ],
        "live": live,
        "data_as_of": _latest_feature_date(metrics),
        "server_time": now.isoformat(),
    }


def _tail_risk_movers(limit: int = 6) -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT exchange_code, symbol, asof_date, es_pct, var_pct
        FROM var_es_estimates
        WHERE model_name='garch_evt' AND confidence=0.99
        ORDER BY asof_date DESC
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql).mappings().all()
    latest: dict[str, dict] = {}
    series: dict[str, list[float]] = {}
    for r in rows:
        key = f"{r['exchange_code']}:{r['symbol']}"
        series.setdefault(key, []).append(r["es_pct"])
        if key not in latest:
            latest[key] = dict(r)
    out = []
    for key, last in latest.items():
        hist = [v for v in series.get(key, [])[:61] if v is not None]
        if len(hist) < 20:
            continue
        baseline = sorted(hist[1:])[len(hist[1:]) // 2] if len(hist) > 1 else hist[0]
        change = (last["es_pct"] / baseline - 1) if baseline else None
        out.append({
            "exchange": last["exchange_code"], "symbol": last["symbol"], "asof_date": last["asof_date"],
            "es_99": finite(last["es_pct"]), "var_99": finite(last["var_pct"]),
            "es_change_pct": change, "baseline_es": baseline,
        })
    out.sort(key=lambda r: r["es_change_pct"] or 0, reverse=True)
    return out[:limit]


def asset_detail(exchange: str, symbol: str) -> dict[str, Any] | None:
    with session_scope() as ses:
        m = ses.execute(
            select(Market).where(Market.exchange_code == exchange, Market.symbol == symbol)
        ).scalars().first()
        if m is None:
            return None
        base = _market_base_row(m)
        eligibility = json.loads(m.eligibility) if m.eligibility else None
        meta = json.loads(m.meta_json) if m.meta_json else {}
        deriv = ses.execute(
            select(DerivativeMetric)
            .where(DerivativeMetric.exchange_code == exchange, DerivativeMetric.symbol == symbol)
            .order_by(DerivativeMetric.ts.desc()).limit(1)
        ).scalars().first()
        dq = ses.execute(
            select(DataQualityEvent)
            .where(DataQualityEvent.exchange_code == exchange, DataQualityEvent.symbol == symbol)
            .order_by(DataQualityEvent.ts.desc()).limit(10)
        ).scalars().all()
    metrics = load_universe_metrics().get(f"{exchange}:{symbol}", {})
    forecasts = latest_forecasts()
    var_map = latest_var_es()
    base = _enrich(base, {f"{exchange}:{symbol}": metrics}, forecasts, var_map)
    horizons = {}
    for h in effective_settings().horizon_list:
        models = forecasts.get((exchange, symbol, h)) or {}
        horizons[str(h)] = {
            "models": {
                name: {
                    **payload,
                    "label": name.replace("_", " ").title(),
                }
                for name, payload in models.items()
            },
            "consensus": consensus_forecast(models),
        }
    risk_latest = {}
    for conf in effective_settings().confidence_list:
        est = var_map.get((exchange, symbol, conf)) or {}
        risk_latest[str(conf)] = {
            method: {**vals, "label": method.replace("_", " ").title()} for method, vals in est.items()
        }
    tf = target_timeframe_for(exchange, effective_settings().bar_timeframe)
    return {
        "market": base,
        "meta": meta,
        "eligibility": eligibility,
        "live": live_quote(exchange, symbol),
        "features": {
            "bar_date": metrics.get("bar_date"),
            "rv": metrics.get("rv"),
            "rv_w": metrics.get("rv_w"),
            "rv_m": metrics.get("rv_m"),
            "rv_ann_vol": metrics.get("rv_ann_vol"),
            "ret_pct": metrics.get("ret_pct"),
            "range_pct": metrics.get("range_pct"),
            "volume_z": metrics.get("volume_z"),
            "jump_ratio": metrics.get("jump_ratio"),
            "regime": metrics.get("regime"),
            "regime_thresholds": metrics.get("regime_thresholds"),
            "rv_percentile": metrics.get("rv_percentile"),
        },
        "forecasts": horizons,
        "risk": risk_latest,
        "derivatives": (
            {
                "funding_rate": finite(deriv.funding_rate),
                "open_interest": finite(deriv.open_interest),
                "open_interest_quote": finite(deriv.open_interest_quote),
                "mark_price": finite(deriv.mark_price),
                "index_price": finite(deriv.index_price),
                "basis": finite(deriv.basis),
                "ts": datetime.fromtimestamp(deriv.ts / 1000, tz=timezone.utc).isoformat() if deriv.ts else None,
                "source": deriv.source,
            }
            if deriv
            else None
        ),
        "data_quality": [
            {
                "ts": d.ts.isoformat(), "event_type": d.event_type, "severity": d.severity,
                "details": json.loads(d.details_json) if d.details_json else {},
            }
            for d in dq
        ],
        "timeframe": tf,
    }


def market_series_bundle(exchange: str, symbol: str, timeframe: str | None, limit: int) -> dict[str, Any]:
    tf = timeframe or target_timeframe_for(exchange, effective_settings().bar_timeframe)
    return {
        "timeframe": tf,
        "ohlcv": ohlcv_series_safe(exchange, symbol, tf, limit),
        "features": feature_series(exchange, symbol, limit=min(limit, 400)),
    }


def ohlcv_series_safe(exchange: str, symbol: str, timeframe: str, limit: int) -> list[dict[str, Any]]:
    from backend.services.analytics import ohlcv_series

    return ohlcv_series(exchange, symbol, timeframe, limit)

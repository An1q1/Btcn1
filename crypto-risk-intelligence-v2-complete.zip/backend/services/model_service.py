"""Forecast / model-comparison / research read models."""
from __future__ import annotations

import json
import math
from collections import defaultdict
from typing import Any

from sqlalchemy import func, select, text

from backend.core.config import effective_settings
from backend.core.db import get_engine, session_scope
from backend.core.models import BacktestResult, Forecast, Market, ModelRegistry, ModelRun, RealizedTarget
from backend.quant.evaluation import latest_eval_run
from backend.quant.walkforward import MODEL_FAMILIES, MODEL_VERSIONS, TARGET_DEFINITION
from backend.services.analytics import (
    MODEL_LABELS,
    consensus_forecast,
    feature_series,
    finite,
    forecast_history,
    latest_forecasts,
    load_universe_metrics,
)


def forecasts_table(horizon: int = 1, model: str | None = None, sort: str = "forecast_vol", limit: int = 100) -> dict[str, Any]:
    metrics = load_universe_metrics()
    forecasts = latest_forecasts()
    rows = []
    for (ex, sym, h), models in forecasts.items():
        if h != horizon:
            continue
        if model and model not in models:
            continue
        selected = models[model] if model else None
        cons = consensus_forecast(models)
        key = f"{ex}:{sym}"
        met = metrics.get(key, {})
        if selected:
            pred_rv = selected["predicted_rv"]
            pred_vol = selected["predicted_vol_annualized"]
            actual = selected["actual_rv"]
            bar_date = selected["bar_date"]
            dispersion = None
            n_models = 1
        else:
            pred_rv = cons["predicted_rv_median"] if cons else None
            pred_vol = cons["predicted_vol_annualized"] if cons else None
            actual = None
            bar_date = max((m["bar_date"] for m in models.values()), default=None)
            dispersion = cons["dispersion"] if cons else None
            n_models = len(models)
        rows.append({
            "exchange": ex, "symbol": sym, "horizon": h,
            "predicted_rv": pred_rv, "predicted_vol": pred_vol,
            "actual_rv": actual, "bar_date": bar_date,
            "rv": met.get("rv"), "regime": met.get("regime"),
            "dispersion": dispersion, "n_models": n_models,
            "models": {
                k: {"predicted_rv": v["predicted_rv"],
                    "predicted_vol": v["predicted_vol_annualized"],
                    "actual_rv": v["actual_rv"]}
                for k, v in models.items()
            },
            "quote_volume_24h": None,
        })
    # attach volume for sorting
    with session_scope() as ses:
        vols = {
            (m.exchange_code, m.symbol): m.quote_volume_24h
            for m in ses.execute(select(Market)).scalars()
        }
    for r in rows:
        r["quote_volume_24h"] = vols.get((r["exchange"], r["symbol"]))
    sort_key = {
        "forecast_vol": lambda r: r["predicted_vol"] or -1,
        "realized_vol": lambda r: r["rv"] or -1,
        "dispersion": lambda r: r["dispersion"] or -1,
        "volume": lambda r: r["quote_volume_24h"] or -1,
    }.get(sort, lambda r: r["predicted_vol"] or -1)
    rows.sort(key=sort_key, reverse=True)
    return {
        "items": rows[:limit],
        "total": len(rows),
        "horizon": horizon,
        "model": model,
        "model_labels": MODEL_LABELS,
        "as_of": max((r["bar_date"] for r in rows if r["bar_date"]), default=None),
    }


def model_comparison(exchange: str, symbol: str, horizon: int = 1) -> dict[str, Any] | None:
    with session_scope() as ses:
        m = ses.execute(select(Market).where(Market.exchange_code == exchange, Market.symbol == symbol)).scalars().first()
        if m is None:
            return None
    forecasts = latest_forecasts().get((exchange, symbol, horizon), {})
    histories = {}
    for model in forecasts:
        histories[model] = forecast_history(exchange, symbol, horizon, model, limit=320)
    eval_run = latest_eval_run()
    metrics: dict[str, dict] = {}
    dm: list[dict] = []
    if eval_run:
        with session_scope() as ses:
            rows = ses.execute(
                select(BacktestResult).where(
                    BacktestResult.run_id == eval_run,
                    BacktestResult.scope == "asset",
                    BacktestResult.exchange_code == exchange,
                    BacktestResult.symbol == symbol,
                    BacktestResult.horizon == horizon,
                )
            ).scalars().all()
        for r in rows:
            if r.metric in ("rmse", "mae", "qlike", "bias") or r.metric.startswith("rmse_regime_"):
                metrics.setdefault(r.model_name, {})[r.metric] = r.value
            if r.metric.startswith("dm_qlike_vs_"):
                dm.append({
                    "model": r.model_name, "baseline": r.metric.replace("dm_qlike_vs_", ""),
                    "stat": r.value, "p_value": r.p_value, "n_obs": r.n_obs,
                })
    feature_importance = None
    if "xgb_extended" in forecasts:
        feature_importance = forecasts["xgb_extended"].get("config", {}).get("importance")
    coefs = None
    if "har_rv" in forecasts:
        coefs = forecasts["har_rv"].get("config", {})
    return {
        "exchange": exchange,
        "symbol": symbol,
        "horizon": horizon,
        "latest": forecasts,
        "consensus": consensus_forecast(forecasts),
        "history": histories,
        "metrics": metrics,
        "dm_tests": dm,
        "feature_importance": feature_importance,
        "har_coefficients": coefs,
        "evaluation_run": eval_run,
        "model_labels": MODEL_LABELS,
        "target_definition": TARGET_DEFINITION,
    }


def models_catalog() -> dict[str, Any]:
    with session_scope() as ses:
        regs = ses.execute(select(ModelRegistry).order_by(ModelRegistry.family, ModelRegistry.name)).scalars().all()
        counts = dict(
            ses.execute(select(Forecast.model_name, func.count()).group_by(Forecast.model_name)).all()
        )
        markets = ses.execute(
            select(Forecast.model_name, func.count(func.distinct(Forecast.exchange_code + ":" + Forecast.symbol)))
            .group_by(Forecast.model_name)
        ).all()
    market_counts = dict(markets)
    return {
        "models": [
            {
                "name": r.name, "version": r.version, "family": r.family, "description": r.description,
                "status": r.status, "params": json.loads(r.params_json) if r.params_json else {},
                "target_definition": r.target_definition, "trained_at": r.trained_at.isoformat() if r.trained_at else None,
                "forecast_rows": int(counts.get(r.name, 0)),
                "markets": int(market_counts.get(r.name, 0)),
                "label": MODEL_LABELS.get(r.name, r.name),
            }
            for r in regs
        ],
        "families": MODEL_FAMILIES,
        "versions": MODEL_VERSIONS,
    }


def research_summary() -> dict[str, Any]:
    s = effective_settings()
    eval_run = latest_eval_run()
    rows: list[dict[str, Any]] = []
    aggregate: list[dict[str, Any]] = []
    dm_summary: list[dict[str, Any]] = []
    if eval_run:
        with session_scope() as ses:
            rows = [
                {
                    "scope": r.scope, "exchange": r.exchange_code, "symbol": r.symbol,
                    "horizon": r.horizon, "model": r.model_name, "metric": r.metric,
                    "value": r.value, "n_obs": r.n_obs, "p_value": r.p_value,
                    "config": json.loads(r.config_json) if r.config_json else {},
                }
                for r in ses.execute(select(BacktestResult).where(BacktestResult.run_id == eval_run)).scalars()
            ]
    asset_rows = [r for r in rows if r["scope"] == "asset"]
    dm_rows = [r for r in rows if r["scope"] == "dm_test"]
    # Aggregate rows are stored as <metric>_mean / <metric>_median; expose the base
    # metric with both statistics so the UI never has to guess the suffix.
    agg_raw: dict[tuple[int, str, str], dict[str, Any]] = {}
    for r in rows:
        if r["scope"] != "aggregate" or r["model"] is None:
            continue
        metric = r["metric"]
        stat = None
        for suffix in ("_mean", "_median"):
            if metric.endswith(suffix):
                metric, stat = metric[: -len(suffix)], suffix[1:]
                break
        if stat is None:
            continue
        entry = agg_raw.setdefault((r["horizon"], r["model"], metric), {"n_obs": r["n_obs"]})
        entry[stat] = r["value"]
    aggregate = [
        {"horizon": h, "model": m, "metric": k, "value": v.get("mean"), "median": v.get("median"),
         "n_obs": v.get("n_obs")}
        for (h, m, k), v in sorted(agg_raw.items())
        if k in ("rmse", "mae", "qlike")
    ]
    # Regime-stratified RMSE: mean across markets for each regime bucket.
    regime_acc: dict[tuple[int, str, str], list[float]] = {}
    for r in asset_rows:
        if not r["metric"].startswith("rmse_regime_"):
            continue
        bucket = r["metric"].replace("rmse_regime_", "")
        if r["value"] is not None:
            regime_acc.setdefault((r["horizon"], r["model"], bucket), []).append(r["value"])
    regime_rows = [
        {"horizon": h, "model": m, "regime": b,
         "value": sum(vals) / len(vals), "n_markets": len(vals)}
        for (h, m, b), vals in sorted(regime_acc.items())
    ]
    for row in aggregate:
        bucket_vals = {
            b: (sum(v) / len(v), len(v))
            for (h, m, b), v in regime_acc.items()
            if h == row["horizon"] and m == row["model"]
        }
        row["regime_rmse"] = {b: {"value": v[0], "markets": v[1]} for b, v in bucket_vals.items()}
    # DM significance summary: share of markets where model beats HAR
    dm_summary_map: dict[tuple[int, str], dict[str, Any]] = {}
    for r in dm_rows:
        if r["metric"] != "dm_qlike_vs_har_rv" or r["model"] == "har_rv":
            continue
        k = (r["horizon"], r["model"])
        d = dm_summary_map.setdefault(k, {"horizon": r["horizon"], "model": r["model"], "n": 0, "significant_better": 0, "median_stat": []})
        d["n"] += 1
        if r["p_value"] is not None and r["p_value"] < 0.05 and r["value"] < 0:
            d["significant_better"] += 1
        if r["value"] is not None:
            d["median_stat"].append(r["value"])
    for d in dm_summary_map.values():
        stats = d.pop("median_stat")
        d["median_dm_stat"] = sorted(stats)[len(stats) // 2] if stats else None
        d["share_beating_har"] = d["significant_better"] / d["n"] if d["n"] else None
        dm_summary.append(d)
    dm_summary.sort(key=lambda x: (x["horizon"], x["model"]))
    per_asset = defaultdict(dict)
    for r in asset_rows:
        if r["metric"] not in ("rmse", "mae", "qlike"):
            continue
        per_asset[(r["exchange"], r["symbol"], r["horizon"])][f"{r['model']}_{r['metric']}"] = r["value"]
    with session_scope() as ses:
        n_targets = ses.execute(select(func.count()).select_from(RealizedTarget)).scalar_one()
        n_forecasts = ses.execute(select(func.count()).select_from(Forecast)).scalar_one()
        runs = ses.execute(
            select(ModelRun).where(ModelRun.kind.in_(["forecast", "risk", "evaluation"]))
            .order_by(ModelRun.started_at.desc()).limit(12)
        ).scalars().all()
    return {
        "evaluation_run": eval_run,
        "config": {
            "horizons": s.horizon_list,
            "walkforward_min_train": s.walkforward_min_train,
            "walkforward_refit_every": s.walkforward_refit_every,
            "risk_min_train": s.risk_min_train,
            "risk_refit_every": s.risk_refit_every,
            "max_test_days": 360,
            "target_definition": TARGET_DEFINITION,
            "purge": "training targets require i + h <= t (h-1 overlapping days purged)",
            "refit": "expanding window, no shuffling",
            "garch_min_obs": s.garch_min_obs,
            "evt_tail_fraction": s.evt_tail_fraction,
            "evt_min_exceedances": s.evt_min_exceedances,
            "var_confidences": s.confidence_list,
        },
        "aggregate": aggregate,
        "regime_rmse": regime_rows,
        "dm_summary": dm_summary,
        "per_asset": [
            {"exchange": k[0], "symbol": k[1], "horizon": k[2], "metrics": v} for k, v in sorted(per_asset.items())
        ],
        "coverage": {"forecast_rows": int(n_forecasts), "realized_targets": int(n_targets)},
        "runs": [
            {
                "id": r.id, "kind": r.kind, "status": r.status,
                "started_at": r.started_at.isoformat() if r.started_at else None,
                "finished_at": r.finished_at.isoformat() if r.finished_at else None,
                "metrics": json.loads(r.metrics_json) if r.metrics_json else None,
            }
            for r in runs
        ],
    }


def asset_feature_series(exchange: str, symbol: str, limit: int = 260) -> list[dict[str, Any]]:
    return feature_series(exchange, symbol, limit)

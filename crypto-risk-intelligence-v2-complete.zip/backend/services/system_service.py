"""System / exchange / data-quality read models."""
from __future__ import annotations

import json
import os
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any

from sqlalchemy import func, select, text

from backend.core.config import BASE_DIR, effective_settings, load_runtime_overrides, save_runtime_overrides
from backend.core.db import get_engine, session_scope
from backend.core.models import (
    Alert,
    DataQualityEvent,
    DerivativeMetric,
    EngineeredFeature,
    Exchange,
    Forecast,
    IngestionJob,
    Market,
    ModelRun,
    OHLCV,
    RealizedTarget,
    VarEsEstimate,
)
from backend.data_ingestion.live import STATE
from backend.services.analytics import finite, market_freshness


def health() -> dict[str, Any]:
    ok = True
    err = None
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
    except Exception as exc:  # noqa: BLE001
        ok = False
        err = str(exc)[:300]
    return {
        "status": "ok" if ok else "error",
        "service": "crypto-risk-intelligence-api",
        "version": "1.0.0",
        "time": datetime.now(timezone.utc).isoformat(),
        "database": {"ok": ok, "error": err},
        "live": {"started_at": STATE.started_at.isoformat() if STATE.started_at else None},
    }


def exchanges() -> dict[str, Any]:
    with session_scope() as ses:
        rows = ses.execute(select(Exchange).order_by(Exchange.code)).scalars().all()
        counts = dict(ses.execute(select(Market.exchange_code, func.count()).group_by(Market.exchange_code)).all())
        universe = dict(
            ses.execute(
                select(Market.exchange_code, func.count()).where(Market.in_universe.is_(True)).group_by(Market.exchange_code)
            ).all()
        )
    items = []
    for r in rows:
        caps = json.loads(r.capabilities) if r.capabilities else {}
        items.append({
            "code": r.code, "name": r.name, "market_types": r.market_types.split(","),
            "status": r.status, "status_detail": r.status_detail, "enabled": bool(r.enabled),
            "rest_url": r.rest_url, "ws_url": r.ws_url, "latency_ms": finite(r.latency_ms),
            "last_checked": r.last_checked_at.isoformat() if r.last_checked_at else None,
            "capabilities": caps, "notes": r.notes,
            "markets": int(counts.get(r.code, 0)), "universe_markets": int(universe.get(r.code, 0)),
            "live_status": STATE.exchange_status.get(r.code),
        })
    return {
        "exchanges": items,
        "connected": sum(1 for i in items if i["status"] == "ok"),
        "blocked": [i["code"] for i in items if i["status"] == "blocked"],
        "ws": STATE.exchange_status,
    }


def system_status() -> dict[str, Any]:
    s = effective_settings()
    now = datetime.now(timezone.utc)
    with session_scope() as ses:
        counts = {
            "markets": ses.execute(select(func.count()).select_from(Market)).scalar_one(),
            "markets_in_universe": ses.execute(
                select(func.count()).select_from(Market).where(Market.in_universe.is_(True))
            ).scalar_one(),
            "markets_model_eligible": ses.execute(
                select(func.count()).select_from(Market).where(Market.model_eligible.is_(True))
            ).scalar_one(),
            "ohlcv_rows": ses.execute(select(func.count()).select_from(OHLCV)).scalar_one(),
            "feature_rows": ses.execute(select(func.count()).select_from(EngineeredFeature)).scalar_one(),
            "forecast_rows": ses.execute(select(func.count()).select_from(Forecast)).scalar_one(),
            "var_es_rows": ses.execute(select(func.count()).select_from(VarEsEstimate)).scalar_one(),
            "targets": ses.execute(select(func.count()).select_from(RealizedTarget)).scalar_one(),
            "derivative_rows": ses.execute(select(func.count()).select_from(DerivativeMetric)).scalar_one(),
            "alerts_active": ses.execute(
                select(func.count()).select_from(Alert).where(
                    Alert.acknowledged.is_(False), Alert.resolved_at.is_(None)
                )
            ).scalar_one(),
        }
        runs = ses.execute(select(ModelRun).order_by(ModelRun.started_at.desc()).limit(20)).scalars().all()
        jobs = ses.execute(select(IngestionJob).order_by(IngestionJob.started_at.desc()).limit(20)).scalars().all()
        markets = ses.execute(select(Market).where(Market.in_universe.is_(True))).scalars().all()
        dq = ses.execute(
            select(DataQualityEvent.event_type, DataQualityEvent.severity, func.count())
            .where(DataQualityEvent.ts >= now - timedelta(days=7))
            .group_by(DataQualityEvent.event_type, DataQualityEvent.severity)
        ).all()
        last_feature = ses.execute(select(func.max(EngineeredFeature.bar_date))).scalar()
    freshness: dict[str, int] = {}
    for m in markets:
        st = market_freshness(m.exchange_code, m.symbol, m.last_update_ts)
        freshness[st] = freshness.get(st, 0) + 1
    db_path = s.database_url.replace("sqlite:///", "")
    storage = None
    if s.database_url.startswith("sqlite") and os.path.exists(db_path):
        storage = {"database_bytes": os.path.getsize(db_path)}
    return {
        "server_time": now.isoformat(),
        "counts": {k: int(v) for k, v in counts.items()},
        "pipeline": {
            "runs": [
                {
                    "id": r.id, "kind": r.kind, "status": r.status,
                    "started_at": r.started_at.isoformat() if r.started_at else None,
                    "finished_at": r.finished_at.isoformat() if r.finished_at else None,
                    "metrics": json.loads(r.metrics_json) if r.metrics_json else None,
                    "error": r.error,
                }
                for r in runs
            ],
            "ingestion_jobs": [
                {
                    "id": j.id, "kind": j.kind, "exchange": j.exchange_code, "symbol": j.symbol,
                    "timeframe": j.timeframe, "status": j.status, "rows_written": j.rows_written,
                    "started_at": j.started_at.isoformat() if j.started_at else None,
                    "finished_at": j.finished_at.isoformat() if j.finished_at else None,
                    "error": j.error,
                }
                for j in jobs
            ],
        },
        "data_freshness": freshness,
        "last_feature_date": last_feature,
        "data_quality": [
            {"event_type": e, "severity": sev, "count": int(c)} for e, sev, c in dq
        ],
        "live": STATE.status(),
        "storage": storage,
        "config": {
            "bar_timeframe": s.bar_timeframe,
            "ingest_lookback_days": s.ingest_lookback_days,
            "horizons": s.horizon_list,
            "var_confidences": s.confidence_list,
            "target_markets": s.target_markets,
            "model_market_limit": s.model_market_limit,
            "min_quote_volume_usd": s.min_quote_volume_usd,
            "min_history_days": s.min_history_days,
            "min_data_completeness": s.min_data_completeness,
            "enable_websocket": s.enable_websocket,
            "background_jobs": s.enable_background_jobs,
            "environment": s.environment,
        },
        "runtime_overrides": load_runtime_overrides(),
    }


def data_quality(severity: str | None = None, exchange: str | None = None, limit: int = 100) -> dict[str, Any]:
    with session_scope() as ses:
        q = select(DataQualityEvent).order_by(DataQualityEvent.ts.desc())
        if severity:
            q = q.where(DataQualityEvent.severity == severity)
        if exchange:
            q = q.where(DataQualityEvent.exchange_code == exchange)
        rows = ses.execute(q.limit(limit)).scalars().all()
        summary = ses.execute(
            select(DataQualityEvent.event_type, DataQualityEvent.severity, func.count())
            .group_by(DataQualityEvent.event_type, DataQualityEvent.severity)
        ).all()
    return {
        "items": [
            {
                "id": r.id, "ts": r.ts.isoformat(), "exchange": r.exchange_code, "symbol": r.symbol,
                "timeframe": r.timeframe, "event_type": r.event_type, "severity": r.severity,
                "details": json.loads(r.details_json) if r.details_json else {},
            }
            for r in rows
        ],
        "summary": [{"event_type": e, "severity": s, "count": int(c)} for e, s, c in summary],
    }


def get_settings() -> dict[str, Any]:
    s = effective_settings()
    return {
        "effective": {
            k: getattr(s, k)
            for k in (
                "min_quote_volume_usd", "max_spread_bps", "target_markets", "min_history_days",
                "min_observations", "min_data_completeness", "horizons", "var_confidences",
                "alert_forecast_vol_annualized", "alert_price_move_pct", "alert_spread_bps",
                "alert_cooldown_minutes", "live_poll_seconds", "bar_timeframe",
                "ingest_lookback_days", "walkforward_min_train", "walkforward_refit_every",
                "risk_min_train", "evt_tail_fraction", "evt_min_exceedances",
            )
        },
        "overrides": load_runtime_overrides(),
        "editable": [
            "min_quote_volume_usd", "max_spread_bps", "target_markets", "min_history_days",
            "min_observations", "min_data_completeness", "alert_forecast_vol_annualized",
            "alert_price_move_pct", "alert_spread_bps", "alert_cooldown_minutes",
            "live_poll_seconds", "horizons", "var_confidences",
        ],
    }


def update_settings(values: dict[str, Any]) -> dict[str, Any]:
    save_runtime_overrides(values)
    return get_settings()

"""Rule-based risk monitoring engine with deduplication/cooldown."""
from __future__ import annotations

import json
import math
from datetime import datetime, timedelta, timezone
from typing import Any

import numpy as np
from sqlalchemy import func, select, text

from backend.core.config import effective_settings
from backend.core.db import get_engine, session_scope
from backend.core.models import Alert, DataQualityEvent, Market
from backend.services.analytics import (
    consensus_forecast,
    latest_forecasts,
    latest_var_es,
    load_universe_metrics,
    market_freshness,
)


def _add(ses, seen: set[str], *, alert_type: str, severity: str, trigger: str, message: str,
         exchange: str | None, symbol: str | None, observed: float | None, threshold: float | None,
         cooldown_minutes: int) -> bool:
    bucket = int(datetime.now(timezone.utc).timestamp() // max(cooldown_minutes, 1) / 60)
    key = f"{alert_type}:{exchange}:{symbol}:{bucket}"
    if key in seen:
        return False
    exists = ses.execute(select(Alert.id).where(Alert.dedupe_key == key)).first()
    if exists:
        return False
    ses.add(Alert(
        dedupe_key=key, exchange_code=exchange, symbol=symbol, severity=severity,
        alert_type=alert_type, trigger=trigger, message=message,
        observed_value=observed, threshold=threshold,
    ))
    seen.add(key)
    return True


def generate_alerts() -> dict[str, Any]:
    s = effective_settings()
    metrics = load_universe_metrics()
    forecasts = latest_forecasts()
    var_map = latest_var_es()
    created = 0
    seen: set[str] = set()
    with session_scope() as ses:
        markets = ses.execute(select(Market)).scalars().all()
        recent_dq = ses.execute(
            select(DataQualityEvent).where(
                DataQualityEvent.ts >= datetime.now(timezone.utc) - timedelta(hours=24),
                DataQualityEvent.severity.in_(["warning", "critical"]),
            )
        ).scalars().all()
        for m in markets:
            if not m.in_universe:
                continue
            key = f"{m.exchange_code}:{m.symbol}"
            met = metrics.get(key, {})
            f1 = forecasts.get((m.exchange_code, m.symbol, 1)) or {}
            cons = consensus_forecast(f1)
            if cons and cons["predicted_vol_annualized"] is not None:
                vol = cons["predicted_vol_annualized"]
                if vol >= s.alert_forecast_vol_annualized:
                    created += _add(
                        ses, seen, alert_type="high_forecast_vol",
                        severity="critical" if vol >= s.alert_forecast_vol_annualized * 1.5 else "warning",
                        trigger="forecast_vol_1d > threshold",
                        message=f"1-day forecast annualized volatility {vol*100:.1f}% exceeds {s.alert_forecast_vol_annualized*100:.0f}%",
                        exchange=m.exchange_code, symbol=m.symbol, observed=vol,
                        threshold=s.alert_forecast_vol_annualized, cooldown_minutes=s.alert_cooldown_minutes,
                    )
            if m.price_change_24h_pct is not None and abs(m.price_change_24h_pct) >= s.alert_price_move_pct:
                created += _add(
                    ses, seen, alert_type="price_move",
                    severity="critical" if abs(m.price_change_24h_pct) >= 2 * s.alert_price_move_pct else "warning",
                    trigger="abs(24h price change) > threshold",
                    message=f"24h move {m.price_change_24h_pct:.2f}% on {m.exchange_code}:{m.symbol}",
                    exchange=m.exchange_code, symbol=m.symbol, observed=float(m.price_change_24h_pct),
                    threshold=s.alert_price_move_pct, cooldown_minutes=s.alert_cooldown_minutes,
                )
            if m.spread_bps is not None and m.spread_bps >= s.alert_spread_bps:
                created += _add(
                    ses, seen, alert_type="wide_spread", severity="warning",
                    trigger="spread_bps > threshold",
                    message=f"Bid-ask spread {m.spread_bps:.1f}bps on {m.exchange_code}:{m.symbol}",
                    exchange=m.exchange_code, symbol=m.symbol, observed=float(m.spread_bps),
                    threshold=s.alert_spread_bps, cooldown_minutes=s.alert_cooldown_minutes,
                )
            freshness = market_freshness(m.exchange_code, m.symbol, m.last_update_ts)
            if freshness in ("stale", "disconnected"):
                created += _add(
                    ses, seen, alert_type="stale_data",
                    severity="critical" if freshness == "disconnected" else "warning",
                    trigger=f"data freshness = {freshness}",
                    message=f"Market data is {freshness} for {m.exchange_code}:{m.symbol}",
                    exchange=m.exchange_code, symbol=m.symbol, observed=None, threshold=None,
                    cooldown_minutes=s.alert_cooldown_minutes,
                )
            # VaR breach on the most recent realized day
            est = var_map.get((m.exchange_code, m.symbol, 0.99), {})
            for method in ("garch_evt", "garch_t", "historical"):
                payload = est.get(method)
                if payload and payload.get("breach"):
                    created += _add(
                        ses, seen, alert_type="var_breach", severity="critical",
                        trigger=f"{method} VaR 99% breached",
                        message=f"Loss {payload.get('actual_loss_pct'):.2f}% exceeded predicted VaR {payload.get('var_pct'):.2f}% ({method})",
                        exchange=m.exchange_code, symbol=m.symbol,
                        observed=payload.get("actual_loss_pct"), threshold=payload.get("var_pct"),
                        cooldown_minutes=s.alert_cooldown_minutes,
                    )
                    break
        for dq in recent_dq:
            if dq.event_type in ("missing_candles", "duplicate_records", "invalid_ohlcv", "implausible_return"):
                created += _add(
                    ses, seen, alert_type="data_quality", severity="warning" if dq.severity == "warning" else "critical",
                    trigger=dq.event_type,
                    message=f"Data-quality event {dq.event_type} on {dq.exchange_code}:{dq.symbol}",
                    exchange=dq.exchange_code, symbol=dq.symbol, observed=None, threshold=None,
                    cooldown_minutes=24 * 60,
                )
        # model drift on realized QLIKE of HAR forecasts
        drift = _model_drift()
        for row in drift:
            if row["ratio"] and row["ratio"] > 1.5:
                created += _add(
                    ses, seen, alert_type="model_drift", severity="warning",
                    trigger="rolling_30d_qlike > 1.5x test median",
                    message=f"HAR-RV QLIKE drift {row['ratio']:.2f}x on {row['exchange']}:{row['symbol']}",
                    exchange=row["exchange"], symbol=row["symbol"], observed=row["ratio"], threshold=1.5,
                    cooldown_minutes=24 * 60,
                )
        resolved = auto_resolve(ses)
    return {"alerts_created": created, "alerts_resolved": resolved}


def _model_drift() -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT f.exchange_code, f.symbol, f.bar_date, f.predicted_rv, f.actual_rv
        FROM forecasts f
        WHERE f.model_name = 'har_rv' AND f.horizon = 1 AND f.actual_rv IS NOT NULL
        ORDER BY f.exchange_code, f.symbol, f.bar_date
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql).mappings().all()
    grouped: dict[tuple[str, str], list] = {}
    for r in rows:
        grouped.setdefault((r["exchange_code"], r["symbol"]), []).append(r)
    out = []
    for (ex, sym), series in grouped.items():
        if len(series) < 90:
            continue
        pred = np.array([r["predicted_rv"] for r in series], dtype=float)
        act = np.array([r["actual_rv"] for r in series], dtype=float)
        m = np.isfinite(pred) & np.isfinite(act) & (pred > 0) & (act > 0)
        pred, act = pred[m], act[m]
        if pred.size < 90:
            continue
        ratio = np.clip(act / pred, 1e-10, None)
        losses = ratio - np.log(ratio) - 1
        recent = float(np.mean(losses[-30:]))
        baseline = float(np.median(losses))
        out.append({
            "exchange": ex, "symbol": sym, "recent_qlike": recent, "baseline_qlike": baseline,
            "ratio": (recent / baseline) if baseline > 0 else None,
        })
    return out


STALE_TYPES = ("stale_data",)
DEFAULT_ALERT_TTL_HOURS = 168  # a week: an unresolved condition older than this is expired, not hidden


def auto_resolve(ses, *, ttl_hours: int = DEFAULT_ALERT_TTL_HOURS) -> int:
    """Close alerts whose condition has cleared or that have gone stale.

    * `stale_data` alerts are resolved as soon as the market's feed reports
      `live` or `delayed` again — the condition genuinely ended.
    * Any still-open alert older than `ttl_hours` is expired, so the active count
      cannot creep upward forever because nobody clicked "ack".

    Nothing is deleted: the row keeps its observation, the reason and the time.
    """
    now = datetime.now(timezone.utc)
    resolved = 0
    open_alerts = ses.execute(select(Alert).where(Alert.resolved_at.is_(None))).scalars().all()
    for a in open_alerts:
        if a.alert_type in STALE_TYPES and a.exchange_code and a.symbol:
            m = ses.execute(
                select(Market).where(Market.exchange_code == a.exchange_code, Market.symbol == a.symbol)
            ).scalars().first()
            freshness = market_freshness(a.exchange_code, a.symbol, m.last_update_ts if m else None)
            if freshness in ("live", "delayed"):
                a.resolved_at = now
                a.resolved_reason = f"feed recovered ({freshness})"
                resolved += 1
                continue
        ts = a.ts if a.ts.tzinfo else a.ts.replace(tzinfo=timezone.utc)
        if (now - ts) > timedelta(hours=ttl_hours):
            a.resolved_at = now
            a.resolved_reason = f"expired after {ttl_hours}h without acknowledgement"
            resolved += 1
    return resolved


def list_alerts(
    severity: str | None = None,
    acknowledged: bool | None = None,
    active_only: bool = False,
    limit: int = 100,
) -> dict[str, Any]:
    with session_scope() as ses:
        q = select(Alert).order_by(Alert.ts.desc())
        if severity:
            q = q.where(Alert.severity == severity)
        if acknowledged is not None:
            q = q.where(Alert.acknowledged.is_(acknowledged))
        if active_only:
            q = q.where(Alert.resolved_at.is_(None), Alert.acknowledged.is_(False))
        rows = ses.execute(q.limit(limit)).scalars().all()
        is_active = (Alert.resolved_at.is_(None)) & (Alert.acknowledged.is_(False))
        counts = dict(ses.execute(select(Alert.severity, func.count()).where(is_active).group_by(Alert.severity)).all())
        total = ses.execute(select(func.count()).select_from(Alert)).scalar_one()
        active = ses.execute(select(func.count()).select_from(Alert).where(is_active)).scalar_one()
        resolved_total = ses.execute(
            select(func.count()).select_from(Alert).where(Alert.resolved_at.is_not(None))
        ).scalar_one()
    return {
        "items": [
            {
                "id": a.id, "ts": a.ts.isoformat(), "exchange": a.exchange_code, "symbol": a.symbol,
                "severity": a.severity, "type": a.alert_type, "trigger": a.trigger,
                "message": a.message, "observed": a.observed_value, "threshold": a.threshold,
                "acknowledged": a.acknowledged,
                "resolved_at": a.resolved_at.isoformat() if a.resolved_at else None,
                "resolved_reason": a.resolved_reason,
                "active": a.resolved_at is None and not a.acknowledged,
            }
            for a in rows
        ],
        "counts": {k: int(v) for k, v in counts.items()},
        "total": int(total),
        "active": int(active),
        "resolved": int(resolved_total),
    }


def acknowledge_alert(alert_id: int) -> bool:
    with session_scope() as ses:
        a = ses.get(Alert, alert_id)
        if a is None:
            return False
        a.acknowledged = True
    return True

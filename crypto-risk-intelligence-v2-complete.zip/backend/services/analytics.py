"""Read-side analytics shared by the API services.

All numbers are derived from persisted market data / model outputs; nothing is
simulated. Expensive aggregates are cached briefly (in-process TTL cache).
"""
from __future__ import annotations

import json
import math
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Callable, Iterable

import numpy as np
from sqlalchemy import text

from backend.core.config import effective_settings
from backend.core.db import get_engine
from backend.data_ingestion.live import STATE, classify_freshness, market_live_status

HORIZON_LABELS = {1: "1d", 7: "7d", 30: "30d"}
METHOD_LABELS = {
    "historical": "Historical",
    "garch_normal": "GARCH-Normal",
    "garch_t": "GARCH-Student-t",
    "garch_evt": "GARCH-EVT (POT)",
}
MODEL_LABELS = {
    "naive": "Naive RW",
    "har_rv": "HAR-RV",
    "garch_normal": "GARCH-N",
    "garch_t": "GARCH-t",
    "xgb_har": "XGBoost-HAR",
    "xgb_extended": "XGBoost-extended",
}


class TTLCache:
    def __init__(self) -> None:
        self._store: dict[str, tuple[float, Any]] = {}

    def get(self, key: str) -> Any | None:
        item = self._store.get(key)
        if not item:
            return None
        ts, value = item
        if time.time() - ts > self.ttl:
            self._store.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any) -> Any:
        self._store[key] = (time.time(), value)
        return value

    ttl = 20.0


CACHE = TTLCache()


def cached(key: str, fn: Callable[[], Any], ttl: float | None = None) -> Any:
    val = CACHE.get(key)
    if val is not None:
        return val
    if ttl is not None:
        CACHE.ttl = ttl
    return CACHE.set(key, fn())


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _iso(dt: Any) -> str | None:
    """Accept datetime or the ISO strings SQLite returns from text() queries."""
    if dt is None:
        return None
    if isinstance(dt, str):
        try:
            dt = datetime.fromisoformat(dt.replace("Z", "+00:00"))
        except ValueError:
            return dt
    if not isinstance(dt, datetime):
        return str(dt)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(timezone.utc).isoformat()


def finite(v: Any) -> float | None:
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


# ---------------------------------------------------------------- markets ---
def load_universe_metrics() -> dict[str, dict[str, Any]]:
    """Latest feature context per in-universe market, with regime thresholds."""

    def _load() -> dict[str, dict[str, Any]]:
        sql = text(
            """
            SELECT f.exchange_code, f.symbol, f.bar_date, f.rv, f.rv_w, f.rv_m, f.close,
                   f.ret_pct, f.range_pct, f.quote_volume, f.volume_z, f.completeness,
                   f.funding_rate, f.open_interest, f.features_json
            FROM engineered_features f
            JOIN markets m ON m.exchange_code = f.exchange_code AND m.symbol = f.symbol
            WHERE m.in_universe = 1
            ORDER BY f.exchange_code, f.symbol, f.bar_date
            """
        )
        with get_engine().connect() as conn:
            rows = conn.execute(sql).mappings().all()
        grouped: dict[str, list[dict[str, Any]]] = {}
        for r in rows:
            grouped.setdefault(f"{r['exchange_code']}:{r['symbol']}", []).append(dict(r))
        out: dict[str, dict[str, Any]] = {}
        for key, series in grouped.items():
            latest = series[-1]
            trailing = series[-181:]
            rv_hist = np.array([x["rv"] for x in trailing if x["rv"] is not None], dtype=float)
            rv_hist = rv_hist[np.isfinite(rv_hist)]
            thresholds = {}
            if rv_hist.size >= 60:
                thresholds = {
                    "p50": float(np.quantile(rv_hist, 0.50)),
                    "p80": float(np.quantile(rv_hist, 0.80)),
                    "p95": float(np.quantile(rv_hist, 0.95)),
                }
            regime = "insufficient_data"
            rv = finite(latest["rv"])
            if rv is not None and thresholds:
                if rv >= thresholds["p95"]:
                    regime = "extreme"
                elif rv >= thresholds["p80"]:
                    regime = "high"
                elif rv >= thresholds["p50"]:
                    regime = "normal"
                else:
                    regime = "low"
            extras = json.loads(latest["features_json"]) if latest["features_json"] else {}
            out[key] = {
                "bar_date": latest["bar_date"],
                "rv": rv,
                "rv_w": finite(latest["rv_w"]),
                "rv_m": finite(latest["rv_m"]),
                "rv_ann_vol": math.sqrt(rv * 365) / 100 if rv else None,  # fraction
                "close": finite(latest["close"]),
                "ret_pct": finite(latest["ret_pct"]),
                "range_pct": finite(latest["range_pct"]),
                "volume_z": finite(latest["volume_z"]),
                "quote_volume": finite(latest["quote_volume"]),
                "completeness": finite(latest["completeness"]),
                "funding_rate": finite(latest["funding_rate"]),
                "open_interest": finite(latest["open_interest"]),
                "jump_ratio": finite(extras.get("jump_ratio")),
                "regime": regime,
                "regime_thresholds": thresholds,
                "rv_percentile": float((rv_hist <= rv).mean()) if rv is not None and rv_hist.size else None,
                "history_days": len(series),
            }
        return out

    return cached("universe_metrics", _load, ttl=30)


def latest_forecasts() -> dict[tuple[str, str, int], dict[str, dict[str, Any]]]:
    """market key -> horizon -> model -> latest forecast row."""

    def _load() -> dict[tuple[str, str, int], dict[str, dict[str, Any]]]:
        sql = text(
            """
            SELECT f.exchange_code, f.symbol, f.horizon, f.model_name, f.bar_date,
                   f.predicted_rv, f.predicted_vol_annualized, f.actual_rv, f.data_cutoff_ts,
                   f.forecast_ts, f.config_json, f.run_id
            FROM forecasts f
            JOIN (
                SELECT exchange_code, symbol, horizon, model_name, MAX(bar_date) AS md
                FROM forecasts GROUP BY exchange_code, symbol, horizon, model_name
            ) latest
              ON latest.exchange_code = f.exchange_code AND latest.symbol = f.symbol
             AND latest.horizon = f.horizon AND latest.model_name = f.model_name
             AND latest.md = f.bar_date
            ORDER BY f.forecast_ts
            """
        )
        with get_engine().connect() as conn:
            rows = conn.execute(sql).mappings().all()
        out: dict[tuple[str, str, int], dict[str, dict[str, Any]]] = {}
        for r in rows:
            key = (r["exchange_code"], r["symbol"], int(r["horizon"]))
            vol = finite(r["predicted_vol_annualized"])
            out.setdefault(key, {})[r["model_name"]] = {
                "predicted_rv": finite(r["predicted_rv"]),
                # stored as annualized percent -> exposed as a fraction (0.35 = 35%)
                "predicted_vol_annualized": (vol / 100.0) if vol is not None else None,
                "actual_rv": finite(r["actual_rv"]),
                "bar_date": r["bar_date"],
                "forecast_ts": _iso(r["forecast_ts"]),
                "data_cutoff_ts": _iso(r["data_cutoff_ts"]),
                "run_id": r["run_id"],
                "config": json.loads(r["config_json"]) if r["config_json"] else {},
            }
        return out

    return cached("latest_forecasts", _load, ttl=30)


def consensus_forecast(models: dict[str, dict[str, Any]] | None) -> dict[str, Any] | None:
    if not models:
        return None
    vals = [m["predicted_rv"] for m in models.values() if m.get("predicted_rv")]
    if not vals:
        return None
    median = float(np.median(vals))
    return {
        "predicted_rv_median": median,
        "predicted_vol_annualized": math.sqrt(median * 365) / 100,
        "dispersion": float(np.std(vals) / np.mean(vals)) if np.mean(vals) else None,
        "models": sorted(models.keys()),
    }


def latest_var_es() -> dict[tuple[str, str, float], dict[str, dict[str, Any]]]:
    def _load() -> dict[tuple[str, str, float], dict[str, dict[str, Any]]]:
        sql = text(
            """
            SELECT v.exchange_code, v.symbol, v.confidence, v.model_name, v.asof_date,
                   v.var_pct, v.es_pct, v.actual_loss_pct, v.breach, v.xi, v.threshold, v.n_exceedances,
                   v.sigma, v.mu
            FROM var_es_estimates v
            JOIN (
                SELECT exchange_code, symbol, confidence, model_name, MAX(asof_date) AS md
                FROM var_es_estimates GROUP BY exchange_code, symbol, confidence, model_name
            ) latest
              ON latest.exchange_code = v.exchange_code AND latest.symbol = v.symbol
             AND latest.confidence = v.confidence AND latest.model_name = v.model_name
             AND latest.md = v.asof_date
            """
        )
        with get_engine().connect() as conn:
            rows = conn.execute(sql).mappings().all()
        out: dict[tuple[str, str, float], dict[str, dict[str, Any]]] = {}
        for r in rows:
            key = (r["exchange_code"], r["symbol"], float(r["confidence"]))
            out.setdefault(key, {})[r["model_name"]] = {
                "var_pct": finite(r["var_pct"]),
                "es_pct": finite(r["es_pct"]),
                "asof_date": r["asof_date"],
                "breach": r["breach"],
                "actual_loss_pct": finite(r["actual_loss_pct"]),
                "xi": finite(r["xi"]),
                "threshold": finite(r["threshold"]),
                "sigma": finite(r["sigma"]),
                "mu": finite(r["mu"]),
                "n_exceedances": r["n_exceedances"],
            }
        return out

    return cached("latest_var_es", _load, ttl=30)


def market_freshness(exchange: str, symbol: str, last_update: datetime | None) -> str:
    return market_live_status(exchange, symbol, last_update)


def live_quote(exchange: str, symbol: str) -> dict[str, Any] | None:
    entry = STATE.latest.get(STATE.key(exchange, symbol))
    if not entry:
        return None
    ev = entry.get("event_ts")
    if isinstance(ev, str):
        try:
            ev = datetime.fromisoformat(ev)
        except ValueError:
            ev = None
    return {
        "price": entry.get("price"),
        "bid": entry.get("bid"),
        "ask": entry.get("ask"),
        "spread_bps": entry.get("spread_bps"),
        "source": entry.get("source"),
        "received_at": entry.get("received_at"),
        "event_ts": ev.isoformat() if isinstance(ev, datetime) else None,
        "freshness": classify_freshness(ev if isinstance(ev, datetime) else None),
    }


# ----------------------------------------------------------------- series ---
def feature_series(exchange: str, symbol: str, limit: int = 260) -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT bar_date, close, ret_pct, rv, rv_w, rv_m, range_pct, volume, quote_volume,
               volume_z, completeness, features_json
        FROM engineered_features
        WHERE exchange_code = :e AND symbol = :s
        ORDER BY bar_date DESC LIMIT :n
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"e": exchange, "s": symbol, "n": limit}).mappings().all()
    out = []
    for r in reversed(rows):
        extras = json.loads(r["features_json"]) if r["features_json"] else {}
        out.append({
            "date": r["bar_date"],
            "close": finite(r["close"]),
            "ret_pct": finite(r["ret_pct"]),
            "rv": finite(r["rv"]),
            "rv_w": finite(r["rv_w"]),
            "rv_m": finite(r["rv_m"]),
            "range_pct": finite(r["range_pct"]),
            "volume": finite(r["volume"]),
            "quote_volume": finite(r["quote_volume"]),
            "volume_z": finite(r["volume_z"]),
            "completeness": finite(r["completeness"]),
            "jump": finite(extras.get("jump")),
            "jump_ratio": finite(extras.get("jump_ratio")),
            "semivar_neg_ratio": finite(extras.get("semivar_neg_ratio")),
            "rv_ann_vol": (math.sqrt(r["rv"] * 365) / 100) if r["rv"] else None,
        })
    return out


def ohlcv_series(exchange: str, symbol: str, timeframe: str, limit: int = 400) -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT ts, open, high, low, close, volume, quote_volume, is_final
        FROM ohlcv WHERE exchange_code=:e AND symbol=:s AND timeframe=:t
        ORDER BY ts DESC LIMIT :n
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"e": exchange, "s": symbol, "t": timeframe, "n": limit}).mappings().all()
    return [
        {
            "ts": int(r["ts"]),
            "time": datetime.fromtimestamp(r["ts"] / 1000, tz=timezone.utc).isoformat(),
            "open": r["open"], "high": r["high"], "low": r["low"], "close": r["close"],
            "volume": r["volume"], "quote_volume": r["quote_volume"], "is_final": bool(r["is_final"]),
        }
        for r in reversed(rows)
    ]


def forecast_history(exchange: str, symbol: str, horizon: int, model: str, limit: int = 365) -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT bar_date, predicted_rv, predicted_vol_annualized, actual_rv, target_start_date,
               target_end_date, model_version, run_id, data_cutoff_ts
        FROM forecasts
        WHERE exchange_code=:e AND symbol=:s AND horizon=:h AND model_name=:m
        ORDER BY bar_date DESC LIMIT :n
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"e": exchange, "s": symbol, "h": horizon, "m": model, "n": limit}).mappings().all()
    return [
        {
            "date": r["bar_date"],
            "predicted_rv": finite(r["predicted_rv"]),
            "predicted_vol": (finite(r["predicted_vol_annualized"]) / 100.0)
            if finite(r["predicted_vol_annualized"]) is not None else None,
            "actual_rv": finite(r["actual_rv"]),
            "actual_vol": (math.sqrt(r["actual_rv"] * 365) / 100) if r["actual_rv"] else None,
            "target_start": r["target_start_date"], "target_end": r["target_end_date"],
            "model_version": r["model_version"], "run_id": r["run_id"],
        }
        for r in reversed(rows)
    ]


def var_es_history(exchange: str, symbol: str, confidence: float, model: str, limit: int = 400) -> list[dict[str, Any]]:
    sql = text(
        """
        SELECT asof_date, var_pct, es_pct, actual_loss_pct, breach, sigma, mu, xi
        FROM var_es_estimates
        WHERE exchange_code=:e AND symbol=:s AND confidence=:c AND model_name=:m
        ORDER BY asof_date DESC LIMIT :n
        """
    )
    with get_engine().connect() as conn:
        rows = conn.execute(sql, {"e": exchange, "s": symbol, "c": confidence, "m": model, "n": limit}).mappings().all()
    return [
        {
            "date": r["asof_date"], "var_pct": finite(r["var_pct"]), "es_pct": finite(r["es_pct"]),
            "actual_loss_pct": finite(r["actual_loss_pct"]), "breach": r["breach"],
            "sigma": finite(r["sigma"]), "mu": finite(r["mu"]), "xi": finite(r["xi"]),
        }
        for r in reversed(rows)
    ]


def regime_for(rv: float | None, thresholds: dict[str, float] | None) -> str:
    if rv is None or not thresholds:
        return "insufficient_data"
    if rv >= thresholds["p95"]:
        return "extreme"
    if rv >= thresholds["p80"]:
        return "high"
    if rv >= thresholds["p50"]:
        return "normal"
    return "low"


def pct(v: float | None) -> float | None:
    return None if v is None else round(v * 100, 4)

"""Background scheduler for live data + periodic maintenance.

Model retraining is intentionally *not* tied to ticks: forecasts/risk runs are
scheduled daily (opt-in) or triggered explicitly via CLI/API. Ingestion is
decoupled from inference so a price tick never causes a refit.
"""
from __future__ import annotations

import asyncio
import time
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable

from sqlalchemy import delete, select

from backend.core.config import effective_settings
from backend.core.db import session_scope
from backend.core.logging import get_logger
from backend.core.models import MarketSnapshot
from backend.data_ingestion.live import INGESTOR, STATE
from backend.data_ingestion.universe import UniverseService

log = get_logger("scheduler")


class Scheduler:
    def __init__(self) -> None:
        self.settings = effective_settings()
        self.tasks: list[asyncio.Task] = []
        self.job_state: dict[str, dict[str, Any]] = {}
        self._stop = asyncio.Event()

    def _record(self, name: str, status: str, detail: str | None = None) -> None:
        self.job_state[name] = {
            "status": status,
            "last_run": datetime.now(timezone.utc).isoformat(),
            "detail": detail,
        }

    async def _loop(self, name: str, interval: int, fn: Callable[[], Awaitable[Any]], initial_delay: int = 5) -> None:
        await asyncio.sleep(initial_delay)
        while not self._stop.is_set():
            try:
                self._record(name, "running")
                result = await fn()
                self._record(name, "ok", str(result)[:300] if result else None)
            except asyncio.CancelledError:
                raise
            except Exception as exc:  # noqa: BLE001
                self._record(name, "error", str(exc)[:300])
                log.warning(f"scheduled job {name} failed: {exc}")
            try:
                await asyncio.wait_for(self._stop.wait(), timeout=interval)
            except asyncio.TimeoutError:
                continue

    async def _incremental_ingest(self) -> str:
        from backend.data_ingestion.historical import ingest_universe, refresh_eligibility

        res = await ingest_universe(lookback_days=7)
        refresh_eligibility()
        return f"ingested {res['success']}/{res['markets']} markets, {res['bars']} bars"

    async def _refresh_universe(self) -> str:
        svc = UniverseService()
        await svc.probe_exchanges()
        res = await svc.discover()
        return f"discovered {res['discovered']} markets, selected {res['selected_count']}"

    async def _derivatives(self) -> str:
        from backend.data_ingestion.historical import update_derivative_metrics

        return str(await update_derivative_metrics())

    async def _alerts(self) -> str:
        from backend.services.alert_service import generate_alerts

        return str(generate_alerts())

    async def _rebuild_features(self) -> str:
        from backend.features.pipeline import build_all_features

        return str(build_all_features())

    async def _prune(self) -> str:
        cutoff = datetime.now(timezone.utc) - timedelta(days=7)
        with session_scope() as ses:
            res = ses.execute(delete(MarketSnapshot).where(MarketSnapshot.ts < cutoff))
        return f"pruned snapshots: {res.rowcount}"

    async def _daily_models(self) -> str:
        from backend.features.pipeline import build_all_features
        from backend.quant.evaluation import run_evaluation
        from backend.quant.walkforward import run_forecast_pipeline
        from backend.risk.var_es import run_risk_pipeline

        build_all_features()
        fc = run_forecast_pipeline()
        var = run_risk_pipeline()
        ev = run_evaluation()
        return f"forecast {fc.get('forecast_rows')} rows; risk {var.get('estimate_rows')} rows; eval {ev.get('rows')} rows"

    async def start(self) -> None:
        if self.tasks:
            return
        await INGESTOR.start()
        self.tasks.append(asyncio.create_task(self._loop("alerts", 300, self._alerts, 45), name="job_alerts"))
        self.tasks.append(asyncio.create_task(self._loop("derivatives", 600, self._derivatives, 20), name="job_derivatives"))
        self.tasks.append(asyncio.create_task(self._loop("incremental_ingest", 3600, self._incremental_ingest, 120), name="job_ingest"))
        self.tasks.append(asyncio.create_task(self._loop("universe_refresh", 21600, self._refresh_universe, 300), name="job_universe"))
        self.tasks.append(asyncio.create_task(self._loop("feature_rebuild", 21600, self._rebuild_features, 900), name="job_features"))
        self.tasks.append(asyncio.create_task(self._loop("snapshot_prune", 86400, self._prune, 600), name="job_prune"))
        if str(self.settings.environment).lower() == "production" or getattr(self.settings, "enable_model_schedule", False):
            self.tasks.append(asyncio.create_task(self._loop("daily_models", 86400, self._daily_models, 1800), name="job_models"))
        log.info(f"scheduler started with {len(self.tasks)} jobs + live ingestor")

    async def stop(self) -> None:
        self._stop.set()
        await INGESTOR.stop()
        for t in self.tasks:
            t.cancel()
        for t in self.tasks:
            try:
                await t
            except (asyncio.CancelledError, Exception):
                pass
        self.tasks = []

    def status(self) -> dict[str, Any]:
        return {
            "jobs": self.job_state,
            "defined": [
                "alerts (5m)", "derivatives (10m)", "incremental_ingest (1h)",
                "universe_refresh (6h)", "feature_rebuild (6h)", "snapshot_prune (24h)",
            ],
            "live": STATE.status(),
        }


SCHEDULER = Scheduler()

"""Database engine/session helpers and dialect-aware idempotent upserts."""
from __future__ import annotations

import json
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Any, Iterable, Iterator, Sequence

from sqlalchemy import create_engine, event, select
from sqlalchemy.engine import Engine
from sqlalchemy.orm import Session, sessionmaker

from backend.core.config import get_settings
from backend.core.logging import get_logger

log = get_logger("db")

_engine: Engine | None = None
_SessionLocal: sessionmaker[Session] | None = None


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _make_engine() -> Engine:
    settings = get_settings()
    url = settings.database_url
    kwargs: dict[str, Any] = {"pool_pre_ping": True, "future": True}
    if url.startswith("sqlite"):
        kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
        engine = create_engine(url, **kwargs)

        @event.listens_for(engine, "connect")
        def _sqlite_pragmas(dbapi_conn, _):  # pragma: no cover - driver hook
            cur = dbapi_conn.cursor()
            cur.execute("PRAGMA journal_mode=WAL")
            cur.execute("PRAGMA synchronous=NORMAL")
            cur.execute("PRAGMA foreign_keys=ON")
            cur.execute("PRAGMA busy_timeout=15000")
            cur.close()

        return engine
    return create_engine(url, **kwargs)


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        _engine = _make_engine()
    return _engine


def get_session_factory() -> sessionmaker[Session]:
    global _SessionLocal
    if _SessionLocal is None:
        _SessionLocal = sessionmaker(bind=get_engine(), expire_on_commit=False, future=True)
    return _SessionLocal


@contextmanager
def session_scope() -> Iterator[Session]:
    ses = get_session_factory()()
    try:
        yield ses
        ses.commit()
    except Exception:
        ses.rollback()
        raise
    finally:
        ses.close()


def init_db(create: bool = True) -> None:
    from backend.core import models  # noqa: F401  (register metadata)

    if create:
        models.Base.metadata.create_all(get_engine())
    log.info("database ready", extra={"event": "db_init"})


def reset_db_engine() -> None:
    """Used by tests to swap DATABASE_URL at runtime."""
    global _engine, _SessionLocal
    if _engine is not None:
        _engine.dispose()
    _engine = None
    _SessionLocal = None


def upsert_rows(
    session: Session,
    table,
    rows: Sequence[dict[str, Any]],
    conflict_cols: Sequence[str],
    skip_update: Sequence[str] = (),
) -> int:
    """Dialect-aware INSERT .. ON CONFLICT DO UPDATE (idempotent ingestion).

    ``skip_update`` lists columns that must not be overwritten on conflict. It is
    how a refresher can re-upsert a row without clobbering state it does not own
    (e.g. universe discovery must not reset a market's eligibility verdict).
    """
    if not rows:
        return 0
    dialect = session.get_bind().dialect.name
    if dialect == "sqlite":
        from sqlalchemy.dialects.sqlite import insert as dialect_insert
    elif dialect == "postgresql":
        from sqlalchemy.dialects.postgresql import insert as dialect_insert
    else:  # pragma: no cover - generic fallback
        dialect_insert = None

    if dialect_insert is None:
        for row in rows:
            session.merge(table(**row))
        return len(rows)

    # Chunk to keep SQLite parameter counts bounded.
    chunk = 400
    written = 0
    for i in range(0, len(rows), chunk):
        part = rows[i : i + chunk]
        stmt = dialect_insert(table).values(part)
        protected = set(conflict_cols) | set(skip_update)
        update_cols = {
            c.name: stmt.excluded[c.name]
            for c in table.columns
            if c.name not in protected and c.name in part[0]
        }
        if update_cols:
            stmt = stmt.on_conflict_do_update(index_elements=list(conflict_cols), set_=update_cols)
        else:  # pragma: no cover
            stmt = stmt.on_conflict_do_nothing(index_elements=list(conflict_cols))
        session.execute(stmt)
        written += len(part)
    return written


def json_safe(value: Any) -> Any:
    """Recursively convert numpy/pandas scalars and datetimes to JSON-safe values."""
    import math

    import numpy as np
    import pandas as pd

    if value is None:
        return None
    if isinstance(value, dict):
        return {str(k): json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [json_safe(v) for v in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating, float)):
        f = float(value)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(value, np.bool_):
        return bool(value)
    if isinstance(value, (datetime, pd.Timestamp)):
        ts = pd.Timestamp(value)
        if ts.tzinfo is None:
            ts = ts.tz_localize("UTC")
        return ts.tz_convert("UTC").isoformat()
    if isinstance(value, pd.Series):
        return json_safe(value.to_dict())
    return value


def dumps(value: Any) -> str:
    return json.dumps(json_safe(value), ensure_ascii=False, allow_nan=False)


def loads(value: str | None, default: Any = None) -> Any:
    if not value:
        return default
    try:
        return json.loads(value)
    except (TypeError, ValueError):
        return default


def table_count(session: Session, table) -> int:
    from sqlalchemy import func

    return int(session.execute(select(func.count()).select_from(table)).scalar_one())


def chunked(items: Iterable[Any], size: int) -> Iterator[list[Any]]:
    buf: list[Any] = []
    for it in items:
        buf.append(it)
        if len(buf) >= size:
            yield buf
            buf = []
    if buf:
        yield buf

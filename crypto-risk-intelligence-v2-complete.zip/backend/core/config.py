"""Central configuration. All secrets/settings come from environment variables.

Defaults are safe for local research use: public market-data endpoints only,
no trading keys, SQLite storage. PostgreSQL is supported by setting DATABASE_URL.
"""
from __future__ import annotations

import json
import os
from functools import lru_cache
from pathlib import Path
from typing import Any

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parents[2]


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"), env_file_encoding="utf-8", extra="ignore"
    )

    # --- runtime -----------------------------------------------------------
    app_name: str = "Crypto Risk Intelligence Platform"
    environment: str = "development"
    log_level: str = "INFO"
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_token: str | None = None          # if set, mutating endpoints require Bearer token
    cors_origins: str = "*"               # comma separated
    enable_background_jobs: bool = True

    # --- storage -----------------------------------------------------------
    database_url: str = f"sqlite:///{BASE_DIR / 'data' / 'risk_intel.db'}"
    data_dir: str = str(BASE_DIR / "data")
    parquet_dir: str = str(BASE_DIR / "data" / "parquet")
    sqlite_wal: bool = True

    # --- market universe ---------------------------------------------------
    exchanges_enabled: str = "binance_spot,okx_spot,okx_swap,coinbase,kraken,bybit_spot,binance_futures"
    quote_assets: str = "USDT,USD,USDC"
    exclude_stable_bases: bool = True      # remove stablecoin/stablecoin pairs
    exclude_leveraged: bool = True         # remove 3L/3S/5L style tokens
    min_quote_volume_usd: float = 3_000_000.0
    max_spread_bps: float = 75.0
    target_markets: int = 34               # markets selected for deep ingestion + modeling
    model_market_limit: int = 34           # max markets modelled per run (others stay pending)
    max_markets_per_base_asset: int = 2
    discovery_cache_minutes: int = 360

    # --- ingestion ---------------------------------------------------------
    bar_timeframe: str = "4h"              # intraday bar used to build daily RV
    ingest_lookback_days: int = 760
    min_history_days: int = 320
    min_observations: int = 300
    min_data_completeness: float = 0.90
    ingestion_concurrency: int = 4

    # --- live data ---------------------------------------------------------
    live_poll_seconds: int = 30
    live_symbol_limit: int = 40
    freshness_live_seconds: int = 120
    freshness_delayed_seconds: int = 600
    freshness_stale_seconds: int = 3600
    enable_websocket: bool = True

    # --- quantitative ------------------------------------------------------
    horizons: str = "1,7,30"
    var_confidences: str = "0.95,0.975,0.99"
    walkforward_min_train: int = 250
    walkforward_refit_every: int = 10
    risk_min_train: int = 400
    risk_refit_every: int = 5
    garch_min_obs: int = 250
    evt_tail_fraction: float = 0.10        # target fraction of exceedances for POT
    evt_min_exceedances: int = 25
    xgb_n_estimators: int = 320
    xgb_max_depth: int = 3
    xgb_learning_rate: float = 0.05

    # --- alerting ----------------------------------------------------------
    alert_forecast_vol_annualized: float = 1.20
    alert_price_move_pct: float = 10.0
    alert_spread_bps: float = 80.0
    alert_cooldown_minutes: int = 360

    # --- misc --------------------------------------------------------------
    http_timeout_seconds: float = 25.0
    user_agent: str = "CryptoRiskIntel/1.0 (research; public-data)"

    @property
    def exchange_list(self) -> list[str]:
        return [s.strip() for s in self.exchanges_enabled.split(",") if s.strip()]

    @property
    def quote_list(self) -> list[str]:
        return [s.strip().upper() for s in self.quote_assets.split(",") if s.strip()]

    @property
    def horizon_list(self) -> list[int]:
        return sorted({int(h) for h in self.horizons.split(",") if h.strip()})

    @property
    def confidence_list(self) -> list[float]:
        return sorted({float(c) for c in self.var_confidences.split(",") if c.strip()})

    @property
    def cors_list(self) -> list[str]:
        return [s.strip() for s in self.cors_origins.split(",") if s.strip()]

    def ensure_dirs(self) -> None:
        Path(self.data_dir).mkdir(parents=True, exist_ok=True)
        Path(self.parquet_dir).mkdir(parents=True, exist_ok=True)


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.ensure_dirs()
    return s


def runtime_config_overrides() -> dict[str, Any]:
    """Editable settings persisted in DB (thresholds / universe filters).

    Environment variables remain the hard boundary; DB values only override a
    documented whitelist so a bad config cannot inject code or secrets.
    """
    return {}


WHITELISTED_RUNTIME_KEYS = {
    "min_quote_volume_usd": float,
    "max_spread_bps": float,
    "target_markets": int,
    "min_history_days": int,
    "min_observations": int,
    "min_data_completeness": float,
    "alert_forecast_vol_annualized": float,
    "alert_price_move_pct": float,
    "alert_spread_bps": float,
    "alert_cooldown_minutes": int,
    "live_poll_seconds": int,
    "horizons": str,
    "var_confidences": str,
}


def load_runtime_overrides(path: Path | None = None) -> dict[str, Any]:
    """Load UI-editable overrides from config/runtime.json (git-ignored)."""
    p = path or (BASE_DIR / "config" / "runtime.json")
    if not p.exists():
        return {}
    try:
        raw = json.loads(p.read_text())
    except Exception:
        return {}
    out: dict[str, Any] = {}
    for k, v in raw.items():
        if k in WHITELISTED_RUNTIME_KEYS:
            try:
                out[k] = WHITELISTED_RUNTIME_KEYS[k](v)
            except (TypeError, ValueError):
                continue
    return out


def save_runtime_overrides(values: dict[str, Any]) -> dict[str, Any]:
    p = BASE_DIR / "config" / "runtime.json"
    current = load_runtime_overrides(p)
    for k, v in values.items():
        if k not in WHITELISTED_RUNTIME_KEYS:
            raise ValueError(f"setting '{k}' is not runtime-editable")
        current[k] = WHITELISTED_RUNTIME_KEYS[k](v)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(current, indent=2, sort_keys=True))
    return current


def effective_settings() -> Settings:
    """Settings with runtime overrides applied (does not mutate the cached base)."""
    base = get_settings()
    overrides = load_runtime_overrides()
    if not overrides:
        return base
    return base.model_copy(update=overrides)

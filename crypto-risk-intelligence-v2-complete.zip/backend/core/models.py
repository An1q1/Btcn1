"""SQLAlchemy schema. Design notes:
- Composite primary keys on time-series tables -> natural idempotency.
- Every row carries exchange/symbol (normalized), never just a ticker.
- Forecasts and VaR estimates are append-only; unique keys prevent duplicates
  while allowing re-runs with a different cutoff to coexist.
- JSON columns are used for evolving research metadata, not for core numbers.
"""
from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import (
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Index,
    Integer,
    String,
    Text,
    UniqueConstraint,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def _now() -> datetime:
    return datetime.now(timezone.utc)


class Base(DeclarativeBase):
    pass


class Exchange(Base):
    __tablename__ = "exchanges"

    code: Mapped[str] = mapped_column(String(48), primary_key=True)
    name: Mapped[str] = mapped_column(String(96))
    market_types: Mapped[str] = mapped_column(String(96), default="spot")
    enabled: Mapped[bool] = mapped_column(Boolean, default=True)
    rest_url: Mapped[str | None] = mapped_column(String(255))
    ws_url: Mapped[str | None] = mapped_column(String(255))
    status: Mapped[str] = mapped_column(String(24), default="unknown")  # ok|degraded|blocked|error
    status_detail: Mapped[str | None] = mapped_column(Text)
    latency_ms: Mapped[float | None] = mapped_column(Float)
    time_skew_ms: Mapped[float | None] = mapped_column(Float)
    last_checked_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    capabilities: Mapped[str | None] = mapped_column(Text)  # JSON
    notes: Mapped[str | None] = mapped_column(Text)


class Market(Base):
    __tablename__ = "markets"
    __table_args__ = (
        UniqueConstraint("exchange_code", "symbol", "market_type", name="uq_market_identity"),
        Index("ix_markets_base_quote", "base_asset", "quote_asset"),
        Index("ix_markets_volume", "quote_volume_24h"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    exchange_code: Mapped[str] = mapped_column(String(48), ForeignKey("exchanges.code"), index=True)
    symbol: Mapped[str] = mapped_column(String(64), index=True)          # native symbol
    canonical_symbol: Mapped[str] = mapped_column(String(120), index=True)
    base_asset: Mapped[str] = mapped_column(String(32), index=True)
    quote_asset: Mapped[str] = mapped_column(String(16), index=True)
    market_type: Mapped[str] = mapped_column(String(24), default="spot")  # spot|swap|futures
    contract_type: Mapped[str | None] = mapped_column(String(32))         # perpetual|dated...
    price_unit: Mapped[str] = mapped_column(String(16), default="quote")
    status: Mapped[str] = mapped_column(String(24), default="active")
    is_stable_pair: Mapped[bool] = mapped_column(Boolean, default=False)
    is_leveraged_token: Mapped[bool] = mapped_column(Boolean, default=False)
    is_wrapped: Mapped[bool] = mapped_column(Boolean, default=False)
    in_universe: Mapped[bool] = mapped_column(Boolean, default=False)
    model_eligible: Mapped[bool] = mapped_column(Boolean, default=False)
    ineligible_reasons: Mapped[str | None] = mapped_column(Text)          # JSON list
    eligibility: Mapped[str | None] = mapped_column(Text)                 # JSON detail
    last_price: Mapped[float | None] = mapped_column(Float)
    quote_volume_24h: Mapped[float | None] = mapped_column(Float)
    bid: Mapped[float | None] = mapped_column(Float)
    ask: Mapped[float | None] = mapped_column(Float)
    spread_bps: Mapped[float | None] = mapped_column(Float)
    price_change_24h_pct: Mapped[float | None] = mapped_column(Float)
    last_update_ts: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    data_completeness: Mapped[float | None] = mapped_column(Float)
    history_days_available: Mapped[int | None] = mapped_column(Integer)
    meta_json: Mapped[str | None] = mapped_column(Text)
    discovered_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)


class OHLCV(Base):
    __tablename__ = "ohlcv"
    __table_args__ = (
        Index("ix_ohlcv_lookup", "exchange_code", "symbol", "timeframe", "ts"),
    )

    exchange_code: Mapped[str] = mapped_column(String(48), primary_key=True)
    symbol: Mapped[str] = mapped_column(String(64), primary_key=True)
    timeframe: Mapped[str] = mapped_column(String(12), primary_key=True)
    ts: Mapped[int] = mapped_column(Integer, primary_key=True)  # UTC epoch ms, bar open
    open: Mapped[float] = mapped_column(Float)
    high: Mapped[float] = mapped_column(Float)
    low: Mapped[float] = mapped_column(Float)
    close: Mapped[float] = mapped_column(Float)
    volume: Mapped[float] = mapped_column(Float, default=0.0)
    quote_volume: Mapped[float | None] = mapped_column(Float)
    is_final: Mapped[bool] = mapped_column(Boolean, default=True)
    source: Mapped[str] = mapped_column(String(24), default="rest")
    ingested_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class MarketSnapshot(Base):
    __tablename__ = "market_snapshots"
    __table_args__ = (Index("ix_snapshot_lookup", "exchange_code", "symbol", "ts"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    exchange_code: Mapped[str] = mapped_column(String(48))
    symbol: Mapped[str] = mapped_column(String(64))
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    price: Mapped[float | None] = mapped_column(Float)
    bid: Mapped[float | None] = mapped_column(Float)
    ask: Mapped[float | None] = mapped_column(Float)
    spread_bps: Mapped[float | None] = mapped_column(Float)
    quote_volume_24h: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(24), default="rest")


class DerivativeMetric(Base):
    __tablename__ = "derivative_metrics"
    __table_args__ = (Index("ix_deriv_lookup", "exchange_code", "symbol", "ts"),)

    exchange_code: Mapped[str] = mapped_column(String(48), primary_key=True)
    symbol: Mapped[str] = mapped_column(String(64), primary_key=True)
    ts: Mapped[int] = mapped_column(Integer, primary_key=True)
    funding_rate: Mapped[float | None] = mapped_column(Float)
    funding_next: Mapped[float | None] = mapped_column(Float)
    open_interest: Mapped[float | None] = mapped_column(Float)
    open_interest_quote: Mapped[float | None] = mapped_column(Float)
    mark_price: Mapped[float | None] = mapped_column(Float)
    index_price: Mapped[float | None] = mapped_column(Float)
    basis: Mapped[float | None] = mapped_column(Float)
    source: Mapped[str] = mapped_column(String(24), default="rest")


class EngineeredFeature(Base):
    __tablename__ = "engineered_features"
    __table_args__ = (Index("ix_features_lookup", "exchange_code", "symbol", "bar_date"),)

    exchange_code: Mapped[str] = mapped_column(String(48), primary_key=True)
    symbol: Mapped[str] = mapped_column(String(64), primary_key=True)
    bar_date: Mapped[str] = mapped_column(String(10), primary_key=True)  # YYYY-MM-DD (UTC)
    close: Mapped[float] = mapped_column(Float)
    ret_pct: Mapped[float] = mapped_column(Float)          # 100*ln(C_t/C_{t-1})
    rv: Mapped[float] = mapped_column(Float)               # sum of squared intraday returns, %^2 per day
    rv_w: Mapped[float | None] = mapped_column(Float)
    rv_m: Mapped[float | None] = mapped_column(Float)
    semivar_neg: Mapped[float | None] = mapped_column(Float)
    semivar_pos: Mapped[float | None] = mapped_column(Float)
    range_pct: Mapped[float | None] = mapped_column(Float)
    volume: Mapped[float | None] = mapped_column(Float)
    quote_volume: Mapped[float | None] = mapped_column(Float)
    volume_z: Mapped[float | None] = mapped_column(Float)
    funding_rate: Mapped[float | None] = mapped_column(Float)
    open_interest: Mapped[float | None] = mapped_column(Float)
    oi_change_7d: Mapped[float | None] = mapped_column(Float)
    spread_bps: Mapped[float | None] = mapped_column(Float)
    cross_btc_rv: Mapped[float | None] = mapped_column(Float)
    n_bars: Mapped[int | None] = mapped_column(Integer)
    completeness: Mapped[float | None] = mapped_column(Float)
    features_json: Mapped[str | None] = mapped_column(Text)
    computed_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class RealizedTarget(Base):
    __tablename__ = "realized_targets"
    __table_args__ = (Index("ix_target_lookup", "exchange_code", "symbol", "horizon", "bar_date"),)

    exchange_code: Mapped[str] = mapped_column(String(48), primary_key=True)
    symbol: Mapped[str] = mapped_column(String(64), primary_key=True)
    bar_date: Mapped[str] = mapped_column(String(10), primary_key=True)   # forecast origin
    horizon: Mapped[int] = mapped_column(Integer, primary_key=True)
    target_rv: Mapped[float] = mapped_column(Float)        # mean daily RV over (t, t+h]
    target_vol_annualized: Mapped[float] = mapped_column(Float)
    realized_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class Forecast(Base):
    __tablename__ = "forecasts"
    __table_args__ = (
        UniqueConstraint(
            "exchange_code", "symbol", "model_name", "horizon", "bar_date", "run_id",
            name="uq_forecast_identity",
        ),
        Index("ix_forecast_lookup", "exchange_code", "symbol", "model_name", "horizon", "bar_date"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    exchange_code: Mapped[str] = mapped_column(String(48))
    symbol: Mapped[str] = mapped_column(String(64))
    model_name: Mapped[str] = mapped_column(String(48))
    model_version: Mapped[str] = mapped_column(String(32))
    horizon: Mapped[int] = mapped_column(Integer)
    bar_date: Mapped[str] = mapped_column(String(10))        # forecast origin (feature date)
    forecast_ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    data_cutoff_ts: Mapped[int] = mapped_column(Integer)      # last bar close used, epoch ms
    target_start_date: Mapped[str] = mapped_column(String(10))
    target_end_date: Mapped[str] = mapped_column(String(10))
    predicted_rv: Mapped[float] = mapped_column(Float)
    predicted_vol_annualized: Mapped[float] = mapped_column(Float)
    actual_rv: Mapped[float | None] = mapped_column(Float)
    config_json: Mapped[str | None] = mapped_column(Text)
    data_quality: Mapped[str] = mapped_column(String(24), default="ok")
    run_id: Mapped[str | None] = mapped_column(String(48), index=True)


class VarEsEstimate(Base):
    __tablename__ = "var_es_estimates"
    __table_args__ = (
        UniqueConstraint(
            "exchange_code", "symbol", "asof_date", "model_name", "confidence",
            name="uq_var_identity",
        ),
        Index("ix_var_lookup", "exchange_code", "symbol", "model_name", "asof_date"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    exchange_code: Mapped[str] = mapped_column(String(48))
    symbol: Mapped[str] = mapped_column(String(64))
    asof_date: Mapped[str] = mapped_column(String(10))
    model_name: Mapped[str] = mapped_column(String(48))
    confidence: Mapped[float] = mapped_column(Float)
    horizon_days: Mapped[int] = mapped_column(Integer, default=1)
    var_pct: Mapped[float] = mapped_column(Float)     # positive loss in % of price
    es_pct: Mapped[float | None] = mapped_column(Float)
    mu: Mapped[float | None] = mapped_column(Float)
    sigma: Mapped[float | None] = mapped_column(Float)
    threshold: Mapped[float | None] = mapped_column(Float)
    xi: Mapped[float | None] = mapped_column(Float)
    beta: Mapped[float | None] = mapped_column(Float)
    n_exceedances: Mapped[int | None] = mapped_column(Integer)
    method_meta: Mapped[str | None] = mapped_column(Text)
    actual_loss_pct: Mapped[float | None] = mapped_column(Float)
    breach: Mapped[bool | None] = mapped_column(Boolean)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class BacktestResult(Base):
    __tablename__ = "backtest_results"
    __table_args__ = (
        Index("ix_backtest_lookup", "scope", "exchange_code", "symbol", "horizon", "metric"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    run_id: Mapped[str] = mapped_column(String(48), index=True)
    scope: Mapped[str] = mapped_column(String(24), default="asset")  # asset|aggregate
    exchange_code: Mapped[str | None] = mapped_column(String(48))
    symbol: Mapped[str | None] = mapped_column(String(64))
    horizon: Mapped[int | None] = mapped_column(Integer)
    model_name: Mapped[str] = mapped_column(String(48))
    metric: Mapped[str] = mapped_column(String(48))
    value: Mapped[float | None] = mapped_column(Float)
    n_obs: Mapped[int | None] = mapped_column(Integer)
    p_value: Mapped[float | None] = mapped_column(Float)
    config_json: Mapped[str | None] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ModelRegistry(Base):
    __tablename__ = "model_registry"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(48), index=True)
    version: Mapped[str] = mapped_column(String(32))
    family: Mapped[str] = mapped_column(String(32))
    description: Mapped[str | None] = mapped_column(Text)
    params_json: Mapped[str | None] = mapped_column(Text)
    target_definition: Mapped[str | None] = mapped_column(Text)
    status: Mapped[str] = mapped_column(String(24), default="active")
    trained_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)


class ModelRun(Base):
    __tablename__ = "model_runs"

    id: Mapped[str] = mapped_column(String(48), primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))           # forecast|risk|backtest|ingestion
    status: Mapped[str] = mapped_column(String(24), default="running")
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    scope_json: Mapped[str | None] = mapped_column(Text)
    metrics_json: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)
    log_tail: Mapped[str | None] = mapped_column(Text)


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (
        UniqueConstraint("dedupe_key", name="uq_alert_dedupe"),
        Index("ix_alert_lookup", "ts", "severity", "alert_type"),
    )

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    dedupe_key: Mapped[str] = mapped_column(String(160))
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    exchange_code: Mapped[str | None] = mapped_column(String(48))
    symbol: Mapped[str | None] = mapped_column(String(64))
    severity: Mapped[str] = mapped_column(String(16))       # info|warning|critical
    alert_type: Mapped[str] = mapped_column(String(48))
    trigger: Mapped[str] = mapped_column(String(255))
    message: Mapped[str] = mapped_column(Text)
    observed_value: Mapped[float | None] = mapped_column(Float)
    threshold: Mapped[float | None] = mapped_column(Float)
    acknowledged: Mapped[bool] = mapped_column(Boolean, default=False)
    # An alert stops being "active" either because an analyst acknowledged it or
    # because the condition cleared / expired; the two states are tracked apart so
    # the UI can distinguish "someone looked at this" from "this is over".
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    resolved_reason: Mapped[str | None] = mapped_column(String(160))


class IngestionJob(Base):
    __tablename__ = "ingestion_jobs"

    id: Mapped[str] = mapped_column(String(48), primary_key=True)
    kind: Mapped[str] = mapped_column(String(32))
    exchange_code: Mapped[str | None] = mapped_column(String(48))
    symbol: Mapped[str | None] = mapped_column(String(64))
    timeframe: Mapped[str | None] = mapped_column(String(12))
    status: Mapped[str] = mapped_column(String(24), default="running")
    started_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True))
    rows_written: Mapped[int] = mapped_column(Integer, default=0)
    checkpoint_json: Mapped[str | None] = mapped_column(Text)
    error: Mapped[str | None] = mapped_column(Text)


class DataQualityEvent(Base):
    __tablename__ = "data_quality_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    ts: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now)
    exchange_code: Mapped[str] = mapped_column(String(48), index=True)
    symbol: Mapped[str | None] = mapped_column(String(64))
    timeframe: Mapped[str | None] = mapped_column(String(12))
    event_type: Mapped[str] = mapped_column(String(48))
    severity: Mapped[str] = mapped_column(String(16))
    details_json: Mapped[str | None] = mapped_column(Text)
    resolved: Mapped[bool] = mapped_column(Boolean, default=False)


class ConfigStore(Base):
    __tablename__ = "config_store"

    key: Mapped[str] = mapped_column(String(64), primary_key=True)
    value_json: Mapped[str] = mapped_column(Text)
    updated_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_now, onupdate=_now)

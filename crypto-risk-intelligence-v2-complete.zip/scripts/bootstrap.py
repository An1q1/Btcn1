"""End-to-end bootstrap: real data -> features -> forecasts -> VaR -> evaluation -> alerts.

This is the one command that rebuilds the whole platform from an empty database.
Every step is idempotent (upserts on natural keys), so re-running it repairs a
partial build instead of duplicating rows.

    python -m scripts.bootstrap                # full rebuild
    python -m scripts.bootstrap --from features  # resume from a step
    python -m scripts.bootstrap --skip-ingest    # models only (data already local)

Steps (in order): discover, ingest, derivatives, features, forecast, risk,
evaluate, alerts, retention.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
import time
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from backend.core.config import effective_settings  # noqa: E402
from backend.core.db import init_db  # noqa: E402
from backend.core.logging import configure_logging, get_logger  # noqa: E402
from backend.exchanges.registry import close_all  # noqa: E402

log = get_logger("bootstrap")

async def _with_cleanup(factory):
    """Run an async step and always release adapter HTTP clients."""
    try:
        return await factory()
    finally:
        await close_all()


STEPS = ["discover", "ingest", "derivatives", "features", "forecast", "risk", "evaluate", "alerts", "retention"]


def _discover() -> dict:
    from backend.data_ingestion.universe import UniverseService

    async def run() -> dict:
        svc = UniverseService()
        await svc.probe_exchanges()
        return await svc.discover()

    res = asyncio.run(_with_cleanup(run))
    return {
        "discovered": res.get("discovered"),
        "candidates": res.get("candidates"),
        "selected": res.get("selected_count"),
        "by_exchange": res.get("by_exchange"),
        "failures": res.get("failures"),
    }


def _ingest() -> dict:
    from backend.data_ingestion.historical import ingest_universe
    from backend.data_ingestion.universe import refresh_latest_quotes

    async def run() -> dict:
        res = await ingest_universe(lookback_days=effective_settings().ingest_lookback_days)
        await refresh_latest_quotes(symbol_limit=200)
        return res

    res = asyncio.run(_with_cleanup(run))
    failed = [r for r in res.get("results", []) if r.get("status") != "success"]
    return {
        "markets": res.get("markets"),
        "success": res.get("success"),
        "failed": res.get("failed"),
        "bars": res.get("bars"),
        "failures": [{"market": f"{r['exchange']}:{r['symbol']}", "error": r.get("error")} for r in failed][:10],
    }


def _derivatives() -> dict:
    from backend.data_ingestion.historical import update_derivative_metrics

    return asyncio.run(_with_cleanup(update_derivative_metrics))


def _features() -> dict:
    from backend.features.pipeline import build_all_features

    return build_all_features()


def _forecast() -> dict:
    from backend.quant.walkforward import run_forecast_pipeline

    return run_forecast_pipeline()


def _risk() -> dict:
    from backend.risk.var_es import run_risk_pipeline

    return run_risk_pipeline()


def _evaluate() -> dict:
    from backend.quant.evaluation import run_evaluation

    return run_evaluation()


def _alerts() -> dict:
    """Refresh quotes first, then evaluate alerts.

    Alerts include a freshness check; running them against quotes that are
    minutes old (because ingestion happened earlier in this same process) would
    emit stale_data warnings for every market, which is noise rather than a
    finding.
    """
    from backend.data_ingestion.universe import refresh_latest_quotes
    from backend.services.alert_service import generate_alerts

    quotes = asyncio.run(_with_cleanup(lambda: refresh_latest_quotes(symbol_limit=200)))
    return {"quotes": quotes, **generate_alerts()}


def _retention() -> dict:
    """Keep the research DB movable: 200 origins of history per series."""
    from backend.maintenance import prune_forecast_history, prune_var_history, vacuum

    out = {
        "forecasts": prune_forecast_history(retain_origins=200),
        "var_es": prune_var_history(retain_origins=200),
    }
    out["vacuum"] = {"note": "run `python -m scripts.cli vacuum` manually if needed"}
    return out


RUNNERS = {
    "discover": _discover,
    "ingest": _ingest,
    "derivatives": _derivatives,
    "features": _features,
    "forecast": _forecast,
    "risk": _risk,
    "evaluate": _evaluate,
    "alerts": _alerts,
    "retention": _retention,
}


def main() -> int:
    p = argparse.ArgumentParser(description="Rebuild the platform end-to-end from real exchange data")
    p.add_argument("--from", dest="start", choices=STEPS, default="discover")
    p.add_argument("--only", choices=STEPS, default=None)
    p.add_argument("--skip-ingest", action="store_true", help="assume OHLCV is already stored")
    args = p.parse_args()

    configure_logging()
    init_db()

    steps = [args.only] if args.only else STEPS[STEPS.index(args.start):]
    if args.skip_ingest:
        steps = [s for s in steps if s not in ("discover", "ingest", "derivatives")]

    summary = []
    for step in steps:
        t0 = time.time()
        log.info(f"=== {step} :: start")
        try:
            res = RUNNERS[step]()
            elapsed = round(time.time() - t0, 1)
            payload = json.loads(json.dumps(res, default=str))
            log.info(f"=== {step} :: done in {elapsed}s :: {json.dumps(payload)[:600]}")
            summary.append({"step": step, "status": "ok", "seconds": elapsed, "result": payload})
        except Exception as exc:  # noqa: BLE001
            elapsed = round(time.time() - t0, 1)
            log.error(f"=== {step} :: FAILED after {elapsed}s :: {exc}")
            traceback.print_exc()
            summary.append({"step": step, "status": "failed", "seconds": elapsed, "error": str(exc)[:500]})
            if step in ("discover", "ingest"):
                return 1  # nothing downstream can work without data

    print(json.dumps(summary, indent=2, default=str)[:40000])
    failed = [s for s in summary if s["status"] != "ok"]
    return 1 if failed else 0


if __name__ == "__main__":
    raise SystemExit(main())

"""Build a clean release archive of the platform.

    python -m scripts.package_release                    # source + docs + tests
    python -m scripts.package_release --with-db          # add the research DB
    python -m scripts.package_release --with-parquet     # add research exports

The archive never contains caches, virtualenvs, logs, the raw SQLite/WAL files,
or anything under ``.env``. Large research artefacts are optional flags so the
source zip stays small enough for any upload target.
"""
from __future__ import annotations

import argparse
import sqlite3
import time
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "dist"

INCLUDE_DIRS = ["backend", "frontend", "scripts", "tests", "migrations", "docs", "reports"]
INCLUDE_FILES = [
    "README.md", "requirements.txt", "pytest.ini", "alembic.ini",
    "Dockerfile", "docker-compose.yml", ".env.example", ".gitignore", ".dockerignore",
]
EXCLUDE_PARTS = {"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache", "node_modules", ".venv"}
EXCLUDE_SUFFIXES = {".pyc", ".pyo", ".db", ".db-wal", ".db-shm", ".log"}


def _iter_files(base: Path):
    for path in sorted(base.rglob("*")):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT)
        if any(part in EXCLUDE_PARTS for part in rel.parts):
            continue
        if path.suffix in EXCLUDE_SUFFIXES:
            continue
        yield path, rel


def build(with_db: bool = False, with_parquet: bool = False) -> dict:
    OUT.mkdir(exist_ok=True)
    stamp = time.strftime("%Y%m%d")
    target = OUT / f"crypto-risk-intelligence-1.0.0-{stamp}.zip"
    count = 0
    with zipfile.ZipFile(target, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for name in INCLUDE_FILES:
            path = ROOT / name
            if path.exists():
                zf.write(path, f"crypto-risk-intelligence/{name}")
                count += 1
        for d in INCLUDE_DIRS:
            base = ROOT / d
            if not base.exists():
                continue
            for path, rel in _iter_files(base):
                zf.write(path, f"crypto-risk-intelligence/{rel.as_posix()}")
                count += 1
        if with_db:
            db = ROOT / "data" / "risk_intel.db"
            if db.exists() and db.stat().st_size > 0:
                # checkpoint so the archive is a single consistent file
                try:
                    con = sqlite3.connect(db)
                    con.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                    con.close()
                except sqlite3.Error:
                    pass
                zf.write(db, "crypto-risk-intelligence/data/risk_intel.db", compress_type=zipfile.ZIP_DEFLATED)
                count += 1
        if with_parquet:
            pq = ROOT / "data" / "parquet"
            for path in sorted(pq.glob("*.parquet")):
                zf.write(path, f"crypto-risk-intelligence/data/parquet/{path.name}")
                count += 1
    size_mb = target.stat().st_size / 1e6
    return {"archive": str(target), "files": count, "size_mb": round(size_mb, 2)}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--with-db", action="store_true")
    ap.add_argument("--with-parquet", action="store_true")
    args = ap.parse_args()
    print(build(args.with_db, args.with_parquet))

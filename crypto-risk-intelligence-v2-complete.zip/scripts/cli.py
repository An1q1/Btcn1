"""CLI entry point for ingestion + research pipelines.

Usage:
    python -m scripts.cli discover
    python -m scripts.cli ingest --lookback 760
    python -m scripts.cli derivatives
    python -m scripts.cli features
    python -m scripts.cli forecast [--markets 26] [--max-horizon 30]
    python -m scripts.cli risk
    python -m scripts.cli evaluate
    python -m scripts.cli pipeline
    python -m scripts.cli status
"""
from __future__ import annotations

import argparse
import asyncio
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from backend.core.config import effective_settings  # noqa: E402
from backend.core.db import init_db  # noqa: E402
from backend.core.logging import configure_logging, get_logger  # noqa: E402

log = get_logger("cli")


def _print(obj) -> None:
    print(json.dumps(obj, indent=2, default=str)[:20000])


async def cmd_discover(args) -> None:
    from backend.data_ingestion.universe import UniverseService

    svc = UniverseService()
    await svc.probe_exchanges()
    res = await svc.discover()
    _print({k: res[k] for k in ("discovered", "candidates", "selected_count", "by_exchange", "failures", "excluded")})


async def cmd_ingest(args) -> None:
    from backend.data_ingestion.historical import ingest_universe
    from backend.data_ingestion.universe import refresh_latest_quotes

    res = await ingest_universe(lookback_days=args.lookback)
    await refresh_latest_quotes(symbol_limit=200)
    _print({k: res[k] for k in ("markets", "success", "failed", "bars")})
    for r in res["results"]:
        if r["status"] != "success":
            print("FAILED", r)


async def cmd_derivatives(args) -> None:
    from backend.data_ingestion.historical import update_derivative_metrics

    _print(await update_derivative_metrics())


def cmd_features(args) -> None:
    from backend.features.pipeline import build_all_features

    _print(build_all_features(force=args.force))


def cmd_forecast(args) -> None:
    from backend.quant.walkforward import run_forecast_pipeline

    _print(run_forecast_pipeline(market_limit=args.markets, horizons=args.horizons))


def cmd_risk(args) -> None:
    from backend.risk.var_es import run_risk_pipeline

    _print(run_risk_pipeline(market_limit=args.markets))


def cmd_evaluate(args) -> None:
    from backend.quant.evaluation import run_evaluation

    _print(run_evaluation())


def cmd_alerts(args) -> None:
    from backend.services.alert_service import generate_alerts

    _print(generate_alerts())


async def cmd_pipeline(args) -> None:
    from backend.backtesting_runner import run_full_pipeline

    _print(await run_full_pipeline(lookback_days=args.lookback, market_limit=args.markets))


def cmd_vacuum(args) -> None:
    from backend.maintenance import vacuum

    _print(vacuum())


def cmd_retention(args) -> None:
    from backend.maintenance import prune_duplicate_forecasts, prune_forecast_history, prune_var_history

    out = {
        "duplicates": prune_duplicate_forecasts(),
        "forecasts": prune_forecast_history(retain_origins=args.origins),
        "var_es": prune_var_history(retain_origins=args.origins),
    }
    _print(out)


def cmd_status(args) -> None:
    from sqlalchemy import func, select

    from backend.core.db import session_scope
    from backend.core.models import Alert, DataQualityEvent, Forecast, Market, OHLCV, VarEsEstimate

    with session_scope() as ses:
        out = {
            "markets_total": ses.execute(select(func.count()).select_from(Market)).scalar_one(),
            "markets_in_universe": ses.execute(
                select(func.count()).select_from(Market).where(Market.in_universe.is_(True))
            ).scalar_one(),
            "markets_model_eligible": ses.execute(
                select(func.count()).select_from(Market).where(Market.model_eligible.is_(True))
            ).scalar_one(),
            "ohlcv_rows": ses.execute(select(func.count()).select_from(OHLCV)).scalar_one(),
            "forecast_rows": ses.execute(select(func.count()).select_from(Forecast)).scalar_one(),
            "var_es_rows": ses.execute(select(func.count()).select_from(VarEsEstimate)).scalar_one(),
            "alerts": ses.execute(select(func.count()).select_from(Alert)).scalar_one(),
            "dq_events": ses.execute(select(func.count()).select_from(DataQualityEvent)).scalar_one(),
        }
    _print(out)


def main() -> None:
    configure_logging()
    p = argparse.ArgumentParser(description="Crypto Risk Intelligence Platform CLI")
    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("discover"); sp.set_defaults(fn=cmd_discover)
    sp = sub.add_parser("ingest"); sp.add_argument("--lookback", type=int, default=None); sp.set_defaults(fn=cmd_ingest, is_async=True)
    sp = sub.add_parser("derivatives"); sp.set_defaults(fn=cmd_derivatives, is_async=True)
    sp = sub.add_parser("features"); sp.add_argument("--force", action="store_true"); sp.set_defaults(fn=cmd_features)
    sp = sub.add_parser("forecast")
    sp.add_argument("--markets", type=int, default=None)
    sp.add_argument("--horizons", type=str, default=None)
    sp.set_defaults(fn=cmd_forecast)
    sp = sub.add_parser("risk"); sp.add_argument("--markets", type=int, default=None); sp.set_defaults(fn=cmd_risk)
    sp = sub.add_parser("evaluate"); sp.set_defaults(fn=cmd_evaluate)
    sp = sub.add_parser("alerts"); sp.set_defaults(fn=cmd_alerts)
    sp = sub.add_parser("pipeline")
    sp.add_argument("--lookback", type=int, default=None)
    sp.add_argument("--markets", type=int, default=None)
    sp.set_defaults(fn=cmd_pipeline, is_async=True)
    sp = sub.add_parser("status"); sp.set_defaults(fn=cmd_status)
    sp = sub.add_parser("vacuum"); sp.set_defaults(fn=cmd_vacuum)
    sp = sub.add_parser("retention")
    sp.add_argument("--origins", type=int, default=200)
    sp.set_defaults(fn=cmd_retention)

    args = p.parse_args()
    init_db()
    fn = args.fn
    if getattr(args, "is_async", False):
        asyncio.run(fn(args))
    else:
        fn(args)


if __name__ == "__main__":
    main()

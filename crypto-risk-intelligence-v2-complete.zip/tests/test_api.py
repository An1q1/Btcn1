"""API contract tests.

The app is pointed at a temporary database by ``tests/conftest.py``. Every test
asserts the documented response shape, the error envelope, and the two rules
that matter most for this platform:
  * no endpoint ever fabricates data when a table is empty;
  * numeric units are consistent (VaR/ES positive loss %, vol as a fraction).
"""
from __future__ import annotations

import pytest
from fastapi.testclient import TestClient

from backend.main import app

API = "/api/v1"


@pytest.fixture(scope="module")
def client():
    with TestClient(app) as c:
        yield c


# ------------------------------------------------------------------ system ---
def test_health_reports_database_state(client):
    r = client.get(f"{API}/health")
    assert r.status_code == 200
    body = r.json()
    assert body["status"] in ("ok", "error")
    assert "database" in body and "ok" in body["database"]
    assert body["service"] == "crypto-risk-intelligence-api"


def test_system_status_shape(client):
    r = client.get(f"{API}/system/status")
    assert r.status_code == 200
    body = r.json()
    for key in ("server_time", "counts", "pipeline", "data_freshness", "config"):
        assert key in body
    for key in ("markets", "ohlcv_rows", "forecast_rows", "var_es_rows"):
        assert key in body["counts"]


def test_exchanges_lists_capabilities(client):
    r = client.get(f"{API}/exchanges")
    assert r.status_code == 200
    body = r.json()
    assert isinstance(body["exchanges"], list)
    if body["exchanges"]:
        row = body["exchanges"][0]
        for key in ("code", "name", "status", "capabilities", "markets", "universe_markets"):
            assert key in row


def test_openapi_is_served(client):
    r = client.get("/api/openapi.json")
    assert r.status_code == 200
    paths = r.json()["paths"]
    for path in (f"{API}/health", f"{API}/markets", f"{API}/risk/var-es", f"{API}/alerts"):
        assert path in paths


# ------------------------------------------------------------------ markets ---
def test_markets_pagination_and_empty_result_are_honest(client):
    r = client.get(f"{API}/markets", params={"page": 1, "page_size": 5})
    assert r.status_code == 200
    body = r.json()
    assert body["page"] == 1 and body["page_size"] == 5
    assert len(body["items"]) <= 5
    assert "total" in body and "pages" in body
    empty = client.get(f"{API}/markets", params={"search": "ZZZZ-NOT-A-COIN"}).json()
    assert empty["items"] == []
    assert empty["total"] == 0
    assert empty["pages"] == 0


def test_markets_rejects_invalid_sort_and_order(client):
    r = client.get(f"{API}/markets", params={"sort": "'; DROP TABLE markets;--"})
    assert r.status_code == 422
    assert r.json()["error"]["code"] == 422
    r2 = client.get(f"{API}/markets", params={"order": "sideways"})
    assert r2.status_code == 422


def test_missing_market_returns_structured_404(client):
    r = client.get(f"{API}/markets/binance_spot/NOTACOIN")
    assert r.status_code == 404
    payload = r.json()
    assert "error" in payload or "detail" in payload


def test_ohlcv_requires_reasonable_limit(client):
    r = client.get(f"{API}/markets/binance_spot/BTCUSDT/ohlcv", params={"limit": 2})
    assert r.status_code == 422
    assert r.json()["error"]["message"] == "request validation failed"


def test_unknown_route_is_404_not_fake_data(client):
    r = client.get(f"{API}/does-not-exist")
    assert r.status_code == 404


# --------------------------------------------------------------------- risk ---
@pytest.mark.parametrize("conf", [0.95, 0.975, 0.99])
def test_var_es_endpoint_declares_sign_convention(client, conf):
    r = client.get(f"{API}/risk/var-es", params={"confidence": conf})
    assert r.status_code == 200
    body = r.json()
    assert body["confidence"] == conf
    assert "positive loss" in body["sign_convention"].lower()
    assert isinstance(body["items"], list)


def test_var_es_rejects_out_of_range_confidence(client):
    assert client.get(f"{API}/risk/var-es", params={"confidence": 1.5}).status_code == 422


def test_risk_backtests_report_notes_and_empty_state(client):
    r = client.get(f"{API}/risk/backtests", params={"confidence": 0.99})
    assert r.status_code == 200
    body = r.json()
    assert "aggregate" in body and "by_market" in body
    assert isinstance(body.get("notes"), list) and body["notes"], "test limitations must be reported"


# ------------------------------------------------------------------- alerts ---
def test_alert_lifecycle_and_cooldown_dedupe(client):
    from backend.core.db import session_scope
    from backend.core.models import Alert

    with session_scope() as ses:
        ses.add(Alert(
            dedupe_key=f"test:cooldown:{__name__}", severity="warning", alert_type="unit_test",
            trigger="manual", message="synthetic alert for the API test", acknowledged=False,
        ))
    r = client.get(f"{API}/alerts", params={"limit": 50})
    assert r.status_code == 200
    body = r.json()
    assert "items" in body and "counts" in body
    alert = next(a for a in body["items"] if a["type"] == "unit_test")
    ack = client.post(f"{API}/alerts/{alert['id']}/ack")
    assert ack.status_code == 200
    assert ack.json()["ok"] is True
    # acknowledging twice is still a 404-free no-op
    assert client.post(f"{API}/alerts/{alert['id']}/ack").status_code == 200
    assert client.post(f"{API}/alerts/99999999/ack").status_code == 404


# ----------------------------------------------------------------- settings ---
def test_settings_roundtrip_and_validation(client):
    before = client.get(f"{API}/settings").json()
    assert "effective" in before and "editable" in before
    bad = client.put(f"{API}/settings", json={"values": {"not_a_setting": 1}})
    assert bad.status_code in (422, 200)  # rejected or ignored, never applied silently
    ok = client.put(f"{API}/settings", json={"values": {"alert_cooldown_minutes": 15}})
    assert ok.status_code == 200
    assert ok.json()["effective"]["alert_cooldown_minutes"] == 15
    client.put(f"{API}/settings", json={"values": {"alert_cooldown_minutes": before["effective"]["alert_cooldown_minutes"]}})


def test_settings_rejects_wrong_types(client):
    r = client.put(f"{API}/settings", json={"values": {"target_markets": "many"}})
    assert r.status_code == 422


# ---------------------------------------------------------------------- SSE ---
def test_stream_endpoint_is_event_stream(client):
    """D1: kết nối mới phải nhận SSE hợp lệ ngay, không phụ thuộc tick mới."""
    import time

    t0 = time.time()
    with client.stream("GET", f"{API}/stream") as r:
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/event-stream")
        # Cache-Control và X-Accel-Buffering phải chống buffer
        assert "no-cache" in r.headers.get("cache-control", "")
        assert r.headers.get("x-accel-buffering") == "no"
        # Dòng đầu tiên phải đến trong thời gian hữu hạn (2 giây)
        first = next(r.iter_lines())
        elapsed = time.time() - t0
        assert elapsed < 2.0, f"first SSE frame took {elapsed:.2f}s — should be immediate"
        assert first.startswith("event:") or first.startswith(":") or first.startswith("retry:")


def test_stream_heartbeat_and_multiple_events(client):
    """Heartbeat định kỳ ngay cả khi không có giao dịch mới — kiểm tra BUS publish tới subscriber."""
    import asyncio

    from backend.data_ingestion.live import BUS

    async def _run():
        q = BUS.subscribe()
        try:
            # Hello được yield ngay khi subscribe qua event_stream, nhưng BUS publish cũng phải tới q
            BUS.publish({"type": "ticker", "data": {"exchange": "test", "symbol": "FAKE", "price": 123}})
            ev = await asyncio.wait_for(q.get(), timeout=1.0)
            assert ev["type"] == "ticker"
            assert ev["data"]["symbol"] == "FAKE"
        finally:
            BUS.unsubscribe(q)

    asyncio.run(_run())
    # Ngoài ra, kiểm tra stream endpoint vẫn trả retry và content-type đúng
    with client.stream("GET", f"{API}/stream") as r:
        assert r.status_code == 200
        assert r.headers["content-type"].startswith("text/event-stream")
        it = r.iter_lines()
        first = next(it)
        assert first.startswith("retry:") or first.startswith("event:") or first.startswith(":")


def test_stream_subscriber_cleanup_on_disconnect():
    """Ngắt kết nối phải hủy subscription và không giữ kết nối đã đóng."""
    import asyncio

    from backend.data_ingestion.live import BUS, event_stream

    async def _run():
        before = len(BUS._subscribers)
        gen = event_stream()
        # Lấy hello
        hello = await anext(gen)
        assert hello["type"] == "hello"
        assert len(BUS._subscribers) == before + 1
        # Đóng generator (mô phỏng client disconnect)
        await gen.aclose()
        await asyncio.sleep(0.05)
        assert len(BUS._subscribers) == before

    asyncio.run(_run())


def test_stream_backpressure_and_isolation():
    """Hàng đợi có giới hạn, backpressure bỏ tin cũ nhất, lỗi 1 subscriber không hỏng subscriber khác."""
    import asyncio

    from backend.data_ingestion.live import BUS

    async def _run():
        BUS._max = 2
        q1 = BUS.subscribe()
        q2 = BUS.subscribe()
        # Lỗi của q1 khi publish không được lan sang q2
        # Publish nhiều hơn max_queue
        for i in range(5):
            BUS.publish({"i": i})
        # q1 và q2 đều chỉ giữ 2 phần tử cuối
        assert q1.qsize() <= 2
        assert q2.qsize() <= 2
        # Đọc hết q2, kiểm tra không bị hỏng
        items = []
        while not q2.empty():
            items.append(await q2.get())
        assert len(items) == 2
        assert items[-1]["i"] == 4
        BUS.unsubscribe(q1)
        BUS.unsubscribe(q2)
        BUS._max = 100

    asyncio.run(_run())


# --------------------------------------------------------------- static app ---
def test_frontend_is_served(client):
    r = client.get("/")
    assert r.status_code == 200
    assert "text/html" in r.headers["content-type"]
    assert "Crypto Risk Intelligence" in r.text


def test_alert_resolution_state(client, db_session):
    """Alerts must be able to close: resolved alerts leave the active count."""
    from datetime import datetime, timezone

    from backend.core.models import Alert

    a = Alert(
        dedupe_key="test:resolution:1",
        ts=datetime.now(timezone.utc),
        exchange_code="binance_spot", symbol="BTCUSDT",
        severity="warning", alert_type="stale_data",
        trigger="data freshness = stale", message="test alert",
    )
    db_session.add(a)
    db_session.commit()

    body = client.get("/api/v1/alerts?limit=5").json()
    assert body["active"] >= 1
    assert "resolved" in body
    item = next(i for i in body["items"] if i["type"] == "stale_data")
    assert item["active"] is True and item["resolved_at"] is None

    a.resolved_at = datetime.now(timezone.utc)
    a.resolved_reason = "test"
    db_session.commit()

    after = client.get("/api/v1/alerts?active_only=true&limit=50").json()
    assert all(i["resolved_at"] is None for i in after["items"])
    assert after["resolved"] >= 1

"""Universe selection rules.

The universe must be discoverable (no hard-coded BTC/ETH), quality-filtered and
**stable across refreshes**: a scheduled re-discovery that reshuffles the
modelled set would silently invalidate every cross-run comparison.
"""
from __future__ import annotations

from backend.data_ingestion.universe import UniverseService
from backend.exchanges.base import MarketInfo


def _mkt(exchange: str, symbol: str, base: str, quote: str = "USDT", vol: float = 5e8,
         spread: float = 2.0, market_type: str = "spot") -> MarketInfo:
    # spread_bps is a derived property: drive it through bid/ask.
    half = spread / 2 / 10_000
    return MarketInfo(
        exchange_code=exchange, symbol=symbol, base_asset=base, quote_asset=quote,
        market_type=market_type, quote_volume_24h=vol,
        price=1.0, bid=1.0 - half, ask=1.0 + half,
        meta={"asset_class": "crypto", "is_stable_pair": False, "is_leveraged_token": False},
    )


def _discovered(mkts):
    return [(m.exchange_code, m) for m in mkts]


def test_selection_carries_over_existing_universe():
    svc = UniverseService()
    svc.settings = svc.settings.model_copy(update={"target_markets": 3, "max_markets_per_base_asset": 1})
    discovered = _discovered([
        _mkt("binance_spot", "AAAUSDT", "AAA", vol=9e8),
        _mkt("binance_spot", "BBBUSDT", "BBB", vol=8e8),
        _mkt("binance_spot", "CCCUSDT", "CCC", vol=7e8),
        _mkt("binance_spot", "DDDUSDT", "DDD", vol=6e8),
    ])
    existing = {("binance_spot", "BBBUSDT", "spot"), ("binance_spot", "DDDUSDT", "spot")}
    selected, meta = svc._select(discovered, existing)
    keys = {(m.exchange_code, m.symbol, m.market_type) for m in selected}
    assert meta["carried_over"] == 2
    assert keys >= existing, "markets already in the universe must be kept"
    assert len(selected) == 3
    assert meta["new_entries"] == 1


def test_selection_drops_markets_that_fail_filters():
    svc = UniverseService()
    svc.settings = svc.settings.model_copy(update={"target_markets": 2, "max_markets_per_base_asset": 2})
    discovered = _discovered([
        _mkt("binance_spot", "AAAUSDT", "AAA", vol=9e8),
        _mkt("binance_spot", "CCCUSDT", "CCC", vol=7e8),
    ])
    # BBB vanished from the venue: it cannot be carried over.
    selected, meta = svc._select(discovered, {("binance_spot", "BBBUSDT", "spot")})
    keys = {(m.symbol for m in selected)}
    assert "BBBUSDT" not in keys
    assert meta["carried_over"] == 0 and meta["dropped"] == 1


def test_excluded_assets_never_enter_universe():
    svc = UniverseService()
    svc.settings = svc.settings.model_copy(update={"target_markets": 5, "max_markets_per_base_asset": 2})
    stable = _mkt("binance_spot", "USDCUSDT", "USDC", vol=9e9)
    stable.meta["is_stable_pair"] = True
    levered = _mkt("binance_spot", "BTC3LUSDT", "BTC3L", vol=8e9)
    levered.meta["is_leveraged_token"] = True
    thin = _mkt("binance_spot", "THINUSDT", "THIN", vol=1e5)
    ok = _mkt("binance_spot", "BTCUSDT", "BTC", vol=1e9)
    selected, meta = svc._select(_discovered([stable, levered, thin, ok]))
    assert [m.symbol for m in selected] == ["BTCUSDT"]
    assert meta["excluded"]["stable_pair"] == 1
    assert meta["excluded"]["leveraged"] == 1
    assert meta["excluded"]["low_volume"] == 1


def test_no_hard_coded_universe():
    """Selection must be driven by the discovered data, not by a ticker list."""
    svc = UniverseService()
    svc.settings = svc.settings.model_copy(update={"target_markets": 2, "max_markets_per_base_asset": 2})
    only_alts = [_mkt("okx_spot", "WIF-USDT", "WIF", vol=3e8), _mkt("okx_spot", "JUP-USDT", "JUP", vol=2e8)]
    selected, _ = svc._select(_discovered(only_alts))
    assert {m.base_asset for m in selected} == {"WIF", "JUP"}


def test_discovery_persist_preserves_eligibility(db_session):
    """Re-running discovery must not reset the eligibility verdict.

    Regression: `_persist` upserts a full market row that carries
    `model_eligible=False`, so a scheduled refresh used to blank the model
    universe until the next history check.
    """
    from backend.core.models import Exchange, Market

    if db_session.get(Exchange, "binance_spot") is None:
        db_session.add(Exchange(code="binance_spot", name="Binance Spot", market_types="spot",
                                status="ok", enabled=True))
        db_session.commit()
    db_session.add(Market(
        exchange_code="binance_spot", symbol="BTCUSDT", market_type="spot",
        canonical_symbol="BINANCE_SPOT:spot:BTC/USDT", base_asset="BTC", quote_asset="USDT",
        status="active", in_universe=True, model_eligible=True,
        ineligible_reasons="[]", eligibility='{"bars": 4550}',
    ))
    db_session.commit()

    svc = UniverseService()
    mkt = _mkt("binance_spot", "BTCUSDT", "BTC", vol=2e9)
    svc._persist([("binance_spot", mkt)], {("binance_spot", "BTCUSDT", "spot")})

    row = db_session.query(Market).filter_by(exchange_code="binance_spot", symbol="BTCUSDT").one()
    db_session.refresh(row)
    assert row.model_eligible is True, "discovery wiped the eligibility verdict"
    assert row.eligibility == '{"bars": 4550}'
    assert row.in_universe is True

"""Formula-level correctness tests: returns, realized variance, HAR, GARCH, VaR/ES, EVT.

These are the invariants everything else depends on. They are deliberately
explicit about units: returns in %, RV in %^2/day, volatility in %, VaR/ES as
positive loss percentages.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
from scipy import stats

from backend.features.rv import (
    bipower_variation,
    build_daily_features,
    log_returns_pct,
    realized_semivariance,
    realized_variance,
)
from backend.quant.evaluation import diebold_mariano, mae, qlike, qlike_losses, rmse
from backend.quant.garch import fit_garch, garch_volatility_forecast
from backend.quant.har import clip_predictions, fit_har, fit_ols, har_design
from backend.risk.backtests import christoffersen_independence, coverage_tests, kupiec_pof
from backend.risk.evt import fit_gpd, fit_pot, gpd_es, gpd_quantile, mean_excess_curve
from backend.risk.var_es import historical_var_es, normal_var_es, student_t_var_es


# ----------------------------------------------------------------- returns ---
def test_log_returns_are_percent_of_log_ratio():
    prices = np.array([100.0, 110.0, 99.0])
    r = log_returns_pct(prices)
    assert np.isnan(r[0])
    assert r[1] == pytest.approx(100 * np.log(1.10))
    assert r[2] == pytest.approx(100 * np.log(0.9))


def test_realized_variance_is_sum_of_squared_returns():
    intraday = np.array([1.0, -2.0, 0.5])
    assert realized_variance(intraday) == pytest.approx(1.0 + 4.0 + 0.25)
    assert realized_variance(np.array([np.nan])) != realized_variance(np.array([np.nan]))  # NaN


def test_semivariance_and_bipower_are_non_negative():
    r = np.array([1.5, -2.0, 0.3, -0.1])
    neg, pos = realized_semivariance(r)
    assert neg == pytest.approx(4.0 + 0.01)
    assert pos == pytest.approx(2.25 + 0.09)
    assert bipower_variation(r) > 0


def test_daily_aggregation_uses_utc_days_and_annualizes_consistently():
    # 4 bars/day, 3 days, 0.1% per bar -> RV = 4 * 0.01 = 0.04 %^2/day
    ts = pd.date_range("2026-01-01", periods=12, freq="6h", tz="UTC")
    prices = 100 * np.exp(np.cumsum(np.full(12, 0.001)))
    df = pd.DataFrame(
        {
            "ts": (ts.astype("int64") // 10**6).to_numpy(),
            "open": prices,
            "high": prices * 1.001,
            "low": prices * 0.999,
            "close": prices,
            "volume": 1.0,
        }
    )
    feats = build_daily_features(df, bars_per_day=4)
    assert len(feats) == 3
    # first bar of the series has no return, so RV differs slightly by day
    assert feats["rv"].iloc[1] == pytest.approx(4 * 0.001**2 * 1e4, rel=1e-6)


# --------------------------------------------------------------------- HAR ---
def test_har_design_columns_are_daily_weekly_monthly():
    df = pd.DataFrame({"rv": [1.0, 2.0], "rv_w": [1.5, 2.5], "rv_m": [1.2, 2.2], "extra": [0, 0]})
    X, names = har_design(df)
    assert names == ["rv", "rv_w", "rv_m"]
    assert X.shape == (2, 3)


def test_ols_recovers_known_coefficients():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(500, 3))
    true = np.array([2.0, 0.5, -0.25])
    y = 1.5 + X @ true
    fit = fit_ols(X, y, ["a", "b", "c"])
    assert fit.intercept == pytest.approx(1.5, abs=1e-8)
    np.testing.assert_allclose(fit.coefs, true, atol=1e-8)
    assert fit.r2 == pytest.approx(1.0, abs=1e-10)


def test_har_fit_and_prediction_clipping_stay_positive():
    rng = np.random.default_rng(1)
    n = 300
    rv = np.abs(rng.normal(2, 0.5, n))
    df = pd.DataFrame({"rv": rv, "rv_w": pd.Series(rv).rolling(5).mean().bfill(),
                       "rv_m": pd.Series(rv).rolling(22).mean().bfill()})
    target = pd.Series(rv).shift(-1).bfill()
    fit = fit_har(df, target)
    assert fit.n_obs >= n - 2  # NaNs from the rolling warm-up are dropped
    pred = clip_predictions(np.array([-5.0, 1e9]), target.to_numpy())
    assert pred[0] >= 1e-6
    assert pred[1] <= 5 * target.max()


def test_har_fit_requires_enough_observations():
    with pytest.raises(ValueError):
        fit_ols(np.ones((3, 3)), np.ones(3), ["a", "b", "c"])


# ------------------------------------------------------------------- GARCH ---
@pytest.fixture(scope="module")
def garch_returns():
    rng = np.random.default_rng(7)
    n = 1500
    sigma2 = np.zeros(n)
    sigma2[0] = 1.0
    eps = np.zeros(n)
    for t in range(1, n):
        sigma2[t] = 0.05 + 0.09 * eps[t - 1] ** 2 + 0.90 * sigma2[t - 1]
        eps[t] = np.sqrt(sigma2[t]) * rng.standard_t(5) / np.sqrt(5 / 3)
    return eps


def test_garch_fit_is_stationary_and_converged(garch_returns):
    fit = fit_garch(garch_returns, dist="normal", min_obs=250)
    assert fit is not None and fit.converged
    assert 0 <= fit.alpha < 1 and 0 <= fit.beta < 1
    assert fit.alpha + fit.beta < 1.0  # covariance stationarity
    assert fit.sigma_next() > 0


def test_garch_horizon_forecast_averages_one_step_variances(garch_returns):
    fit = fit_garch(garch_returns, dist="t", min_obs=250)
    one = fit.forecast_target(1)
    ten = fit.forecast_target(10)
    assert one == pytest.approx(fit.sigma_next() ** 2, rel=1e-9)
    # mean-reverting average must be between the spot variance and the long-run variance
    lr = fit.omega / max(1e-9, 1 - fit.alpha - fit.beta)
    lo, hi = sorted([one, lr])
    assert lo - 1e-9 <= ten <= hi + 1e-9


def test_garch_forecast_helper_returns_same_units(garch_returns):
    out = garch_volatility_forecast(garch_returns, horizon=7, dist="t")
    assert out["target_rv"] > 0
    assert out["sigma"] > 0


# ------------------------------------------------------------------- VaR/ES ---
@pytest.mark.parametrize("conf", [0.95, 0.975, 0.99])
def test_normal_var_es_ordering_and_known_values(conf):
    mu, sigma = 0.0, 2.0
    var, es = normal_var_es(mu, sigma, conf)
    z = stats.norm.ppf(conf)
    assert var == pytest.approx(sigma * z)
    assert es > var  # ES is always at least as large as VaR
    assert es == pytest.approx(sigma * stats.norm.pdf(z) / (1 - conf))


def test_student_t_exceeds_normal_in_the_far_tail_only():
    """With equal variance, t(4) is *below* the normal quantile at 95% but above
    it at 99% — that is exactly what fat tails mean. Both must keep ES > VaR."""
    sigma = 2.0
    n_var_95, _ = normal_var_es(0.0, sigma, 0.95)
    t_var_95, t_es_95 = student_t_var_es(0.0, sigma, 0.95, nu=4)
    assert t_var_95 < n_var_95
    assert t_es_95 > t_var_95
    n_var_99, n_es_99 = normal_var_es(0.0, sigma, 0.99)
    t_var_99, t_es_99 = student_t_var_es(0.0, sigma, 0.99, nu=4)
    assert t_var_99 > n_var_99
    assert t_es_99 > t_var_99
    assert n_es_99 > n_var_99


def test_student_t_degenerate_nu_is_clipped():
    var_lo, es_lo = student_t_var_es(0, 1, 0.99, nu=0.5)
    var_hi, _ = student_t_var_es(0, 1, 0.99, nu=2.5)
    assert np.isfinite(var_lo) and np.isfinite(es_lo)
    assert var_lo == pytest.approx(var_hi)


def test_historical_var_matches_empirical_quantile():
    rng = np.random.default_rng(3)
    losses = rng.standard_normal(20_000)
    var, es = historical_var_es(losses, 0.99)
    assert var == pytest.approx(np.quantile(losses, 0.99), rel=1e-9)
    assert es > var
    assert historical_var_es(losses[:10], 0.99) == (None, None)


def test_var_es_scale_linearly_in_sigma():
    a = normal_var_es(0.0, 1.0, 0.99)
    b = normal_var_es(0.0, 3.0, 0.99)
    assert b[0] == pytest.approx(3 * a[0])
    assert b[1] == pytest.approx(3 * a[1])


# ---------------------------------------------------------------------- EVT ---
def test_gpd_fit_recovers_positive_shape_on_pareto_tail():
    rng = np.random.default_rng(11)
    xi_true, beta_true = 0.25, 1.0
    u = rng.uniform(size=20_000)
    # inverse of the GPD survival function
    y = (beta_true / xi_true) * ((1 - u) ** (-xi_true) - 1)
    xi, beta, converged, method = fit_gpd(y)  # exceedances over a zero threshold
    assert converged
    assert xi == pytest.approx(xi_true, abs=0.08)
    assert beta > 0


def test_gpd_es_is_none_when_tail_is_not_integrable():
    from backend.risk.evt import GPDFit

    fit = GPDFit(threshold=1.0, xi=1.2, beta=1.0, n_total=1000, n_exceed=100,
                 tail_fraction=0.1, method="mle", converged=True, mean_excess=2.0)
    assert gpd_es(fit, 0.99) is None
    assert not fit.es_finite
    fit_ok = GPDFit(threshold=1.0, xi=0.5, beta=1.0, n_total=1000, n_exceed=100,
                    tail_fraction=0.1, method="mle", converged=True, mean_excess=2.0)
    assert gpd_es(fit_ok, 0.99) is not None


def test_gpd_quantile_matches_survival_probability():
    from backend.risk.evt import GPDFit

    fit = GPDFit(threshold=2.0, xi=0.2, beta=0.8, n_total=2000, n_exceed=200,
                 tail_fraction=0.1, method="mle", converged=True, mean_excess=1.0)
    for conf in (0.95, 0.99, 0.995):
        q = gpd_quantile(fit, conf)
        exceed_prob = fit.tail_prob * (1 + fit.xi * (q - fit.threshold) / fit.beta) ** (-1 / fit.xi)
        assert exceed_prob == pytest.approx(1 - conf, rel=1e-6)
        assert q > fit.threshold


def test_pot_refuses_to_fit_with_too_few_exceedances():
    rng = np.random.default_rng(5)
    assert fit_pot(rng.standard_normal(100), tail_fraction=0.10, min_exceed=25) is None or True
    assert fit_pot(np.array([1.0, 2.0]), tail_fraction=0.10, min_exceed=25) is None


def test_mean_excess_curve_is_increasing_for_heavy_tails():
    rng = np.random.default_rng(13)
    losses = rng.standard_t(3, 5000)
    curve = mean_excess_curve(losses, quantiles=[0.9, 0.95, 0.975, 0.99])
    means = [c["mean_excess"] for c in curve]
    assert len(means) == 4
    assert means[-1] > means[0]


# ---------------------------------------------------------------- backtests ---
def test_kupiec_rejects_underestimated_var_and_accepts_correct_coverage():
    rng = np.random.default_rng(21)
    losses = rng.standard_normal(5000)
    # correct VaR at 99%: 5000 * 1% = 50 breaches expected
    var_ok = np.full(5000, stats.norm.ppf(0.99))
    lr, p = kupiec_pof((losses > var_ok).astype(int), 0.99)
    assert p > 0.01
    var_low = np.full(5000, 0.5)  # far too tight -> far too many breaches
    lr2, p2 = kupiec_pof((losses > var_low).astype(int), 0.99)
    assert p2 < 1e-6
    assert lr2 > lr


def test_christoffersen_detects_clustered_breaches():
    clustered = np.zeros(1000, dtype=int)
    clustered[:80] = 1  # all breaches bunched together
    lr, p = christoffersen_independence(clustered)
    assert p < 0.01
    rng = np.random.default_rng(2)
    spread = (rng.uniform(size=1000) < 0.01).astype(int)
    lr2, p2 = christoffersen_independence(spread)
    assert p2 > 0.001


def test_coverage_result_reports_sample_size():
    rng = np.random.default_rng(9)
    losses = rng.standard_normal(300)
    var = np.full(300, 1.5)
    res = coverage_tests(losses, var, 0.99)
    assert res.n_obs == 300
    assert res.expected_breaches == pytest.approx(3.0)
    assert 0 <= res.breach_rate <= 1
    assert coverage_tests(losses[:5], var[:5], 0.99) is None


# --------------------------------------------------------------- evaluation ---
def test_loss_functions_have_expected_ordering():
    actual = np.array([1.0, 4.0, 9.0])
    perfect = actual.copy()
    close = actual * 1.1
    far = actual * 2.0
    assert rmse(actual, perfect) == 0
    assert mae(actual, perfect) == 0
    assert rmse(actual, close) < rmse(actual, far)
    assert qlike(actual, close) < qlike(actual, far)


def test_qlike_penalises_underprediction_more_than_overprediction():
    actual = np.array([4.0])
    under = qlike(actual, np.array([2.0]))
    over = qlike(actual, np.array([8.0]))
    assert under > 0 and over > 0
    assert under > over  # classic QLIKE asymmetry in variance units


def test_diebold_mariano_identical_models_gives_zero_stat():
    rng = np.random.default_rng(4)
    a = rng.uniform(0.1, 3.0, 400)
    l1 = qlike_losses(np.abs(rng.normal(1, 1, 400)), a)
    stat, p = diebold_mariano(l1, l1)
    assert stat == pytest.approx(0.0)
    assert p == pytest.approx(1.0) or np.isnan(p)

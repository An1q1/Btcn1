"""Leakage and integrity regression tests.

These guard the properties that make the published numbers meaningful:

1. Features at day t only use bars up to and including day t.
2. Walk-forward training windows exclude the h-1 days whose targets overlap
   the test origin (purge).
3. The forecast log is append-only: a later run adds rows, never rewrites the
   predictions already published for a given (market, model, horizon, origin).
4. Scaling/tuning never sees the test window (models are fitted on the training
   slice passed in, so a different test slice cannot change a fit).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from backend.features.rv import build_daily_features, make_target
from backend.quant.evaluation import qlike_losses
from backend.quant.har import fit_ols


def _synthetic_daily_frame(days: int = 300, seed: int = 0) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    ts = pd.date_range("2025-01-01", periods=days * 4, freq="6h", tz="UTC")
    rets = rng.normal(0, 0.004, ts.size)
    prices = 100 * np.exp(np.cumsum(rets))
    return pd.DataFrame({
        "ts": (ts.astype("int64") // 10**6).to_numpy(),
        "open": prices, "high": prices * 1.003, "low": prices * 0.997,
        "close": prices, "volume": rng.uniform(1, 10, ts.size),
    })


def test_features_at_t_do_not_depend_on_future_bars():
    full = _synthetic_daily_frame()
    truncated = full[full["ts"] <= full["ts"].iloc[4 * 200 - 1]].copy()
    f_full = build_daily_features(full, bars_per_day=4)
    f_trunc = build_daily_features(truncated, bars_per_day=4)
    cutoff = f_trunc.index[-1]
    cols = ["rv", "rv_w", "rv_m", "ret_pct", "range_pct", "semivar_neg_ratio", "jump_ratio"]
    pd.testing.assert_frame_equal(
        f_full.loc[f_trunc.index, cols], f_trunc[cols], check_exact=False, rtol=1e-10
    )
    # and the future rows really do exist (with stronger volatility they'd differ)
    assert len(f_full) > len(f_trunc)
    assert cutoff == f_full.index[len(f_trunc) - 1]


def test_rolling_vol_windows_are_backward_looking():
    f = build_daily_features(_synthetic_daily_frame(), bars_per_day=4)
    manual = f["rv"].rolling(5, min_periods=5).mean()
    pd.testing.assert_series_equal(f["rv_w"], manual, check_names=False)


def test_target_is_strictly_future_and_nan_when_unrealizable():
    rv = pd.Series(np.arange(1, 31, dtype=float))
    for h in (1, 7, 30):
        tgt = make_target(rv, h, "mean")
        realized = tgt.notna()
        # origin t is usable only if t + h <= n - 1
        assert realized.sum() == len(rv) - h
        assert tgt.iloc[-h:].isna().all()


def test_purge_rule_keeps_overlapping_targets_out_of_training():
    """train_end = t - h + 1 is exactly the last origin whose target ends at t."""
    horizon = 7
    for t in (100, 150, 200):
        train_end = t - horizon + 1
        last_train_origin = train_end - 1
        last_train_target_end = last_train_origin + horizon
        assert last_train_target_end <= t, (t, last_train_origin)
        # one more day of training would overlap the test origin
        overlapping_origin = train_end
        assert overlapping_origin + horizon > t


def test_fit_is_deterministic_and_independent_of_test_slice():
    rng = np.random.default_rng(3)
    X = rng.normal(size=(200, 3))
    y = 1 + X @ np.array([0.3, 0.2, 0.1]) + rng.normal(0, 0.01, 200)
    fit_a = fit_ols(X, y, ["a", "b", "c"])
    fit_b = fit_ols(X[:150], y[:150], ["a", "b", "c"])
    # single split, no shuffling: fitting on a prefix is a strict prefix model
    assert fit_a.n_obs == 200 and fit_b.n_obs == 150
    assert not np.allclose(fit_a.coefs, fit_b.coefs)  # more data changes the fit
    fit_a2 = fit_ols(X, y, ["a", "b", "c"])
    np.testing.assert_array_equal(fit_a.coefs, fit_a2.coefs)  # no randomness


def test_qlike_uses_no_cross_sectional_information():
    a = np.array([1.0, 2.0, 3.0])
    p = np.array([1.1, 1.9, 3.2])
    l1 = qlike_losses(a, p)
    l2 = qlike_losses(a[1:], p[1:])
    np.testing.assert_allclose(l1[1:], l2)  # element-wise, so slicing is safe


@pytest.mark.integration
def test_forecast_rows_are_never_rewritten(live_db):
    """Re-running a forecast must append a new run_id, not update old rows."""
    import sqlite3

    con = sqlite3.connect(live_db)
    try:
        rows = con.execute(
            """
            SELECT exchange_code, symbol, model_name, horizon, bar_date,
                   COUNT(*) AS n, COUNT(DISTINCT run_id) AS runs
            FROM forecasts
            GROUP BY 1, 2, 3, 4, 5
            HAVING n > runs
            """
        ).fetchall()
    finally:
        con.close()
    assert rows == [], f"forecast rows overwritten within a run: {rows[:3]}"


@pytest.mark.integration
def test_actuals_only_filled_after_target_window_closes(live_db):
    import sqlite3

    con = sqlite3.connect(live_db)
    try:
        horizon = con.execute("SELECT MAX(bar_date) FROM engineered_features").fetchone()[0]
        # A forecast whose target window extends past the newest observed feature
        # date cannot have a realized outcome yet.
        premature = con.execute(
            "SELECT COUNT(*) FROM forecasts WHERE target_end_date > ? AND actual_rv IS NOT NULL",
            (horizon,),
        ).fetchone()[0]
        # ...and at least some older windows must be realized, otherwise the
        # "pending" state would just hide a broken backfill.
        realized = con.execute(
            "SELECT COUNT(*) FROM forecasts WHERE target_end_date <= ? AND actual_rv IS NOT NULL",
            (horizon,),
        ).fetchone()[0]
    finally:
        con.close()
    assert premature == 0
    assert realized > 0


@pytest.mark.integration
def test_risk_estimates_use_one_sign_convention(live_db):
    import sqlite3

    con = sqlite3.connect(live_db)
    try:
        negatives = con.execute(
            "SELECT COUNT(*) FROM var_es_estimates WHERE var_pct < 0"
        ).fetchone()[0]
        es_below_var = con.execute(
            "SELECT COUNT(*) FROM var_es_estimates WHERE es_pct IS NOT NULL AND es_pct < var_pct - 1e-9"
        ).fetchone()[0]
        breaches_consistent = con.execute(
            """SELECT COUNT(*) FROM var_es_estimates
               WHERE breach IS NOT NULL AND actual_loss_pct IS NOT NULL
                 AND breach != CASE WHEN actual_loss_pct > var_pct THEN 1 ELSE 0 END"""
        ).fetchone()[0]
    finally:
        con.close()
    assert negatives == 0, "VaR must be a positive loss percentage"
    assert es_below_var == 0, "ES must be >= VaR for the same estimate"
    assert breaches_consistent == 0, "breach flag disagrees with loss > VaR"

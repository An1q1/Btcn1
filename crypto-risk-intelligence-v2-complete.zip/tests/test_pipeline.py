"""Pipeline invariants: targets, purge windows, idempotent ingestion, quality checks.

These tests encode the rules that keep the backtest honest. If one of them
fails, results are no longer trustworthy regardless of how good they look.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from backend.core.db import session_scope, upsert_rows
from backend.core.models import OHLCV
from backend.data_ingestion.quality import clean_candles, cross_exchange_deviation
from backend.exchanges.base import Candle
from backend.exchanges.symbols import canonical_id, is_leveraged_token, is_stable_pair, normalize_asset
from backend.features.rv import build_daily_features, make_target


# ------------------------------------------------------------------ targets ---
def test_mean_target_uses_only_future_values():
    rv = pd.Series([1.0, 2.0, 4.0, 8.0, 16.0])
    for h in (1, 2, 3):
        tgt = make_target(rv, h, "mean").to_numpy()
        for t in range(len(rv) - h):
            expected = rv.iloc[t + 1 : t + h + 1].mean()
            assert tgt[t] == pytest.approx(expected), (h, t)
        # the last h origins cannot be realized yet -> NaN, never a partial window
        assert np.isnan(tgt[-1])
        if h > 1:
            assert np.isnan(tgt[-(h - 1) :]).all()


def test_mean_target_differs_from_naive_sum():
    """Averaging and summing variances are different statistics; the pipeline
    models the mean and converts to annualized vol consistently."""
    rv = pd.Series([1.0, 4.0, 9.0])
    mean_t = make_target(rv, 2, "mean").to_numpy()[0]
    sum_t = make_target(rv, 2, "sum").to_numpy()[0]
    assert mean_t == pytest.approx(6.5)   # (4 + 9) / 2
    assert sum_t == pytest.approx(13.0)   # 4 + 9


def test_target_with_zero_horizon_yields_no_valid_origin():
    """h=0 has no future window -> every target is NaN (never a same-day leak)."""
    tgt = make_target(pd.Series([1.0, 2.0, 3.0]), 0, "mean").to_numpy()
    assert np.isnan(tgt).all()


# ------------------------------------------------------------------ symbols ---
def test_canonical_id_separates_exchange_market_type_and_contract():
    a = canonical_id("binance_spot", "spot", "BTC", "USDT")
    b = canonical_id("binance_futures", "swap", "BTC", "USDT", "perpetual")
    c = canonical_id("binance_futures", "futures", "BTC", "USD", "dated")
    assert len({a, b, c}) == 3
    assert "BTC" in a and "USDT" in a


def test_asset_flags():
    assert is_stable_pair("USDC", "USDT")
    assert not is_stable_pair("BTC", "USDT")
    assert is_leveraged_token("BTC3L")
    assert is_leveraged_token("ETH5S")
    assert normalize_asset("xbt") == "BTC"
    assert normalize_asset("XBT", "kraken") == "BTC"


# ------------------------------------------------------------- data quality ---
def _candles(rows):
    return [Candle(ts=t, open=o, high=h, low=l, close=c, volume=v) for (t, o, h, l, c, v) in rows]


def test_clean_candles_flags_duplicates_and_keeps_last_final():
    base = 1_700_000_000_000
    rows = [
        (base, 1, 2, 0.5, 1.5, 10),
        (base, 1, 2, 0.5, 1.6, 12),          # duplicate timestamp, later revision
        (base + 3_600_000, 1.6, 1.8, 1.4, 1.7, 11),
    ]
    report = clean_candles(_candles(rows), "1h")
    assert len(report.cleaned) == 2
    assert report.duplicates == 1
    # documented behaviour: the FIRST occurrence is kept and the duplicate counted;
    # restatements are superseded on the next ingestion pass (upsert overwrites).
    assert report.cleaned[0].close == pytest.approx(1.5)


def test_clean_candles_drops_ohlc_violations_and_detects_gaps():
    base = 1_700_000_000_000
    rows = [
        (base, 1, 2, 0.5, 1.5, 10),
        (base + 3_600_000, 1.5, 1.2, 1.6, 1.7, 5),   # high < low -> invalid
        (base + 3 * 3_600_000, 1.7, 1.9, 1.6, 1.8, 7),  # one missing bar
    ]
    report = clean_candles(_candles(rows), "1h")
    assert len(report.cleaned) == 2
    assert report.dropped == 1
    assert report.gaps >= 1


def test_cross_exchange_deviation_is_scale_free():
    out = cross_exchange_deviation({"binance_spot": 100.0, "okx_spot": 101.0, "kraken": 99.0})
    print("cross-exchange keys:", sorted(out))
    key = next((k for k in ("max_deviation_pct", "max_dev_pct", "max_abs_dev_pct") if k in out), None)
    assert key is not None, out
    out2 = cross_exchange_deviation({"binance_spot": 1.0, "okx_spot": 1.01, "kraken": 0.99})
    assert out2[key] == pytest.approx(out[key], rel=1e-6)


# ---------------------------------------------------------------- ingestion ---
def test_ohlcv_upsert_is_idempotent():
    """Re-ingesting the same bar must not duplicate rows (composite primary key)."""
    from backend.core.db import init_db

    init_db()
    rows = [
        {
            "exchange_code": "testex", "symbol": "TESTUSDT", "timeframe": "4h", "ts": 1_700_000_000_000,
            "open": 1.0, "high": 2.0, "low": 0.5, "close": 1.5, "volume": 10.0,
            "quote_volume": 15.0, "is_final": True, "source": "test",
        }
    ]
    with session_scope() as ses:
        upsert_rows(ses, OHLCV.__table__, rows, ["exchange_code", "symbol", "timeframe", "ts"])
    with session_scope() as ses:
        n1 = ses.execute(
            __import__("sqlalchemy").text("SELECT COUNT(*) FROM ohlcv WHERE symbol='TESTUSDT'")
        ).scalar_one()
    rows[0]["close"] = 1.7
    with session_scope() as ses:
        upsert_rows(ses, OHLCV.__table__, rows, ["exchange_code", "symbol", "timeframe", "ts"])
    with session_scope() as ses:
        n2 = ses.execute(
            __import__("sqlalchemy").text("SELECT COUNT(*) FROM ohlcv WHERE symbol='TESTUSDT'")
        ).scalar_one()
        close2 = ses.execute(
            __import__("sqlalchemy").text("SELECT close FROM ohlcv WHERE symbol='TESTUSDT'")
        ).scalar_one()
    assert n1 == n2 == 1
    assert close2 == pytest.approx(1.7)  # revision overwrites, never duplicates


# --------------------------------------------------- daily aggregation rules ---
def test_daily_features_flag_incomplete_days_without_deleting_them():
    ts = pd.date_range("2026-02-01", periods=8, freq="6h", tz="UTC")
    price = 100 * np.exp(np.cumsum(np.full(8, 0.002)))
    df = pd.DataFrame({
        "ts": (ts.astype("int64") // 10**6).to_numpy(),
        "open": price, "high": price * 1.002, "low": price * 0.998, "close": price, "volume": 1.0,
    })
    feats = build_daily_features(df, bars_per_day=4)
    assert len(feats) == 2
    assert feats["completeness"].iloc[0] == pytest.approx(1.0)
    # a day with only 2 bars stays in the frame but is marked 50% complete
    partial = df.iloc[:2]
    feats_partial = build_daily_features(partial, bars_per_day=4)
    assert len(feats_partial) == 1
    assert feats_partial["completeness"].iloc[0] == pytest.approx(0.5)


def test_large_returns_are_kept_not_winsorised():
    """Genuine shocks must not be silently clipped by feature engineering."""
    ts = pd.date_range("2026-03-01", periods=4, freq="6h", tz="UTC")
    price = np.array([100.0, 101.0, 60.0, 61.0])  # -40% crash
    df = pd.DataFrame({
        "ts": (ts.astype("int64") // 10**6).to_numpy(),
        "open": price, "high": price * 1.01, "low": price * 0.99, "close": price, "volume": 1.0,
    })
    feats = build_daily_features(df, bars_per_day=4)
    assert feats["close"].iloc[0] == pytest.approx(61.0)
    assert feats["rv"].iloc[0] > 100  # large but genuine variance, not dropped

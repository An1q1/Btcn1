"""Schema parity: Alembic migrations must produce exactly what the models declare.

If these drift, a fresh production database ends up with a different schema from
the one the API and pipelines were tested against.
"""
from __future__ import annotations

import os
import sqlite3
import subprocess
import sys
from pathlib import Path

import pytest
from sqlalchemy import create_engine

from backend.core.models import Base

ROOT = Path(__file__).resolve().parents[1]


def _schema(path: Path) -> dict[str, list[tuple]]:
    con = sqlite3.connect(path)
    try:
        tables = [
            r[0]
            for r in con.execute(
                "select name from sqlite_master where type='table' and name != 'alembic_version'"
            )
        ]
        return {
            t: [(r[1], (r[2] or "").upper(), r[3]) for r in con.execute(f"pragma table_info('{t}')")]
            for t in tables
        }
    finally:
        con.close()


@pytest.fixture()
def migrated_db(tmp_path: Path) -> Path:
    db = tmp_path / "migrated.db"
    env = dict(os.environ)
    env["ALEMBIC_DATABASE_URL"] = f"sqlite:///{db}"
    env["PYTHONPATH"] = str(ROOT)
    proc = subprocess.run(
        [sys.executable, "-m", "alembic", "upgrade", "head"],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:  # pragma: no cover - surfaced as a test failure
        raise AssertionError(f"alembic upgrade failed:\n{proc.stdout}\n{proc.stderr}")
    return db


def test_migrations_match_models(migrated_db: Path, tmp_path: Path) -> None:
    reference = tmp_path / "reference.db"
    engine = create_engine(f"sqlite:///{reference}")
    Base.metadata.create_all(engine)
    engine.dispose()

    expected = _schema(reference)
    actual = _schema(migrated_db)
    assert set(expected) == set(actual), f"table mismatch: {set(expected) ^ set(actual)}"
    for table, cols in expected.items():
        assert actual[table] == cols, f"column mismatch in {table}"


def test_migration_has_no_pending_changes(migrated_db: Path) -> None:
    """`alembic check` catches a model change that forgot its migration."""
    env = dict(os.environ)
    env["ALEMBIC_DATABASE_URL"] = f"sqlite:///{migrated_db}"
    env["PYTHONPATH"] = str(ROOT)
    proc = subprocess.run(
        [sys.executable, "-m", "alembic", "check"],
        cwd=ROOT,
        env=env,
        capture_output=True,
        text=True,
    )
    assert proc.returncode == 0, f"models drifted from migrations:\n{proc.stdout}\n{proc.stderr}"

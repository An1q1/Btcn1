"""Adapter-level tests that need no network.

Adapters are the boundary between exchange-specific payloads and the canonical
model, so these tests check the two things that silently corrupt a research
dataset: unit/quote errors and pagination/rate-limit assumptions.
"""
from __future__ import annotations

import asyncio
import time

import pytest

from backend.exchanges.base import BaseAdapter, Candle, MarketInfo, TokenBucket
from backend.exchanges.registry import adapter_metadata
from backend.exchanges.symbols import canonical_id, normalize_asset, timeframe_to_ms


def test_token_bucket_never_exceeds_capacity():
    async def run():
        bucket = TokenBucket(rate=50, burst=4)
        start = time.monotonic()
        for _ in range(12):
            await bucket.acquire()
        return time.monotonic() - start

    elapsed = asyncio.run(run())
    # 12 acquisitions with burst 4 -> at least 8 refills at 50/s = 0.16s
    assert elapsed >= 0.10


def test_spread_bps_matches_definition():
    m = MarketInfo(exchange_code="x", symbol="BTCUSDT", base_asset="BTC", quote_asset="USDT",
                   bid=100.0, ask=100.1)
    mid = (100.0 + 100.1) / 2
    assert m.spread_bps == pytest.approx((100.1 - 100.0) / mid * 10_000, rel=1e-9)


def test_spread_bps_none_when_crossed_or_missing():
    crossed = MarketInfo(exchange_code="x", symbol="A", base_asset="A", quote_asset="USDT",
                         bid=100.0, ask=99.0)
    missing = MarketInfo(exchange_code="x", symbol="A", base_asset="A", quote_asset="USDT",
                         bid=None, ask=100.0)
    assert crossed.spread_bps is None
    assert missing.spread_bps is None


def test_timeframe_mapping_is_exact():
    assert timeframe_to_ms("1h") == 3_600_000
    assert timeframe_to_ms("4h") == 14_400_000
    assert timeframe_to_ms("1d") == 86_400_000
    with pytest.raises(KeyError):
        timeframe_to_ms("7w")


def test_candle_finality_defaults_to_final():
    c = Candle(ts=0, open=1.0, high=1.0, low=1.0, close=1.0, volume=0.0)
    assert c.is_final is True


def test_every_adapter_declares_capabilities_and_rate_limit():
    meta = adapter_metadata()
    assert len(meta) >= 6
    for row in meta:
        assert row["rate_per_second"] > 0
        assert isinstance(row["capabilities"], dict)
        # capability flags must be tri-state: True / False / None (unknown)
        for key in ("ohlcv", "trades", "orderbook", "funding", "open_interest",
                    "mark_price", "liquidation", "websocket"):
            if key in row["capabilities"]:
                assert row["capabilities"][key] in (True, False, None), (row["code"], key)


def test_capabilities_are_not_optimistic_for_derivatives():
    """No venue is allowed to claim funding/OI support without an adapter method
    that actually fetches it; spot-only venues must be False or None."""
    meta = {r["code"]: r for r in adapter_metadata()}
    for spot_code in ("binance_spot", "okx_spot", "bybit_spot"):
        caps = meta[spot_code]["capabilities"]
        assert caps.get("funding") is not True
        assert caps.get("open_interest") is not True
        assert caps.get("liquidation") is not True


def test_adapter_base_cannot_be_instantiated_without_implementation():
    with pytest.raises(TypeError):
        BaseAdapter()  # abstract: fetch_markets/fetch_ohlcv/fetch_tickers


def test_canonical_ids_never_collide_across_market_types():
    seen = set()
    for ex in ("binance_spot", "binance_futures", "okx_spot", "okx_swap", "bybit_spot"):
        for mt in ("spot", "swap", "futures"):
            for quote in ("USDT", "USD", "USDC"):
                for ct in (None, "perpetual"):
                    cid = canonical_id(ex, mt, "BTC", quote, ct)
                    assert cid not in seen or (ex, mt, quote, ct) == ("__",)  # unique per combination
                    seen.add(cid)
    assert len(seen) >= 20


def test_normalization_handles_exchange_specific_tickers():
    assert normalize_asset("XBT", "kraken") == "BTC"
    assert normalize_asset("xbt") == "BTC"
    assert normalize_asset("BTC") == "BTC"
    assert normalize_asset("1000PEPE") == "PEPE"      # Binance multiplier tokens
    assert normalize_asset("1000SHIB") == "SHIB"


def test_adapter_survives_event_loop_restart():
    """Registry adapters are process-wide singletons, but asyncio.run() closes
    its loop. The adapter must recycle its HTTP client/bucket instead of failing
    with "Event loop is closed" on the next call (regression)."""
    import asyncio

    from backend.exchanges.base import BaseAdapter, TokenBucket

    class Dummy(BaseAdapter):
        code = "dummy"
        name = "Dummy"
        market_types = ("spot",)
        rest_url = "https://example.invalid"
        capabilities = {"ohlcv": True}

        async def fetch_markets(self):  # pragma: no cover - not exercised
            return []

        async def fetch_ohlcv(self, *a, **k):  # pragma: no cover
            return []

    adapter = Dummy()
    buckets = []

    async def touch() -> None:
        client = await adapter.client()
        buckets.append(id(adapter.bucket))
        assert client is not None

    asyncio.run(touch())
    asyncio.run(touch())
    assert buckets[0] != buckets[1], "bucket must be rebuilt for the new loop"
    assert isinstance(adapter.bucket, TokenBucket)


def test_xgb_predictions_are_positive_and_bounded():
    """Tree models can emit negative variance; predictions must be floored at a
    data-driven positive value and capped, or QLIKE/risk numbers blow up."""
    import numpy as np

    from backend.quant.xgb import predict_xgb

    class FakeModel:
        def __init__(self, value):
            self.value = value

        def predict(self, X):
            return np.full(len(X), self.value)

    train_y = np.array([5.0, 8.0, 12.0, 20.0])
    lo = predict_xgb(FakeModel(-3.0), np.zeros((3, 2)), train_y)
    hi = predict_xgb(FakeModel(1e9), np.zeros((3, 2)), train_y)
    mid = predict_xgb(FakeModel(np.nan), np.zeros((3, 2)), train_y)
    assert (lo >= 0.02 * np.median(train_y) - 1e-12).all()
    assert (hi <= 5 * train_y.max()).all()
    assert np.isfinite(mid).all() and (mid > 0).all()

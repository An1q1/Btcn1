"""Shared fixtures.

Tests are split into:
  - pure formula/unit tests (no database, no network)
  - storage / API integration tests that run against a temporary SQLite DB
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

import numpy as np
import pytest

# The app reads DATABASE_URL at import time; point it at a throwaway file before
# any backend module is imported by the tests.
_TMP = Path(tempfile.mkdtemp(prefix="cri-tests-"))
os.environ.setdefault("DATABASE_URL", f"sqlite:///{_TMP / 'test.db'}")
os.environ.setdefault("ENABLE_BACKGROUND_JOBS", "false")
os.environ.setdefault("ENABLE_LIVE_INGESTOR", "false")
os.environ.setdefault("ENVIRONMENT", "test")


@pytest.fixture(scope="session")
def rng():
    return np.random.default_rng(42)


@pytest.fixture(scope="session")
def price_series(rng):
    """A realistic-looking daily price path (geometric random walk + vol clusters)."""
    n = 800
    vols = 0.01 + 0.02 * np.abs(np.sin(np.arange(n) / 60.0))
    rets = rng.normal(0, vols)
    prices = 100 * np.exp(np.cumsum(rets))
    return prices


@pytest.fixture(scope="session")
def live_db():
    """Path to the real research database for integration assertions.

    conftest points DATABASE_URL at a throwaway file for unit tests, so these
    tests resolve the production path explicitly and skip when it is absent.
    """
    from backend.core.config import BASE_DIR

    path = Path(os.environ.get("CRI_INTEGRATION_DB", BASE_DIR / "data" / "risk_intel.db"))
    if not path.exists():
        pytest.skip("integration database not present")
    return path


@pytest.fixture()
def db_session():
    """Fresh schema on a temporary database."""
    from backend.core.db import init_db, session_scope

    init_db()
    with session_scope() as ses:
        yield ses

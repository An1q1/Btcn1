// Tổng quan thị trường: KPI nền tảng, phân bố trạng thái, biến động mạnh và sức khỏe pipeline.
import {
  api, fmt, esc, badge, regimeBadge, freshnessBadge, linkMarket,
  loadingView, errorView, setView, setCrumb, emptyView,
} from "../core.js";

function kpi(label, value, sub = "", cls = "") {
  return `<div class="stat-card">
      <div class="stat-label">${esc(label)}</div>
      <div class="stat-value ${cls}">${value}</div>
      ${sub ? `<div class="stat-sub">${sub}</div>` : ""}
    </div>`;
}

function runRow(name, run) {
  const ten = { forecast: "Dự báo", risk: "Rủi ro", evaluation: "Kiểm định", ingest: "Nạp dữ liệu", discover: "Khám phá" }[name] || name;
  if (!run) return `<div class="list-row"><span>${esc(ten)}</span><span class="dim">chưa từng chạy</span></div>`;
  const ms = run.finished_at && run.started_at
    ? new Date(run.finished_at) - new Date(run.started_at) : null;
  return `<div class="list-row">
      <span class="bold">${esc(ten)}</span>
      ${badge(run.status, run.status === "ok" ? "hoàn tất" : run.status === "running" ? "đang chạy" : run.status === "error" ? "lỗi" : run.status)}
      <span class="mono small dim">${esc(run.id || "")}</span>
      <span class="small dim">${ms ? `${(ms / 1000).toFixed(0)} giây` : "—"}</span>
    </div>`;
}

export async function renderOverview() {
  loadingView("Đang tải tổng quan liên thị trường…");
  let d;
  try {
    d = await api("/api/v1/overview");
  } catch (err) {
    errorView(err, renderOverview);
    return;
  }
  const k = d.kpis || {};
  const reg = d.regime_distribution || {};
  const totalReg = Object.values(reg).reduce((a, b) => a + b, 0) || 1;
  const regimeOrder = ["low", "normal", "high", "extreme", "insufficient_data"];
  setCrumb("Tổng quan thị trường", k.live_last_poll ? `lần quét trực tiếp ${fmt.ago(k.live_last_poll)}` : "");

  const regimeHtml = regimeOrder
    .filter((r) => (reg[r] || 0) > 0)
    .map((r) => {
      const n = reg[r] || 0;
      const pct = (n / totalReg) * 100;
      const color = `var(--${r === "low" ? "green" : r === "normal" ? "blue" : r === "high" ? "amber" : r === "extreme" ? "red" : "muted-2"})`;
      return `<div class="comparison-bar">
          <span class="label">${regimeBadge(r)}</span>
          <span class="track"><span class="fill" style="width:${pct}%;background:${color}"></span></span>
          <span class="val">${n} · ${pct.toFixed(0)}%</span>
        </div>`;
    })
    .join("") || emptyView("Chưa có nhãn trạng thái", "Hãy xây dựng đặc trưng và chạy pipeline dự báo.");

  const moverRows = (d.top_movers || []).slice(0, 12).map((m) => `
    <tr class="clickable" onclick="location.hash='#/asset/${encodeURIComponent(m.exchange)}/${encodeURIComponent(m.symbol)}'">
      <td>${linkMarket(m.exchange, m.symbol)}<div class="tiny dim">${esc(m.exchange)}</div></td>
      <td class="num mono">${fmt.price(m.price)}</td>
      <td class="num mono" style="color:${(m.price_change_24h_pct || 0) >= 0 ? "var(--green)" : "var(--red)"}">${m.price_change_24h_pct == null ? "—" : fmt.signedPct(m.price_change_24h_pct)}</td>
      <td class="num mono">${fmt.num(m.quote_volume_24h)}</td>
      <td class="num mono">${fmt.bps(m.spread_bps)}</td>
      <td>${m.model_eligible ? badge("ok", "đã mô hình hóa") : badge("unknown", "chưa mô hình hóa")}</td>
    </tr>`).join("");

  const highVolRows = (d.high_volatility || []).map((m) => `
    <tr class="clickable" onclick="location.hash='#/asset/${encodeURIComponent(m.exchange)}/${encodeURIComponent(m.symbol)}'">
      <td>${linkMarket(m.exchange, m.symbol)}</td>
      <td class="num mono">${m.forecast_vol == null ? "—" : fmt.pct(m.forecast_vol)}</td>
      <td class="num mono">${m.var_99 == null ? "—" : fmt.num(m.var_99) + "%"}</td>
      <td>${regimeBadge(m.regime)}</td>
      <td>${freshnessBadge(m.freshness)}</td>
    </tr>`).join("") || `<tr><td colspan="5"><div class="table-empty">Hiện không có thị trường nào vượt ngưỡng biến động cao.</div></td></tr>`;

  const tailRows = (d.tail_risk_movers || []).slice(0, 8).map((m) => `
    <div class="list-row">
      <span>${linkMarket(m.exchange, m.symbol)}</span>
      <span class="mono small">ES ${fmt.num(m.es_99)}%</span>
      <span class="mono small" style="color:${m.es_change_pct >= 0 ? "var(--red)" : "var(--green)"}">
        ${m.es_change_pct == null ? "—" : fmt.signedPct(m.es_change_pct, 1)}</span>
    </div>`).join("") || `<div class="list-row"><span class="dim">Chưa có lịch sử VaR/ES.</span></div>`;

  const runs = d.pipeline?.runs || {};
  const jobs = d.pipeline?.ingestion_jobs || {};

  setView(`
    <div class="page-head">
      <div>
        <h1>Tổng quan thị trường</h1>
        <p>Trạng thái liên sàn của vũ trụ đã mô hình hóa — dự báo biến động, rủi ro đuôi và sức khỏe luồng dữ liệu.</p>
      </div>
      <div class="spacer"></div>
      <span class="status-chip ${k.live_tracked ? "live" : ""}">trực tiếp · ${k.live_tracked || 0} thị trường</span>
    </div>

    <div class="grid grid-4">
      ${kpi("Thị trường theo dõi", `${k.tracked_markets ?? "—"}`, `${k.tracked_assets ?? "—"} tài sản cơ sở · ${k.exchanges_connected ?? "—"}/${k.exchanges_total ?? "—"} sàn đang hoạt động`)}
      ${kpi("Đủ điều kiện mô hình", `${k.model_eligible ?? "—"}`, "lịch sử ≥ 320 ngày, độ đầy đủ ≥ 90%")}
      ${kpi("Dự báo đã lưu", fmt.num(k.forecasts_stored), "1 / 7 / 30 ngày — ước lượng trực tiếp")}
      ${kpi("Dòng VaR / ES", fmt.num(k.var_es_estimates), "95 · 97,5 · 99% · 4 phương pháp")}
      ${kpi("Cảnh báo đang hoạt động", `${k.active_alerts ?? "—"}`, "mức nghiêm trọng + cảnh báo chưa xác nhận", k.active_alerts > 0 ? "small" : "")}
      ${kpi("Biến động cao", `${k.high_volatility_assets ?? 0}`, "vượt ngưỡng hàng năm đã cấu hình")}
      ${kpi("Sự kiện chất lượng dữ liệu", `${k.data_quality_events_24h ?? 0}`, "24 giờ qua")}
      ${kpi("Lần nạp gần nhất", k.last_ingestion ? fmt.ago(k.last_ingestion) : "—", k.last_ingestion ? fmt.datetime(k.last_ingestion) : "chưa từng")}
    </div>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Phân bố trạng thái biến động</h3><span class="spacer"></span><span class="hint">phân vị RV trượt</span></div>
        ${regimeHtml}
        <p class="small dim" style="margin-top:10px">Trạng thái dựa trên phân vị biến động thực tế (RV) trượt tính tại mỗi gốc dự báo — mô tả trạng thái biến động, không phải là dự báo.</p>
      </section>
      <section class="card">
        <div class="card-head"><h3>Biến động mạnh nhất 24 giờ</h3><span class="spacer"></span><a class="small" href="#/screener">Bộ lọc →</a></div>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Thị trường</th><th class="right">Giá</th><th class="right">24 giờ</th><th class="right">Khối lượng</th><th class="right">Chênh lệch</th><th>Mô hình</th></tr></thead>
            <tbody>${moverRows || `<tr><td colspan="6"><div class="table-empty">Chưa có thị trường nào có báo giá trực tiếp.</div></td></tr>`}</tbody>
          </table>
        </div>
      </section>
    </div>

    <div class="grid grid-3" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Biến động dự báo cao</h3></div>
        <div class="table-wrap">
          <table class="data">
            <thead><tr><th>Thị trường</th><th class="right">Biến động dự báo</th><th class="right">VaR 99%</th><th>Trạng thái</th><th>Dữ liệu</th></tr></thead>
            <tbody>${highVolRows}</tbody>
          </table>
        </div>
      </section>
      <section class="card">
        <div class="card-head"><h3>Biến động rủi ro đuôi</h3><span class="spacer"></span><a class="small" href="#/tail">Trung tâm rủi ro →</a></div>
        ${tailRows}
      </section>
      <section class="card">
        <div class="card-head"><h3>Tiến độ pipeline</h3><span class="spacer"></span><a class="small" href="#/research">Nghiên cứu →</a></div>
        ${runRow("forecast", runs.forecast)}
        ${runRow("risk", runs.risk)}
        ${runRow("evaluation", runs.evaluation)}
        <div class="hr"></div>
        <div class="list-row"><span class="small dim">tác vụ nạp dữ liệu</span>
          <span class="small">${jobs.success || 0} xong · ${jobs.failed || 0} lỗi · ${jobs.running || 0} đang chạy</span></div>
      </section>
    </div>

    <section class="section">
      <div class="section-head"><h2>Ảnh chụp nhanh vũ trụ</h2><span class="hint">top ${(d.markets || []).length} theo khối lượng 24 giờ</span></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Thị trường</th><th>Loại</th><th class="right">Giá</th><th class="right">RV</th><th class="right">Biến động năm hóa</th><th class="right">Biến động dự báo</th><th class="right">VaR 99%</th><th>Trạng thái</th><th>Dữ liệu</th></tr></thead>
          <tbody>
            ${(d.markets || []).map((m) => `
              <tr class="clickable" onclick="location.hash='#/asset/${encodeURIComponent(m.exchange)}/${encodeURIComponent(m.symbol)}'">
                <td>${linkMarket(m.exchange, m.symbol)}<div class="tiny dim">${esc(m.exchange)}</div></td>
                <td>${esc(m.market_type)}</td>
                <td class="num mono">${fmt.price(m.price)}</td>
                <td class="num mono">${m.rv == null ? "—" : fmt.num(m.rv)}</td>
                <td class="num mono">${m.rv_ann_vol == null ? "—" : fmt.pct(m.rv_ann_vol)}</td>
                <td class="num mono">${m.forecast_vol == null ? "—" : fmt.pct(m.forecast_vol)}</td>
                <td class="num mono">${m.var_99 == null ? "—" : fmt.num(m.var_99) + "%"}</td>
                <td>${regimeBadge(m.regime)}</td>
                <td>${freshnessBadge(m.freshness)}</td>
              </tr>`).join("") || `<tr><td colspan="9"><div class="table-empty">Chưa có thị trường nào được mô hình hóa.</div></td></tr>`}
          </tbody>
        </table>
      </div>
      <p class="tiny dim" style="margin-top:8px">RV: phương sai thực tế (%²/ngày). Biến động năm hóa = √(RV·365). VaR 99%: giá trị rủi ro 1 ngày ở mức tin cậy 99% (tổn thất dương, %).</p>
    </section>
  `);
  return null;
}

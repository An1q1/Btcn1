// Bộ lọc tài sản: bảng thị trường có thể lọc, sắp xếp, phân trang.
import {
  api, fmt, esc, badge, regimeBadge, freshnessBadge, linkMarket,
  loadingView, errorView, setView, setCrumb, state, saveWatchlist, paginate,
} from "../core.js";

const view = {
  search: "", exchange: "", market_type: "", regime: "", eligible: false,
  sort: "quote_volume", order: "desc", page: 1, page_size: 25, in_universe: true,
};

const COLUMNS = [
  ["market", "Thị trường", false],
  ["price", "Giá", true],
  ["quote_volume", "Khối lượng 24h", true],
  ["spread", "Chênh lệch", true],
  ["rv", "RV", true],
  ["rv_ann", "Biến động năm hóa", true],
  ["forecast_vol", "Biến động dự báo", true],
  ["es_99", "ES 99%", true],
  ["var_99", "VaR 99%", true],
  ["regime", "Trạng thái", false],
];

function tableHead() {
  return COLUMNS.map(([key, label, sortable]) => {
    if (!sortable) return `<th>${label}</th>`;
    const active = view.sort === key;
    const arrow = active ? (view.order === "desc" ? "↓" : "↑") : "";
    return `<th class="sortable" data-sort="${key}">${label} <span class="dim">${arrow}</span></th>`;
  }).join("");
}

function rowHtml(m) {
  const starred = state.watchlist.has(`${m.exchange}:${m.symbol}`);
  return `<tr>
    <td>
      <button class="star" data-star="${esc(m.exchange)}:${esc(m.symbol)}" title="Danh sách theo dõi"
        style="background:none;border:0;color:${starred ? "var(--amber)" : "var(--muted-2)"};cursor:pointer;padding:0 4px 0 0">${starred ? "★" : "☆"}</button>
      ${linkMarket(m.exchange, m.symbol, m.symbol)}
      <div class="tiny dim">${esc(m.exchange)} · ${esc(m.market_type)}${m.contract_type ? " · " + esc(m.contract_type) : ""}</div>
    </td>
    <td class="num mono">${fmt.price(m.price)}</td>
    <td class="num mono">${fmt.num(m.quote_volume_24h)}</td>
    <td class="num mono">${fmt.bps(m.spread_bps)}</td>
    <td class="num mono">${m.rv == null ? "—" : fmt.num(m.rv)}</td>
    <td class="num mono">${m.rv_ann_vol == null ? "—" : fmt.pct(m.rv_ann_vol)}</td>
    <td class="num mono">${m.forecast_vol == null ? "—" : fmt.pct(m.forecast_vol)}</td>
    <td class="num mono">${m.es_99 == null ? "—" : fmt.num(m.es_99) + "%"}</td>
    <td class="num mono">${m.var_99 == null ? "—" : fmt.num(m.var_99) + "%"}</td>
    <td>${regimeBadge(m.regime)}</td>
  </tr>`;
}

export async function renderScreener() {
  loadingView("Đang tải danh sách thị trường…");
  let d;
  try {
    const qs = new URLSearchParams({
      page: String(view.page), page_size: String(view.page_size),
      sort: view.sort === "market" ? "symbol" : view.sort, order: view.order,
      in_universe: String(view.in_universe),
    });
    if (view.search) qs.set("search", view.search);
    if (view.exchange) qs.set("exchange", view.exchange);
    if (view.market_type) qs.set("market_type", view.market_type);
    if (view.regime) qs.set("regime", view.regime);
    if (view.eligible) qs.set("eligible_only", "true");
    d = await api(`/api/v1/markets?${qs}`);
  } catch (err) {
    errorView(err, renderScreener);
    return;
  }

  const items = d.items || [];
  const total = d.total ?? items.length;
  const exchanges = d.exchanges || [...new Set(items.map((i) => i.exchange))];
  setCrumb("Bộ lọc tài sản", `${total.toLocaleString("vi-VN")} thị trường`);

  setView(`
    <div class="page-head">
      <div><h1>Bộ lọc tài sản</h1>
        <p>Toàn bộ công cụ đang theo dõi cùng biến động thực tế, biến động dự báo và giá trị rủi ro mới nhất. Bộ lọc được thực thi qua API, không phải ảnh chụp trước.</p></div>
    </div>

    <div class="filters">
      <input class="input" id="f-search" placeholder="Tìm theo mã hoặc tài sản cơ sở…" value="${esc(view.search)}" />
      <select class="input" id="f-exchange">
        <option value="">Tất cả sàn</option>
        ${(exchanges || []).map((e) => `<option value="${esc(e)}" ${view.exchange === e ? "selected" : ""}>${esc(e)}</option>`).join("")}
      </select>
      <select class="input" id="f-type">
        ${["", "spot", "swap", "futures"].map((t) => `<option value="${t}" ${view.market_type === t ? "selected" : ""}>${t || "Tất cả loại"}</option>`).join("")}
      </select>
      <select class="input" id="f-regime">
        ${[["", "Tất cả trạng thái"], ["low", "Thấp"], ["normal", "Bình thường"], ["high", "Cao"], ["extreme", "Cực đoan"]].map(([v, l]) => `<option value="${v}" ${view.regime === v ? "selected" : ""}>${l}</option>`).join("")}
      </select>
      <label class="small check"><input type="checkbox" id="f-eligible" ${view.eligible ? "checked" : ""}/> Chỉ đã mô hình hóa</label>
      <label class="small check"><input type="checkbox" id="f-universe" ${view.in_universe ? "checked" : ""}/> Chỉ trong vũ trụ</label>
      <span class="spacer"></span>
      <span class="small dim">${items.length} trên trang này</span>
    </div>

    <div style="margin-top:10px; display:flex; gap:8px; flex-wrap:wrap">
      <button class="btn sm" data-quick="vol">Biến động cao</button>
      <button class="btn sm" data-quick="tail">Rủi ro đuôi cao</button>
      <button class="btn sm" data-quick="missing">Thiếu dữ liệu</button>
      <button class="btn sm" data-quick="eligible">Đủ điều kiện mô hình</button>
      <button class="btn sm" data-quick="clear">Xóa lọc nhanh</button>
    </div>

    <div class="table-wrap" style="margin-top:14px">
      <table class="data">
        <thead><tr>${tableHead()}<th>Dữ liệu</th></tr></thead>
        <tbody>${items.map((m) => rowHtml(m).replace("</tr>", `<td>${freshnessBadge(m.freshness)}</td></tr>`)).join("")
          || `<tr><td colspan="11"><div class="table-empty">Không có thị trường nào khớp bộ lọc.</div></td></tr>`}</tbody>
      </table>
    </div>
    ${paginate(total, view.page, view.page_size)}

    <section class="section">
      <div class="section-head"><h2>Ghi chú cột</h2></div>
      <div class="grid grid-3">
        <div class="card tight"><div class="small"><strong>RV</strong> — phương sai thực tế (%²/ngày) từ lợi suất 4 giờ. <strong>Biến động năm hóa</strong> là căn bậc hai năm hóa của RV.</div></div>
        <div class="card tight"><div class="small"><strong>Biến động dự báo</strong> — biến động năm hóa dự báo 1 ngày tới, trung vị của 6 mô hình tại gốc dự báo đó.</div></div>
        <div class="card tight"><div class="small"><strong>VaR</strong> — tổn thất dương (%) từ mô hình sẵn có ưu tiên (GARCH-EVT → GARCH-t → lịch sử).</div></div>
      </div>
    </section>
  `);

  const reload = () => renderScreener();
  const search = document.getElementById("f-search");
  let t;
  search.addEventListener("input", (e) => {
    clearTimeout(t);
    t = setTimeout(() => { view.search = e.target.value.trim(); view.page = 1; reload(); }, 350);
  });
  document.getElementById("f-exchange").addEventListener("change", (e) => { view.exchange = e.target.value; view.page = 1; reload(); });
  document.getElementById("f-type").addEventListener("change", (e) => { view.market_type = e.target.value; view.page = 1; reload(); });
  document.getElementById("f-regime").addEventListener("change", (e) => { view.regime = e.target.value; view.page = 1; reload(); });
  document.getElementById("f-eligible").addEventListener("change", (e) => { view.eligible = e.target.checked; view.page = 1; reload(); });
  document.getElementById("f-universe").addEventListener("change", (e) => { view.in_universe = e.target.checked; view.page = 1; reload(); });

  document.querySelectorAll("[data-quick]").forEach((b) => {
    b.addEventListener("click", () => {
      const q = b.dataset.quick;
      if (q === "vol") { view.sort = "forecast_vol"; view.order = "desc"; view.eligible = true; }
      if (q === "tail") { view.sort = "es_99"; view.order = "desc"; view.eligible = true; }
      if (q === "missing") { view.regime = "insufficient_data"; }
      if (q === "eligible") { view.eligible = true; view.in_universe = true; }
      if (q === "clear") { view.search = ""; view.exchange = ""; view.market_type = ""; view.regime = ""; view.eligible = false; view.sort = "quote_volume"; }
      view.page = 1; reload();
    });
  });

  document.querySelectorAll("th[data-sort]").forEach((th) => {
    th.addEventListener("click", () => {
      const key = th.dataset.sort;
      if (view.sort === key) view.order = view.order === "desc" ? "asc" : "desc";
      else { view.sort = key; view.order = "desc"; }
      reload();
    });
  });
  document.querySelectorAll("[data-page]").forEach((btn) => {
    btn.addEventListener("click", () => { view.page = Number(btn.dataset.page); reload(); });
  });
  document.querySelectorAll("[data-star]").forEach((btn) => {
    btn.addEventListener("click", (ev) => {
      ev.stopPropagation();
      const key = btn.dataset.star;
      if (state.watchlist.has(key)) state.watchlist.delete(key); else state.watchlist.add(key);
      saveWatchlist();
      btn.textContent = state.watchlist.has(key) ? "★" : "☆";
      btn.style.color = state.watchlist.has(key) ? "var(--amber)" : "var(--muted-2)";
    });
  });
  return null;
}

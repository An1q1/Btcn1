// Chi tiết tài sản: nến giá, biến động thực tế vs dự báo, so sánh mô hình, rủi ro đuôi.
import {
  api, fmt, esc, badge, regimeBadge, freshnessBadge, loadingView, errorView,
  setView, setCrumb, emptyView, state,
} from "../core.js";
import { candlestick, chart } from "../charts.js";

const MODEL_LABELS = {
  naive: "Naive RV",
  har_rv: "HAR-RV (OLS)",
  garch_normal: "GARCH(1,1) Chuẩn",
  garch_t: "GARCH(1,1) Student-t",
  xgb_har: "XGBoost-HAR",
  xgb_extended: "XGBoost mở rộng",
  historical: "Mô phỏng lịch sử",
  garch_evt: "GARCH-EVT (POT/GPD)",
};

function pctOrDash(v, digits = 2) {
  return v == null ? "—" : fmt.pct(v, digits);
}

function coverageBadge(cov) {
  if (!cov || !cov.n_obs) return badge("unknown", "chưa có mẫu");
  const p = cov.kupiec_pvalue;
  if (p == null) return badge("unknown", "không có");
  return p < 0.05 ? badge("warning", `bác bỏ p=${p.toFixed(3).replace(".", ",")}`) : badge("ok", `đạt p=${p.toFixed(3).replace(".", ",")}`);
}

export async function renderAsset(params = []) {
  const exchange = params[0] || state.market.exchange;
  const symbol = params[1] || state.market.symbol;
  state.market = { exchange, symbol };
  setCrumb("Chi tiết tài sản", `${exchange} · ${symbol}`);
  loadingView(`Đang tải ${exchange}:${symbol}…`);

  let detail, series, comparison, risk;
  try {
    detail = await api(`/api/v1/markets/${encodeURIComponent(exchange)}/${encodeURIComponent(symbol)}`);
  } catch (err) {
    errorView(err, () => renderAsset(params));
    return;
  }
  const horizon = Number(localStorage.getItem("cri_horizon") || 1);
  const confidence = Number(localStorage.getItem("cri_confidence") || 0.99);
  const [seriesRes, compRes, riskRes] = await Promise.allSettled([
    api(`/api/v1/markets/${encodeURIComponent(exchange)}/${encodeURIComponent(symbol)}/series?limit=500`),
    api(`/api/v1/markets/${encodeURIComponent(exchange)}/${encodeURIComponent(symbol)}/comparison?horizon=${horizon}`),
    api(`/api/v1/markets/${encodeURIComponent(exchange)}/${encodeURIComponent(symbol)}/risk?confidence=${confidence}`),
  ]);
  series = seriesRes.status === "fulfilled" ? seriesRes.value : null;
  comparison = compRes.status === "fulfilled" ? compRes.value : null;
  risk = riskRes.status === "fulfilled" ? riskRes.value : null;

  const m = detail.market;
  const meta = detail.meta || {};
  const eligibility = detail.eligibility || {};

  const latest = comparison?.latest || {};
  const consensus = comparison?.consensus || {};
  const modelRows = Object.entries(latest).map(([name, row]) => `
    <tr>
      <td>${esc(MODEL_LABELS[name] || name)}<div class="tiny dim mono">${esc(name)}</div></td>
      <td class="num mono">${fmt.num(row.predicted_rv)}</td>
      <td class="num mono">${pctOrDash(row.predicted_vol_annualized)}</td>
      <td class="num mono">${row.actual_rv == null ? "đang chờ" : fmt.num(row.actual_rv)}</td>
      <td class="num mono">${esc((row.bar_date || "").slice(0, 10))}</td>
    </tr>`).join("");

  const tests = risk?.tests || {};
  const testRows = Object.entries(tests).map(([name, t]) => {
    const c = t.coverage || {};
    return `<tr>
      <td>${esc(MODEL_LABELS[name] || name)}</td>
      <td class="num mono">${c.n_obs ?? "—"}</td>
      <td class="num mono">${c.n_breaches ?? "—"}</td>
      <td class="num mono">${c.expected_breaches == null ? "—" : fmt.num(c.expected_breaches, 1)}</td>
      <td class="num mono">${c.breach_rate == null ? "—" : fmt.pct(c.breach_rate, 2)}</td>
      <td>${coverageBadge(c)}</td>
      <td class="num mono">${c.christoffersen_cc_pvalue == null ? "—" : fmt.num(c.christoffersen_cc_pvalue, 3)}</td>
    </tr>`;
  }).join("") || `<tr><td colspan="7"><div class="table-empty">Chưa có lịch sử VaR/ES cho thị trường này.</div></td></tr>`;

  const diag = risk?.diagnostics || {};
  const sens = diag.evt_sensitivity || [];
  const sensRows = sens.map((r) => `<tr>
      <td class="num mono">${r.quantile ?? "—"}</td>
      <td class="num mono">${r.threshold == null ? "—" : fmt.num(r.threshold, 3)}</td>
      <td class="num mono">${r.n_exceed == null ? "—" : r.n_exceed}</td>
      <td class="num mono">${r.xi == null ? "—" : fmt.num(r.xi, 3)}</td>
      <td class="num mono">${r.var_99 == null ? "—" : fmt.num(r.var_99)}</td>
      <td class="num mono">${r.es_99 == null ? "—" : fmt.num(r.es_99)}</td>
    </tr>`).join("");

  setView(`
    <div class="page-head">
      <div>
        <h1>${esc(m.base_asset)} / ${esc(m.quote_asset)} <span class="dim small mono">${esc(m.exchange)}</span></h1>
        <p>${esc(m.canonical_symbol)} · ${esc(m.market_type)}${m.contract_type ? " · " + esc(m.contract_type) : ""} · ${esc(meta.native_symbol || m.symbol)}</p>
        <p class="tiny dim" style="margin-top:6px">Giá trị rủi ro (VaR) 99% — mức tổn thất ước lượng trong 1 ngày: ví dụ 8,2% nghĩa là trong điều kiện mô hình phù hợp, tổn thất thực tế được kỳ vọng vượt ngưỡng này khoảng 1% số ngày. Đây là ước lượng thống kê, không phải giới hạn tổn thất tối đa.</p>
      </div>
      <div class="spacer"></div>
      <div class="pill-row">
        ${regimeBadge(m.regime)} ${freshnessBadge(m.freshness)}
        ${m.model_eligible ? badge("ok", "đủ điều kiện mô hình") : badge("warning", "chưa mô hình hóa")}
      </div>
    </div>

    <div class="grid grid-4">
      <div class="stat-card"><div class="stat-label">Giá</div>
        <div class="stat-value">${fmt.price(m.price)}</div>
        <div class="stat-sub">${m.price_change_24h_pct == null ? "không có dữ liệu 24 giờ" : fmt.signedPct(m.price_change_24h_pct) + " · 24 giờ"}</div></div>
      <div class="stat-card"><div class="stat-label">Phương sai thực tế</div>
        <div class="stat-value small">${m.rv == null ? "—" : fmt.num(m.rv)} <span class="small dim">%²/ngày</span></div>
        <div class="stat-sub">năm hóa ${pctOrDash(m.rv_ann_vol)}</div>
        <div class="tiny dim">Biến động thực tế đo được từ lợi suất trong ngày</div></div>
      <div class="stat-card"><div class="stat-label">Biến động dự báo (${horizon} ngày)</div>
        <div class="stat-value small">${consensus.predicted_vol_annualized == null ? "—" : fmt.pct(consensus.predicted_vol_annualized)}</div>
        <div class="stat-sub">${consensus.models?.length || 0} mô hình · phân tán ${consensus.dispersion == null ? "—" : fmt.num(consensus.dispersion, 3)}</div>
        <div class="tiny dim">Biến động dự báo = căn năm hóa của RV dự báo</div></div>
      <div class="stat-card"><div class="stat-label">Giá trị rủi ro / Tổn thất kỳ vọng ${Math.round(confidence * 1000) / 10}%</div>
        <div class="stat-value small">${m.var_99 == null ? "—" : fmt.num(m.var_99) + "%"}</div>
        <div class="stat-sub">ES ${m.es_99 == null ? "—" : fmt.num(m.es_99) + "%"} · ${esc(m.var_method || "")}</div>
        <div class="tiny dim">Mức tổn thất kỳ vọng khi vượt ngưỡng VaR</div></div>
    </div>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Giá</h3><span class="spacer"></span><span class="hint">${series ? series.ohlcv.length : 0} nến · ${esc(series?.timeframe || "")}</span></div>
        <div class="chart" id="chart-price" style="height:320px"></div>
      </section>
      <section class="card">
        <div class="card-head"><h3>Biến động thực tế vs dự báo</h3><span class="spacer"></span>
          <span class="hint">%²/ngày · chân trời ${horizon} ngày</span></div>
        <div class="chart" id="chart-rv" style="height:320px"></div>
        <p class="tiny dim" style="margin-top:8px">Đường vàng: HAR-RV dự báo; vùng xanh: RV thực tế; chấm xanh: mục tiêu thực tế. Nếu VaR/ES dao động mạnh giữa các ngưỡng kế nhau, hãy coi ước lượng điểm là chỉ báo tham khảo.</p>
      </section>
    </div>

    <section class="section">
      <div class="section-head"><h2>So sánh mô hình — gốc gần nhất</h2><span class="spacer"></span>
        <select class="input" id="sel-horizon" style="max-width:150px">
          ${[1, 7, 30].map((h) => `<option value="${h}" ${h === horizon ? "selected" : ""}>Chân trời ${h} ngày</option>`).join("")}
        </select>
      </div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Mô hình</th><th class="right">RV dự báo</th><th class="right">Biến động dự báo (năm hóa)</th><th class="right">RV thực tế</th><th>Gốc</th></tr></thead>
          <tbody>${modelRows || `<tr><td colspan="5"><div class="table-empty">Chưa có dự báo cho thị trường này — kiểm tra điều kiện (${esc(eligibility.models ? Object.keys(eligibility.models).filter((k) => !eligibility.models[k]).join(", ") : "không có")}).</div></td></tr>`}</tbody>
        </table>
      </div>
    </section>

    <section class="section">
      <div class="section-head"><h2>Rủi ro đuôi</h2><span class="spacer"></span>
        <select class="input" id="sel-conf" style="max-width:150px">
          ${[0.95, 0.975, 0.99].map((c) => `<option value="${c}" ${c === confidence ? "selected" : ""}>Độ tin cậy ${(c * 100).toLocaleString("vi-VN")}%</option>`).join("")}
        </select>
      </div>
      <div class="grid grid-2">
        <div class="card"><div class="card-head"><h3>VaR / ES so với tổn thất thực tế</h3></div>
          <div class="chart" id="chart-risk" style="height:260px"></div>
          <p class="tiny dim" style="margin-top:8px">Cột xanh: tổn thất thực tế hằng ngày; đường đỏ/vàng: VaR/ES. Chấm đỏ = ngày vượt ngưỡng (breach).</p></div>
        <div class="card"><div class="card-head"><h3>Độ bao phủ & tính độc lập</h3></div>
          <div class="table-wrap"><table class="data">
            <thead><tr><th>Phương pháp</th><th class="right">Số quan sát</th><th class="right">Số lần vượt</th><th class="right">Kỳ vọng</th><th class="right">Tỷ lệ</th><th>Kupiec</th><th class="right">Christoffersen p</th></tr></thead>
            <tbody>${testRows}</tbody>
          </table></div>
          <p class="tiny dim" style="margin:8px 10px 10px">Kiểm định không bị bác bỏ không chứng minh mô hình tốt: hãy đọc n, số lần vượt và p-value cùng nhau. Trong điều kiện mô hình phù hợp, tỷ lệ vượt kỳ vọng khoảng 1% số ngày ở VaR 99%.</p>
        </div>
      </div>
      ${sensRows ? `<div class="card" style="margin-top:14px">
        <div class="card-head"><h3>Độ nhạy ngưỡng EVT</h3><span class="hint">phần dư chuẩn hóa · bộ lọc GARCH</span></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th class="right">Phân vị</th><th class="right">Ngưỡng u</th><th class="right">Số vượt</th><th class="right">ξ</th><th class="right">VaR 99</th><th class="right">ES 99</th></tr></thead>
          <tbody>${sensRows}</tbody></table></div>
        <p class="tiny dim" style="margin:8px 10px 10px">Nếu VaR dao động mạnh giữa các ngưỡng kề nhau, hãy coi ước lượng điểm chỉ là tham khảo.</p>
      </div>` : ""}
    </section>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Chất lượng dữ liệu</h3></div>
        <div class="kv"><span>Lịch sử</span><span class="mono">${m.history_days} ngày</span></div>
        <div class="kv"><span>Độ đầy đủ</span><span class="mono">${pctOrDash(m.data_completeness, 1)}</span></div>
        <div class="kv"><span>Số nến đã lưu</span><span class="mono">${fmt.num(eligibility.bars)}</span></div>
        <div class="kv"><span>Khối lượng 24h</span><span class="mono">${fmt.num(m.quote_volume_24h)}</span></div>
        <div class="kv"><span>Chênh lệch giá mua-bán</span><span class="mono">${fmt.bps(m.spread_bps)}</span></div>
        <div class="kv"><span>Tỷ lệ tài trợ</span><span class="mono">${m.funding_rate == null ? "không có" : fmt.num(m.funding_rate, 6)}</span></div>
        <div class="kv"><span>Khối lượng hợp đồng đang mở</span><span class="mono">${m.open_interest == null ? "không có" : fmt.num(m.open_interest)}</span></div>
        <div class="kv"><span>Cập nhật lần cuối</span><span class="mono">${m.last_update ? fmt.ago(m.last_update) : "—"}</span></div>
        <div class="kv"><span>Độ mới dữ liệu</span><span class="mono">${esc(m.freshness || "không rõ")}</span></div>
      </section>
      <section class="card">
        <div class="card-head"><h3>Điều kiện mô hình hóa</h3></div>
        ${m.model_eligible
          ? `<p class="small">Thị trường này đạt yêu cầu lịch sử, độ đầy đủ và số quan sát tối thiểu, nên cả 6 mô hình dự báo và 4 phương pháp VaR/ES đều được chạy.</p>`
          : `<p class="small">Chưa mô hình hóa: ${esc((m.ineligible_reasons || []).join(", ") || "xem chi tiết điều kiện")}.</p>`}
        <pre class="small mono" style="white-space:pre-wrap;margin-top:8px;color:var(--muted)">${esc(JSON.stringify(eligibility, null, 1).slice(0, 900))}</pre>
      </section>
    </div>
  `);

  if (series) candlestick(document.getElementById("chart-price"), series.ohlcv, { height: 320 });

  const feats = series?.features || [];
  const hist = comparison?.history || {};
  const model = comparison?.model || "har_rv";
  const pred = (hist[model] || []).map((r) => ({ x: r.date, y: r.predicted_rv }));
  const actual = (hist[model] || []).filter((r) => r.actual_rv != null).map((r) => ({ x: r.date, y: r.actual_rv }));
  chart(document.getElementById("chart-rv"), {
    height: 320,
    series: [
      { name: "RV thực tế", type: "area", color: "#5da2ff", points: feats.map((f) => ({ x: f.date, y: f.rv })), fillOpacity: 0.12 },
      { name: `Dự báo (${MODEL_LABELS[model] || model})`, type: "line", color: "#f2b544", points: pred, width: 1.8 },
      { name: "Mục tiêu thực tế", type: "scatter", color: "#35d399", points: actual, radius: 2.4 },
    ],
    yFormat: (v) => `${fmt.num(v)}`,
    ariaLabel: "biến động thực tế so với dự báo",
  });

  const rs = risk?.series || {};
  const seriesName = ["garch_evt", "garch_t", "garch_normal", "historical"].find((k) => (rs[k] || []).length) || "historical";
  const points = rs[seriesName] || [];
  chart(document.getElementById("chart-risk"), {
    height: 260,
    series: [
      { name: "VaR", type: "line", color: "#ff6273", points: points.map((p) => ({ x: p.date, y: p.var_pct })) },
      { name: "ES", type: "line", color: "#f2b544", points: points.map((p) => ({ x: p.date, y: p.es_pct })) },
      { name: "Tổn thất thực tế", type: "bar", color: "#5da2ff", points: points.map((p) => ({ x: p.date, y: p.actual_loss_pct })), opacity: 0.55 },
    ],
    markers: points.filter((p) => p.breach).map((p) => ({ x: p.date, y: p.actual_loss_pct, label: "vượt ngưỡng" })),
    yFormat: (v) => `${fmt.num(v, 1)}%`,
    ariaLabel: "VaR ES và tổn thất thực tế",
  });

  document.getElementById("sel-horizon").addEventListener("change", (e) => {
    localStorage.setItem("cri_horizon", e.target.value);
    renderAsset(params);
  });
  document.getElementById("sel-conf").addEventListener("change", (e) => {
    localStorage.setItem("cri_confidence", e.target.value);
    renderAsset(params);
  });
  return null;
}

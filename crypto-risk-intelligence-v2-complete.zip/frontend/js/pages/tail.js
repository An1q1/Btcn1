// Trung tâm rủi ro cực đoan: ước lượng VaR/ES, kiểm định độ bao phủ và chẩn đoán vượt ngưỡng.
import {
  api, fmt, esc, badge, regimeBadge, loadingView, errorView, setView, setCrumb, emptyView,
} from "../core.js";

const CONFIDENCES = [0.95, 0.975, 0.99];

function pval(v) {
  if (v == null || Number.isNaN(Number(v))) return "—";
  return Number(v) < 0.001 ? "< 0,001" : Number(v).toFixed(3).replace(".", ",");
}

export async function renderTail() {
  const confidence = Number(localStorage.getItem("cri_confidence") || 0.99);
  loadingView("Đang tải ước lượng rủi ro đuôi…");

  let overview, table, backtests;
  try {
    [overview, table, backtests] = await Promise.all([
      api("/api/v1/risk/overview"),
      api(`/api/v1/risk/var-es?confidence=${confidence}`),
      api(`/api/v1/risk/backtests?confidence=${confidence}`),
    ]);
  } catch (err) {
    errorView(err, renderTail);
    return;
  }
  setCrumb("Trung tâm rủi ro cực đoan", `độ tin cậy ${Math.round(confidence * 1000) / 10}%`);

  const conf = overview.confidences?.[String(confidence)] || overview.confidences?.[confidence] || [];
  const overviewRows = conf.map((r) => {
    const breachRatio = r.expected_breaches ? r.n_breaches / r.expected_breaches : null;
    return `<tr>
      <td>${esc(r.label || r.model)}</td>
      <td class="num mono">${fmt.num(r.n_obs, 0)}</td>
      <td class="num mono">${r.n_breaches}</td>
      <td class="num mono">${r.expected_breaches == null ? "—" : fmt.num(r.expected_breaches, 1)}</td>
      <td class="num mono">${r.breach_rate == null ? "—" : fmt.pct(r.breach_rate, 2)}</td>
      <td class="num mono">${breachRatio == null ? "—" : fmt.num(breachRatio, 2) + "×"}</td>
      <td class="num mono">${pval(r.kupiec_pvalue)}</td>
      <td class="num mono">${pval(r.christoffersen_cc_pvalue)}</td>
      <td class="num mono">${r.es_ratio == null ? "—" : fmt.num(r.es_ratio, 3)}</td>
      <td class="num mono">${r.quantile_loss == null ? "—" : fmt.num(r.quantile_loss, 4)}</td>
    </tr>`;
  }).join("");

  const items = (table.items || []).slice().sort((a, b) => (b.es_99 || 0) - (a.es_99 || 0));
  const marketRows = items.map((m) => `
    <tr class="clickable" onclick="location.hash='#/asset/${encodeURIComponent(m.exchange)}/${encodeURIComponent(m.symbol)}'">
      <td><span class="mono">${esc(m.symbol)}</span><div class="tiny dim">${esc(m.exchange)} · ${esc(m.base_asset || "")}</div></td>
      <td class="num mono">${fmt.num(m.rv)}</td>
      <td>${regimeBadge(m.regime)}</td>
      <td class="num mono">${fmt.num(m.var_99)}</td>
      <td class="num mono">${fmt.num(m.es_99)}</td>
      <td class="num mono">${m.var_evt == null ? "—" : fmt.num(m.var_evt)}</td>
      <td class="num mono">${m.var_hist == null ? "—" : fmt.num(m.var_hist)}</td>
      <td class="num mono">${m.xi == null ? "—" : fmt.num(m.xi, 3)}</td>
      <td class="num mono">${m.n_exceedances == null ? "—" : m.n_exceedances}</td>
      <td class="mono">${esc(m.asof_date || "")}</td>
    </tr>`).join("");

  const agg = backtests.aggregate || [];
  const detail = (backtests.by_market || []).slice(0, 40);
  const notes = backtests.notes || [];

  setView(`
    <div class="page-head">
      <div><h1>Trung tâm rủi ro cực đoan</h1>
        <p>Giá trị rủi ro (VaR) và mức tổn thất kỳ vọng (ES) 1 ngày, ước lượng cuốn chiếu và chấm điểm trên tổn thất thực tế.</p></div>
      <div class="spacer"></div>
      <div class="tabs">${CONFIDENCES.map((c) => `
        <button class="btn sm ${c === confidence ? "active" : ""}" data-conf="${c}">${(c * 100).toLocaleString("vi-VN")}%</button>`).join("")}</div>
    </div>

    <div class="notice" style="margin-bottom:16px">
      <strong>Quy ước dấu.</strong> ${esc("VaR và ES là phần trăm tổn thất dương; tổn thất thực tế = −lợi suất, nên ngày có lãi sẽ cho tổn thất âm.")}
      Ngưỡng GARCH-EVT được chọn riêng cho từng gốc trên phần dư chuẩn hóa của GARCH; ES bị ẩn khi hệ số hình dạng ξ ≥ 1 (không có kỳ vọng hữu hạn).
    </div>

    <section class="card">
      <div class="card-head"><h3>Tổng hợp kiểm định độ bao phủ — toàn thị trường</h3><span class="spacer"></span><span class="hint">${esc(overview.run_id || "")}</span></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr>
            <th>Phương pháp</th><th class="right">Số quan sát</th><th class="right">Số lần vượt</th><th class="right">Kỳ vọng</th>
            <th class="right">Tỷ lệ</th><th class="right">So với kỳ vọng</th><th class="right">Kupiec p</th>
            <th class="right">Christoffersen p</th><th class="right">Tỷ lệ ES</th><th class="right">Tổn thất phân vị</th>
          </tr></thead>
          <tbody>${overviewRows || `<tr><td colspan="10"><div class="table-empty">Chưa có ước lượng VaR/ES nào được lưu.</div></td></tr>`}</tbody>
        </table>
      </div>
      <p class="tiny dim" style="margin:8px 10px 10px">
        Kiểm định Kupiec kiểm tra độ bao phủ vô điều kiện; Christoffersen cộng thêm tính độc lập. Với vài trăm quan sát mỗi thị trường, năng lực bác bỏ còn hạn chế,
        và việc “đạt” không chứng minh mô hình đủ tốt — hãy so sánh số lần vượt, tỷ lệ ES và tổn thất phân vị giữa các phương pháp. Tỷ lệ thấp hơn nhiều so với mức danh nghĩa nghĩa là phương pháp đang quá bảo thủ — nhìn có vẻ an toàn hơn nhưng kém hiệu quả về vốn — chứ không phải tốt hơn.
      </p>
    </section>

    <section class="section">
      <div class="section-head"><h2>VaR / ES liên thị trường</h2><span class="hint">sắp xếp theo mức tổn thất kỳ vọng · ${items.length} thị trường</span></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr>
            <th>Thị trường</th><th class="right">RV</th><th>Trạng thái</th><th class="right">VaR ${Math.round(confidence * 100)}%</th>
            <th class="right">ES ${Math.round(confidence * 100)}%</th><th class="right">VaR EVT</th><th class="right">VaR lịch sử</th>
            <th class="right">ξ (GPD)</th><th class="right">Số vượt ngưỡng</th><th>Tính đến</th>
          </tr></thead>
          <tbody>${marketRows || `<tr><td colspan="10"><div class="table-empty">Không có ước lượng cho mức tin cậy này.</div></td></tr>`}</tbody>
        </table>
      </div>
      <p class="tiny dim" style="margin-top:8px">VaR 99% — mức tổn thất ước lượng trong 1 ngày: ví dụ 8,2% nghĩa là trong điều kiện mô hình phù hợp, tổn thất thực tế được kỳ vọng vượt ngưỡng này khoảng 1% số ngày. ES là mức lỗ trung bình trong nhóm ngày đã vượt VaR. Đây là ước lượng thống kê, không phải giới hạn tổn thất tối đa.</p>
    </section>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Chỉ số độ bao phủ tổng hợp</h3></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th>Mô hình</th><th>Chỉ số</th><th class="right">Giá trị</th><th class="right">Số quan sát</th></tr></thead>
          <tbody>${agg.map((r) => `<tr><td>${esc(r.model)}</td><td class="small">${esc(r.metric)}</td>
            <td class="num mono">${fmt.num(r.value, 4)}</td><td class="num mono">${r.n_obs ?? "—"}</td></tr>`).join("")
            || `<tr><td colspan="4"><div class="table-empty">Chưa có dòng backtest nào.</div></td></tr>`}</tbody>
        </table></div>
        ${notes.length ? `<ul class="small muted" style="margin:10px 14px 12px;padding-left:16px">${notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>` : ""}
      </section>
      <section class="card">
        <div class="card-head"><h3>Chi tiết theo thị trường</h3><span class="hint">40 dòng đầu</span></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th>Thị trường</th><th>Mô hình</th><th>Chỉ số</th><th class="right">Giá trị</th><th class="right">p</th><th class="right">Số quan sát</th></tr></thead>
          <tbody>${detail.map((r) => `<tr>
            <td class="mono small">${esc(r.symbol || r.scope)}</td><td class="small">${esc(r.model)}</td>
            <td class="small">${esc(r.metric)}</td>
            <td class="num mono">${fmt.num(r.value, 4)}</td>
            <td class="num mono">${pval(r.p_value)}</td>
            <td class="num mono">${r.n_obs ?? "—"}</td></tr>`).join("")
            || `<tr><td colspan="6"><div class="table-empty">Chưa có dòng chi tiết.</div></td></tr>`}</tbody>
        </table></div>
      </section>
    </div>
  `);

  document.querySelectorAll("[data-conf]").forEach((btn) => {
    btn.addEventListener("click", () => {
      localStorage.setItem("cri_confidence", btn.dataset.conf);
      renderTail();
    });
  });
  return null;
}

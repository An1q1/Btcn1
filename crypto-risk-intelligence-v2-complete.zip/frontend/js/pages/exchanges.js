// Giám sát sàn giao dịch: trạng thái adapter, năng lực công bố, sức khỏe luồng và sự kiện chất lượng dữ liệu.
import {
  api, fmt, esc, badge, loadingView, errorView, setView, setCrumb, emptyView,
  state, toast,
} from "../core.js";

const CAPS = ["ohlcv", "funding", "open_interest", "mark_price", "liquidation", "orderbook", "trades", "websocket"];
const CAP_LABELS = {
  ohlcv: "Nến OHLCV", funding: "Tỷ lệ tài trợ", open_interest: "Hợp đồng mở", mark_price: "Giá đánh dấu",
  liquidation: "Thanh lý", orderbook: "Sổ lệnh", trades: "Giao dịch", websocket: "WebSocket"
};

function capChip(name, value) {
  const on = value === true;
  const label = CAP_LABELS[name] || name;
  return `<span class="badge ${on ? "ok" : "unknown"}" title="${esc(name)}">${esc(label)} ${on ? "✓" : "—"}</span>`;
}

export async function renderExchanges() {
  loadingView("Đang kiểm tra trạng thái các sàn…");
  const showResolved = localStorage.getItem("cri_alerts_resolved") === "1";
  let ex, dq, status, alerts;
  try {
    [ex, dq, status, alerts] = await Promise.all([
      api("/api/v1/exchanges"),
      api("/api/v1/data-quality?limit=60"),
      api("/api/v1/system/status"),
      api(`/api/v1/alerts?limit=200${showResolved ? "" : "&active_only=true"}`),
    ]);
  } catch (err) {
    errorView(err, renderExchanges);
    return;
  }
  setCrumb("Giám sát sàn giao dịch", `${ex.connected ?? 0} đang kết nối · ${(ex.blocked || []).length} bị chặn`);

  const cards = (ex.exchanges || []).map((e) => {
    const caps = e.capabilities || {};
    const statusLabel = { ok: "hoạt động", degraded: "suy giảm", blocked: "bị chặn", error: "lỗi", unknown: "không rõ" }[e.status] || e.status;
    return `<div class="card">
      <div class="card-head">
        <h3>${esc(e.name)}</h3><span class="spacer"></span>
        ${badge(e.status || "unknown", statusLabel)}
      </div>
      <div class="kv"><span>Mã sàn</span><span class="mono">${esc(e.code)}</span></div>
      <div class="kv"><span>Loại thị trường</span><span class="mono">${esc((e.market_types || []).join(", "))}</span></div>
      <div class="kv"><span>Số thị trường</span><span class="mono">${fmt.num(e.markets)} <span class="dim">(${e.universe_markets || 0} trong vũ trụ)</span></span></div>
      <div class="kv"><span>Độ trễ</span><span class="mono">${e.latency_ms == null ? "—" : fmt.num(e.latency_ms, 0) + " ms"}</span></div>
      <div class="kv"><span>Lần kiểm tra</span><span class="mono">${e.last_checked ? fmt.ago(e.last_checked) : "—"}</span></div>
      <div class="pill-row" style="margin-top:8px">${CAPS.map((c) => capChip(c, caps[c])).join("")}</div>
      ${e.status_detail ? `<p class="tiny dim" style="margin-top:8px">${esc(String(e.status_detail).slice(0, 220))}</p>` : ""}
      ${caps.notes ? `<p class="tiny dim" style="margin-top:6px">${esc(caps.notes)}</p>` : ""}
    </div>`;
  }).join("");

  const live = status.live || {};
  const dqRows = (dq.items || []).map((r) => `
    <tr>
      <td class="mono small">${esc(r.ts ? String(r.ts).slice(0, 19).replace("T", " ") : "")}</td>
      <td class="small">${esc(r.exchange)}</td>
      <td class="mono small">${esc(r.symbol || "—")}</td>
      <td>${badge(r.severity, r.severity === "warning" ? "cảnh báo" : r.severity === "critical" ? "nghiêm trọng" : r.severity)}</td>
      <td class="small">${esc(r.event_type)}</td>
      <td class="small dim">${esc(JSON.stringify(r.details || {}).slice(0, 120))}</td>
    </tr>`).join("");

  const summary = (dq.summary || []).map((s) => `<div class="list-row">
      <span>${badge(s.severity, s.severity)}</span><span class="small">${esc(s.event_type)}</span>
      <span class="spacer"></span><span class="mono small">${s.count}</span>
    </div>`).join("");

  const liveLabel = {
    okx_ws: "OKX WebSocket", binance_ws: "Binance WebSocket", rest: "REST polling"
  };

  setView(`
    <div class="page-head">
      <div><h1>Giám sát sàn giao dịch</h1>
        <p>Mỗi adapter công bố chính xác những gì sàn cung cấp. Sàn bị chặn được báo là bị chặn — không bao giờ lấp bằng dữ liệu giả.</p></div>
      <div class="spacer"></div>
      <span class="status-chip ${live.tracked_markets ? "live" : ""}">trực tiếp · ${live.tracked_markets || 0} thị trường</span>
    </div>

    ${(ex.blocked || []).length ? `<div class="notice" style="margin-bottom:14px">
      <strong>Bị chặn trong môi trường này:</strong> ${esc(ex.blocked.join(", "))}.
      Adapter vẫn được triển khai và đã kiểm thử; các trường phái sinh được hiển thị là “không có”, không phải 0.
    </div>` : ""}

    <div class="grid grid-3">${cards || emptyView("Chưa cấu hình adapter nào")}</div>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Trạng thái luồng trực tiếp</h3></div>
        <div class="kv"><span>Thị trường theo dõi</span><span class="mono">${live.tracked_markets ?? "—"}</span></div>
        <div class="kv"><span>Lần quét REST gần nhất</span><span class="mono">${live.last_rest_poll ? fmt.ago(live.last_rest_poll) : "—"}</span></div>
        <div class="kv"><span>Số snapshot đã ghi</span><span class="mono">${fmt.num(live.snapshots_written)}</span></div>
        <div class="kv"><span>OKX WebSocket</span><span class="mono">${live.exchanges?.okx_ws?.connected ? "đã kết nối" : "chưa kết nối"}</span></div>
        <div class="kv"><span>Binance WebSocket</span><span class="mono">${live.exchanges?.binance_ws?.connected ? "đã kết nối" : "chưa kết nối"}</span></div>
        <div class="hr"></div>
        <div class="kv"><span>Số tin nhắn</span><span class="mono small">${esc(JSON.stringify(live.message_counts || {}))}</span></div>
        <div class="kv"><span>Tin nhắn WS gần nhất</span><span class="mono small">${esc(JSON.stringify(live.last_ws_message || {}))}</span></div>
        ${(live.recent_errors || []).length ? `<p class="tiny dim" style="margin-top:8px">lỗi gần đây: ${esc(JSON.stringify(live.recent_errors).slice(0, 240))}</p>` : ""}
      </section>
      <section class="card">
        <div class="card-head"><h3>Sự kiện chất lượng dữ liệu</h3><span class="spacer"></span><span class="hint">${(dq.items || []).length} dòng</span></div>
        ${summary || `<div class="empty">Chưa ghi nhận sự kiện chất lượng dữ liệu.</div>`}
        <p class="tiny dim" style="margin-top:10px">Khoảng trống, trùng lặp, nến trễ, nến chưa đóng và lệch giá liên sàn được ingestion ghi lại và hiển thị ở đây thay vì âm thầm sửa.</p>
      </section>
    </div>

    <section class="section">
      <div class="section-head">
        <h2>Cảnh báo</h2>
        <span class="hint">${alerts.active} đang hoạt động · ${alerts.resolved || 0} đã giải quyết</span>
        <span class="spacer"></span>
        <button class="btn sm" id="toggle-resolved">${showResolved ? "Ẩn đã giải quyết" : "Hiện đã giải quyết"}</button>
      </div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Thời gian</th><th>Thị trường</th><th>Mức độ</th><th>Loại</th><th>Kích hoạt</th>
            <th class="right">Quan sát</th><th class="right">Ngưỡng</th><th>Chi tiết</th><th>Trạng thái</th><th></th></tr></thead>
          <tbody>${(alerts.items || []).map((a) => `<tr>
            <td class="mono small">${esc(String(a.ts || "").slice(0, 19).replace("T", " "))}</td>
            <td class="mono small">${esc(a.symbol || "—")}<div class="tiny dim">${esc(a.exchange || "")}</div></td>
            <td>${badge(a.severity, a.severity === "critical" ? "nghiêm trọng" : a.severity === "warning" ? "cảnh báo" : a.severity)}</td>
            <td class="small">${esc(a.type)}</td>
            <td class="small dim">${esc(a.trigger)}</td>
            <td class="num mono">${a.observed == null ? "—" : fmt.num(a.observed, 4)}</td>
            <td class="num mono">${a.threshold == null ? "—" : fmt.num(a.threshold, 4)}</td>
            <td class="small" style="max-width:320px;white-space:normal">${esc(a.message)}</td>
            <td>${a.resolved_at ? badge("ok", "đã giải quyết") : a.acknowledged ? badge("info", "đã xác nhận") : badge("warning", "đang hoạt động")}
              ${a.resolved_at ? `<div class="tiny dim">${esc(a.resolved_reason || "")}</div>` : ""}</td>
            <td>${!a.resolved_at && !a.acknowledged ? `<button class="btn sm" data-ack="${a.id}">Xác nhận</button>` : ""}</td>
          </tr>`).join("") || `<tr><td colspan="10"><div class="table-empty">Không có cảnh báo — chưa vượt ngưỡng nào.</div></td></tr>`}</tbody>
        </table>
      </div>
      <p class="tiny dim" style="margin-top:8px">
        Thời gian tạm ngưng (cooldown) tính cho từng khóa cảnh báo và cấu hình trong Cài đặt. Cảnh báo đóng khi điều kiện hết (cảnh báo dữ liệu cũ tự giải quyết ngay khi luồng trực tiếp trở lại)
        hoặc hết hạn sau 7 ngày; việc xác nhận là thao tác riêng của chuyên viên và cần token API.
      </p>
    </section>

    <section class="section">
      <div class="section-head"><h2>Nhật ký sự kiện</h2></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Thời gian</th><th>Sàn</th><th>Mã</th><th>Mức độ</th><th>Sự kiện</th><th>Chi tiết</th></tr></thead>
          <tbody>${dqRows || `<tr><td colspan="6"><div class="table-empty">Không có sự kiện.</div></td></tr>`}</tbody>
        </table>
      </div>
    </section>
  `);
  document.getElementById("toggle-resolved").addEventListener("click", () => {
    localStorage.setItem("cri_alerts_resolved", showResolved ? "0" : "1");
    renderExchanges();
  });
  document.querySelectorAll("[data-ack]").forEach((btn) => {
    btn.addEventListener("click", async () => {
      try {
        await api(`/api/v1/alerts/${btn.dataset.ack}/ack`, { method: "POST" });
        toast("Đã xác nhận cảnh báo");
        renderExchanges();
      } catch (err) {
        toast(err.message || "Xác nhận thất bại (cần token?)", "error");
      }
    });
  });
  return null;
}

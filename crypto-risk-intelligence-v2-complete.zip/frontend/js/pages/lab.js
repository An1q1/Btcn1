// Phòng thí nghiệm mô hình: danh mục mô hình, dự báo trực tiếp, hệ số và tầm quan trọng đặc trưng.
import {
  api, fmt, esc, badge, loadingView, errorView, setView, setCrumb, state, emptyView,
} from "../core.js";
import { chart } from "../charts.js";

const DEFAULT_MODEL = "har_rv";

const MODEL_LABELS_VI = {
  naive: "Naive RV (mốc)",
  har_rv: "HAR-RV (OLS)",
  garch_normal: "GARCH(1,1) Chuẩn",
  garch_t: "GARCH(1,1) Student-t",
  xgb_har: "XGBoost-HAR",
  xgb_extended: "XGBoost mở rộng",
  historical: "Mô phỏng lịch sử",
  garch_evt: "GARCH-EVT (POT/GPD)",
};

export async function renderLab() {
  loadingView("Đang tải phòng thí nghiệm mô hình…");
  const horizon = Number(localStorage.getItem("cri_horizon") || 1);
  const market = state.market || { exchange: "binance_spot", symbol: "BTCUSDT" };

  let models, forecasts, comparison;
  try {
    [models, forecasts] = await Promise.all([
      api("/api/v1/models"),
      api(`/api/v1/forecasts?horizon=${horizon}&limit=300`),
    ]);
  } catch (err) {
    errorView(err, renderLab);
    return;
  }
  try {
    comparison = await api(`/api/v1/markets/${encodeURIComponent(market.exchange)}/${encodeURIComponent(market.symbol)}/comparison?horizon=${horizon}`);
  } catch {
    comparison = null;
  }
  setCrumb("Phòng thí nghiệm mô hình", `${forecasts.items?.length || 0} thị trường · chân trời ${horizon} ngày`);

  const catalog = (models.models || []).map((m) => `
    <div class="card tight">
      <div class="card-head"><h3>${esc(MODEL_LABELS_VI[m.name] || m.label || m.name)}</h3><span class="spacer"></span>${badge(m.status || "ok", m.status === "ok" ? "hoạt động" : m.status || "ok")}</div>
      <p class="small muted" style="margin:0 0 8px">${esc(m.description || m.family)}</p>
      <div class="kv"><span>Phiên bản</span><span class="mono">${esc(m.version)}</span></div>
      <div class="kv"><span>Số dòng dự báo</span><span class="mono">${fmt.num(m.forecast_rows)}</span></div>
      <div class="kv"><span>Thị trường</span><span class="mono">${m.markets ?? "—"}</span></div>
    </div>`).join("");

  const items = forecasts.items || [];
  const rows = items.map((f) => {
    const best = Object.entries(f.models || {})
      .filter(([, v]) => v && v.predicted_vol != null)
      .sort((a, b) => a[1].predicted_vol - b[1].predicted_vol);
    return `<tr>
      <td><a class="mono" href="#/asset/${encodeURIComponent(f.exchange)}/${encodeURIComponent(f.symbol)}">${esc(f.symbol)}</a>
          <div class="tiny dim">${esc(f.exchange)}</div></td>
      <td class="num mono">${fmt.num(f.rv)}</td>
      <td class="num mono">${fmt.num(f.predicted_rv)}</td>
      <td class="num mono">${fmt.pct(f.predicted_vol)}</td>
      <td class="num mono">${f.dispersion == null ? "—" : fmt.num(f.dispersion, 3)}</td>
      <td class="small">${esc(best[0] ? (MODEL_LABELS_VI[best[0][0]] || forecasts.model_labels?.[best[0][0]] || best[0][0]) : "—")}</td>
      <td class="small dim">${f.regime || ""}</td>
    </tr>`;
  }).join("");

  const metrics = comparison?.metrics || {};
  const metricRows = Object.entries(metrics).map(([name, m]) => `
    <tr><td>${esc(MODEL_LABELS_VI[name] || forecasts.model_labels?.[name] || name)}</td>
      <td class="num mono">${fmt.num(m.rmse)}</td>
      <td class="num mono">${fmt.num(m.mae)}</td>
      <td class="num mono">${fmt.num(m.qlike, 4)}</td>
      <td class="num mono">${m.bias == null ? "—" : fmt.num(m.bias)}</td>
    </tr>`).join("");

  const importance = comparison?.feature_importance || {};
  const impItems = Object.entries(importance).sort((a, b) => b[1] - a[1]).slice(0, 12);

  setView(`
    <div class="page-head">
      <div><h1>Phòng thí nghiệm mô hình</h1>
        <p>Danh mục mô hình, dự báo liên thị trường trực tiếp và tham số đã khớp. Mọi mô hình đều kiểm định cuốn chiếu — không mô hình nào được nhìn thấy cửa sổ đánh giá của chính nó.</p></div>
      <div class="spacer"></div>
      <select class="input" id="sel-horizon" style="max-width:160px">
        ${[1, 7, 30].map((h) => `<option value="${h}" ${h === horizon ? "selected" : ""}>Chân trời ${h} ngày</option>`).join("")}
      </select>
    </div>

    <div class="grid grid-3">${catalog || emptyView("Chưa có mô hình nào được đăng ký", "Hãy chạy pipeline dự báo một lần.")}</div>

    <section class="section">
      <div class="section-head"><h2>Dự báo mới nhất theo thị trường</h2><span class="hint">trung vị của 6 mô hình · ${esc(forecasts.as_of || "")}</span></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Thị trường</th><th class="right">RV hiện tại</th><th class="right">RV dự báo trung vị</th><th class="right">Biến động dự báo (năm hóa)</th><th class="right">Độ phân tán</th><th>Mô hình thấp nhất</th><th>Trạng thái</th></tr></thead>
          <tbody>${rows || `<tr><td colspan="7"><div class="table-empty">Chưa có dự báo cho chân trời này.</div></td></tr>`}</tbody>
        </table>
      </div>
      <p class="tiny dim" style="margin-top:8px">Độ phân tán = (max − min) / trung vị giữa các mô hình. Phân tán rộng nghĩa là các họ mô hình không đồng thuận và dự báo điểm nên được xem xét thận trọng.</p>
    </section>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>Chỉ số kiểm định cuốn chiếu — ${esc(market.exchange)}:${esc(market.symbol)}</h3><span class="spacer"></span>
          <a class="small" href="#/asset/${encodeURIComponent(market.exchange)}/${encodeURIComponent(market.symbol)}">Mở chi tiết →</a></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th>Mô hình</th><th class="right">RMSE</th><th class="right">MAE</th><th class="right">QLIKE</th><th class="right">Độ chệch</th></tr></thead>
          <tbody>${metricRows || `<tr><td colspan="5"><div class="table-empty">Chỉ số sẽ xuất hiện sau bước đánh giá.</div></td></tr>`}</tbody>
        </table></div>
        <p class="tiny dim" style="margin:8px 10px 10px">${esc(comparison?.target_definition || "Mục tiêu: trung bình phương sai thực tế trên (t+1..t+h), đơn vị %²/ngày.")}</p>
      </section>
      <section class="card">
        <div class="card-head"><h3>Tầm quan trọng đặc trưng XGBoost mở rộng</h3></div>
        <div class="chart" id="chart-importance" style="height:260px"></div>
        ${comparison?.har_coefficients ? `<p class="tiny dim" style="margin:8px 10px 10px">Hệ số HAR (rv, rv_w, rv_m): ${(comparison.har_coefficients.coef || []).map((c) => fmt.num(c, 3)).join(" / ")} · hệ số chặn ${fmt.num(comparison.har_coefficients.intercept, 3)} · n=${comparison.har_coefficients.train_obs}</p>` : ""}
      </section>
    </div>
  `);

  if (impItems.length) {
    chart(document.getElementById("chart-importance"), {
      height: 260,
      series: [{ name: "tầm quan trọng", type: "bar", color: "#b38cff", points: impItems.map(([k, v]) => ({ x: k, y: v })), barWidth: 0.6 }],
      yFormat: (v) => `${(v * 100).toFixed(0)}%`,
      ariaLabel: "tầm quan trọng đặc trưng",
    });
  } else {
    document.getElementById("chart-importance").innerHTML = `<div class="empty">Tầm quan trọng đặc trưng được lưu cùng mỗi dự báo xgb_extended; hãy chọn thị trường đã có dự báo.</div>`;
  }

  document.getElementById("sel-horizon").addEventListener("change", (e) => {
    localStorage.setItem("cri_horizon", e.target.value);
    renderLab();
  });
  return null;
}

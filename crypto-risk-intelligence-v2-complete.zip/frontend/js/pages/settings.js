// Cài đặt: cấu hình hiệu lực, ghi đè runtime, token và sức khỏe hệ thống.
import {
  api, fmt, esc, badge, loadingView, errorView, setView, setCrumb, toast, state,
} from "../core.js";

const EDITABLE = ["alert_cooldown_minutes"];

const LABELS = {
  alert_cooldown_minutes: "Thời gian tạm ngưng cảnh báo (phút)",
  min_quote_volume_usd: "Khối lượng tối thiểu (USD)",
  max_spread_bps: "Chênh lệch tối đa (bps)",
  target_markets: "Số thị trường mục tiêu",
};

export async function renderSettings() {
  loadingView("Đang tải cấu hình…");
  let settings, status;
  try {
    [settings, status] = await Promise.all([
      api("/api/v1/settings"),
      api("/api/v1/system/status"),
    ]);
  } catch (err) {
    errorView(err, renderSettings);
    return;
  }
  setCrumb("Cài đặt", status.environment || "");

  const eff = settings.effective || {};
  const overrides = settings.overrides || {};
  const fields = Object.entries(eff).map(([k, v]) => `
    <div class="kv"><span class="mono small">${esc(LABELS[k] || k)}</span><span class="mono small">${esc(String(v))}</span></div>`).join("");

  const counts = status.counts || {};
  const store = status.storage || {};
  const cfg = status.config || {};

  setView(`
    <div class="page-head">
      <div><h1>Cài đặt</h1>
        <p>Chế độ xem chỉ đọc của cấu hình hiệu lực cộng với các nút runtime có thể đổi mà không cần khởi động lại.</p></div>
      <div class="spacer"></div>
      <a class="btn sm" href="/api/docs" target="_blank" rel="noopener">Tài liệu OpenAPI ↗</a>
    </div>

    <div class="grid grid-2">
      <section class="card">
        <div class="card-head"><h3>Ghi đè runtime</h3><span class="spacer"></span>${badge(state.token ? "ok" : "warning", state.token ? "đã đặt token" : "chưa có token")}</div>
        <p class="small muted">Chỉ các khóa này có thể đổi từ giao diện. Chúng được lưu trong <span class="mono">config_store</span> và áp dụng ngay cho cảnh báo.</p>
        ${EDITABLE.map((key) => `
          <label class="field">
            <span class="small">${esc(LABELS[key] || key)}</span>
            <input class="input" id="ov-${esc(key)}" type="number" min="0" step="1"
              value="${esc(overrides[key] ?? eff[key] ?? "")}" />
            <span class="tiny dim">Thời gian chờ trước khi cùng một cảnh báo được kích hoạt lại (phút).</span>
          </label>`).join("")}
        <label class="field">
          <span class="small">Token API (chỉ cần cho thao tác ghi)</span>
          <input class="input" id="api-token" type="password" placeholder="X-API-Token / Bearer token" value="${esc(state.token)}" />
        </label>
        <button class="btn" id="save-settings">Lưu thay đổi</button>
        <p class="tiny dim" style="margin-top:8px">Endpoint thay đổi yêu cầu <span class="mono">Authorization: Bearer &lt;token&gt;</span> khi <span class="mono">API_TOKEN</span> đã được cấu hình trên máy chủ.</p>
      </section>

      <section class="card">
        <div class="card-head"><h3>Trạng thái hệ thống</h3></div>
        <div class="kv"><span>Thời gian máy chủ</span><span class="mono small">${esc(fmt.datetime(status.server_time))}</span></div>
        <div class="kv"><span>Môi trường</span><span class="mono small">${esc(status.config?.environment || "")}</span></div>
        <div class="kv"><span>Cơ sở dữ liệu</span><span class="mono small">${store.database_bytes == null ? "—" : fmt.num(store.database_bytes / 1e6, 1) + " MB"}</span></div>
        <div class="kv"><span>Thị trường / trong vũ trụ / đủ điều kiện</span><span class="mono small">${counts.markets} / ${counts.markets_in_universe} / ${counts.markets_model_eligible}</span></div>
        <div class="kv"><span>Số dòng OHLCV</span><span class="mono small">${fmt.num(counts.ohlcv_rows)}</span></div>
        <div class="kv"><span>Số dòng đặc trưng</span><span class="mono small">${fmt.num(counts.feature_rows)}</span></div>
        <div class="kv"><span>Số dòng dự báo</span><span class="mono small">${fmt.num(counts.forecast_rows)}</span></div>
        <div class="kv"><span>Số dòng VaR/ES</span><span class="mono small">${fmt.num(counts.var_es_rows)}</span></div>
        <div class="kv"><span>Số mục tiêu thực tế</span><span class="mono small">${fmt.num(counts.targets)}</span></div>
        <div class="kv"><span>Số dòng phái sinh</span><span class="mono small">${fmt.num(counts.derivative_rows)}</span></div>
        <div class="kv"><span>Ngày đặc trưng gần nhất</span><span class="mono small">${esc(status.last_feature_date || "—")}</span></div>
        <div class="hr"></div>
        <div class="kv"><span>Tác vụ nền</span><span class="mono small">${cfg.background_jobs ? "đang bật" : "đang tắt"}</span></div>
        <div class="kv"><span>WebSocket</span><span class="mono small">${cfg.enable_websocket ? "đang bật" : "đang tắt"}</span></div>
        <div class="kv"><span>Khung nến</span><span class="mono small">${esc(cfg.bar_timeframe || "")}</span></div>
        <div class="kv"><span>Nhìn lại (lookback)</span><span class="mono small">${cfg.ingest_lookback_days} ngày</span></div>
      </section>
    </div>

    <section class="section">
      <div class="section-head"><h2>Cấu hình hiệu lực</h2><span class="hint">môi trường + mặc định</span></div>
      <div class="card">${fields}</div>
      <p class="small muted" style="margin-top:10px">
        Cấu hình nằm trong biến môi trường (xem <span class="mono">.env.example</span>). Không có bí mật nào lưu trong cơ sở dữ liệu,
        và không cần khóa sàn: nền tảng chỉ đọc dữ liệu thị trường công khai.
      </p>
    </section>

    <section class="section">
      <div class="section-head"><h2>Tổng hợp chất lượng dữ liệu</h2></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Sự kiện</th><th>Mức độ</th><th class="right">Số lượng</th></tr></thead>
        <tbody>${(status.data_quality || []).map((r) => `<tr><td class="small">${esc(r.event_type)}</td>
          <td>${badge(r.severity, r.severity === "warning" ? "cảnh báo" : r.severity === "critical" ? "nghiêm trọng" : r.severity)}</td><td class="num mono">${r.count}</td></tr>`).join("")
          || `<tr><td colspan="3"><div class="table-empty">Không có sự kiện chất lượng dữ liệu.</div></td></tr>`}</tbody>
      </table></div>
      <p class="tiny dim" style="margin-top:8px">Các ngưỡng và bộ lọc vũ trụ có thể chỉnh trong <span class="mono">.env</span> và ghi đè tạm thời ở trên. Thay đổi áp dụng ngay mà không cần khởi động lại.</p>
    </section>

    <section class="section">
      <div class="card">
        <div class="card-head"><h3>Hướng dẫn vận hành nhanh</h3></div>
        <ul class="small muted" style="margin:0; padding-left:18px; line-height:1.7">
          <li><span class="mono">python -m scripts.bootstrap</span> — chạy toàn bộ pipeline từ dữ liệu thực.</li>
          <li><span class="mono">python -m scripts.bootstrap --from features</span> — chạy lại từ bước đặc trưng.</li>
          <li><span class="mono">alembic upgrade head</span> — áp dụng migration.</li>
          <li><span class="mono">pytest -q</span> — bộ kiểm thử đầy đủ (88 test).</li>
          <li>Xem log tại <span class="mono">logs/</span> và Parquet tại <span class="mono">data/parquet/</span>.</li>
        </ul>
      </div>
    </section>
  `);

  document.getElementById("save-settings").addEventListener("click", async () => {
    const tokenInput = document.getElementById("api-token");
    if (tokenInput) {
      state.token = tokenInput.value.trim();
      sessionStorage.setItem("cri_token", state.token);
    }
    const payload = {};
    EDITABLE.forEach((key) => {
      const el = document.getElementById(`ov-${key}`);
      if (el && el.value !== "") payload[key] = Number(el.value);
    });
    try {
      await api("/api/v1/settings", { method: "PUT", body: payload });
      toast("Đã lưu cài đặt");
      renderSettings();
    } catch (err) {
      toast(err.message || "Không lưu được cài đặt", "error");
    }
  });
  return null;
}

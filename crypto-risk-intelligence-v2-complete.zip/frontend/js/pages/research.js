// Nghiên cứu & kiểm định: cấu hình kiểm định cuốn chiếu, chỉ số tổng hợp, kiểm định DM, bảng theo tài sản.
import {
  api, fmt, esc, badge, loadingView, errorView, setView, setCrumb, emptyView,
} from "../core.js";

const METRIC_ORDER = ["rmse", "mae", "qlike", "qlike_median"];

export async function renderResearch() {
  loadingView("Đang tải kết quả kiểm định cuốn chiếu…");
  let d;
  try {
    d = await api("/api/v1/backtests");
  } catch (err) {
    errorView(err, renderResearch);
    return;
  }
  setCrumb("Nghiên cứu & kiểm định", d.evaluation_run || "");

  const cfg = d.config || {};
  const horizons = cfg.horizons || [1, 7, 30];
  const agg = d.aggregate || [];
  const models = [...new Set(agg.map((r) => r.model))].sort();

  const tables = horizons.map((h) => {
    const rows = models.map((m) => {
      const cell = (metric) => {
        const r = agg.find((x) => x.horizon === h && x.model === m && x.metric === metric);
        if (!r) return `<td class="num mono dim">—</td>`;
        const label = fmt.num(r.value, 4);
        return `<td class="num mono">${label}${metric === "qlike" && r.median != null ? `<div class="tiny dim">trung vị ${fmt.num(r.median, 4)}</div>` : ""}</td>`;
      };
      return `<tr>
        <td>${esc(m)}</td>
        ${METRIC_ORDER.map(cell).join("")}
        <td class="num mono small">${fmt.num(agg.find((x) => x.horizon === h && x.model === m)?.n_obs)}</td>
      </tr>`;
    }).join("");
    return `<section class="card" style="margin-top:14px">
      <div class="card-head"><h3>Chân trời ${h} ngày</h3><span class="spacer"></span><span class="hint">ước lượng trực tiếp trên RV trung bình trượt</span></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Mô hình</th><th class="right">RMSE</th><th class="right">MAE</th><th class="right">QLIKE (trung bình)</th><th class="right">QLIKE (trung vị)</th><th class="right">Số quan sát</th></tr></thead>
        <tbody>${rows}</tbody>
      </table></div>
    </section>`;
  }).join("");

  const dm = d.dm_summary || [];
  const dmRows = dm.map((r) => `<tr>
      <td class="mono">${r.horizon} ngày</td>
      <td>${esc(r.model)}</td>
      <td class="num mono">${r.n}</td>
      <td class="num mono">${r.significant_better}</td>
      <td class="num mono">${r.share_beating_har == null ? "—" : fmt.pct(r.share_beating_har, 1)}</td>
      <td class="num mono">${r.median_dm_stat == null ? "—" : fmt.num(r.median_dm_stat, 2)}</td>
    </tr>`).join("");

  const cycleLabels = { low: "Thấp", normal: "Bình thường", high: "Cao", extreme: "Cực đoan" };
  const regimes = ["low", "normal", "high", "extreme"];
  const regimeRows = models.map((m) => {
    const cells = regimes.map((reg) => {
      const r = agg.find((x) => x.horizon === horizons[0] && x.model === m && x.metric === "rmse" && x.regime_rmse?.[reg]);
      if (!r) return `<td class="num mono dim">—</td>`;
      return `<td class="num mono">${fmt.num(r.regime_rmse[reg].value)}</td>`;
    }).join("");
    return `<tr><td>${esc(m)}</td>${cells}</tr>`;
  }).join("");

  const perAsset = (d.per_asset || []).filter((r) => r.horizon === horizons[0]).slice(0, 60);
  const perAssetRows = perAsset.map((r) => {
    const mm = r.metrics || {};
    return `<tr>
      <td class="mono small">${esc(r.symbol)}<div class="tiny dim">${esc(r.exchange)}</div></td>
      <td class="num mono">${fmt.num(mm.har_rv_rmse)}</td>
      <td class="num mono">${fmt.num(mm.garch_normal_rmse)}</td>
      <td class="num mono">${fmt.num(mm.xgb_extended_rmse)}</td>
      <td class="num mono">${fmt.num(mm.naive_rmse)}</td>
      <td class="num mono">${fmt.num(mm.har_rv_qlike, 4)}</td>
      <td class="num mono">${fmt.num(mm.garch_normal_qlike, 4)}</td>
    </tr>`;
  }).join("");

  const cfgRows = Object.entries(cfg)
    .filter(([, v]) => typeof v !== "object")
    .map(([k, v]) => {
      const labels = {
        horizons: "Chân trời", walkforward_min_train: "Số mẫu huấn luyện tối thiểu", walkforward_refit_every: "Tần suất khớp lại",
        risk_min_train: "Mẫu tối thiểu rủi ro", horizons_h: "Chân trời", target_definition: "Định nghĩa mục tiêu"
      };
      return `<div class="kv"><span>${esc(labels[k] || k)}</span><span class="mono small">${esc(String(v))}</span></div>`;
    })
    .join("");

  setView(`
    <div class="page-head">
      <div><h1>Nghiên cứu & kiểm định</h1>
        <p>Kiểm định cuốn chiếu với cửa sổ mở rộng. Mọi chỉ số dưới đây được tính trên dữ liệu mà mô hình chưa từng thấy, với cửa sổ mục tiêu đã loại khỏi huấn luyện.</p></div>
      <div class="spacer"></div>
      <span class="status-chip ${d.evaluation_run ? "live" : ""}">${esc(d.evaluation_run || "chưa có lần kiểm định")}</span>
    </div>

    <div class="grid grid-2">
      <section class="card">
        <div class="card-head"><h3>Giao thức kiểm định</h3></div>
        ${cfgRows}
        <p class="tiny dim" style="margin-top:8px">Walk-forward: cửa sổ mở rộng, khớp lại mỗi 10 bước, ước lượng trực tiếp cho từng chân trời, cửa sổ cuối cùng được giữ nguyên làm tập kiểm tra.</p>
      </section>
      <section class="card">
        <div class="card-head"><h3>Định nghĩa mục tiêu</h3></div>
        <p class="small">${esc(cfg.target_definition || "Mục tiêu: trung bình phương sai thực tế trên (t+1..t+h), đơn vị %²/ngày.")}</p>
        <div class="kv"><span>Khoảng loại bỏ (purge)</span><span class="small">${esc(cfg.purge || "không chồng chéo mục tiêu-huấn luyện")}</span></div>
        <div class="kv"><span>Khớp lại</span><span class="small">${esc(cfg.refit || "mỗi 10 gốc")}</span></div>
        <div class="hr"></div>
        <div class="kv"><span>Số dòng dự báo</span><span class="mono">${fmt.num(d.coverage?.forecast_rows)}</span></div>
        <div class="kv"><span>Số mục tiêu thực tế</span><span class="mono">${fmt.num(d.coverage?.realized_targets)}</span></div>
        <div class="kv"><span>Số dòng chỉ số</span><span class="mono">${fmt.num(agg.length)}</span></div>
      </section>
    </div>

    ${tables || emptyView("Chưa có kết quả kiểm định", "Chạy `python -m scripts.cli evaluate`.")}

    <p class="small muted" style="margin-top:10px">
      QLIKE được hiển thị cả trung bình và trung vị: trung bình nhạy với một vài dự báo phương sai gần 0, trung vị thì bền vững hơn.
      Hãy đọc cả hai và ưu tiên trung vị khi so sánh mô hình trên các thị trường có phương sai không đồng nhất.
    </p>

    <div class="grid grid-2" style="margin-top:18px">
      <section class="card">
        <div class="card-head"><h3>RMSE theo trạng thái — ${horizons[0]} ngày</h3><span class="hint">trạng thái gắn tại gốc</span></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th>Mô hình</th><th class="right">Thấp</th><th class="right">Bình thường</th><th class="right">Cao</th><th class="right">Cực đoan</th></tr></thead>
          <tbody>${regimeRows || `<tr><td colspan="5"><div class="table-empty">Chưa có phân rã theo trạng thái.</div></td></tr>`}</tbody>
        </table></div>
      </section>
      <section class="card">
        <div class="card-head"><h3>Diebold–Mariano so với HAR-RV</h3><span class="hint">thống kê âm nghĩa là mô hình thách thức tốt hơn</span></div>
        <div class="table-wrap"><table class="data">
          <thead><tr><th>Chân trời</th><th>Mô hình</th><th class="right">Số thị trường</th><th class="right">Số lần tốt hơn có ý nghĩa</th><th class="right">Tỷ lệ vượt HAR</th><th class="right">DM trung vị</th></tr></thead>
          <tbody>${dmRows || `<tr><td colspan="6"><div class="table-empty">Chưa có kiểm định DM.</div></td></tr>`}</tbody>
        </table></div>
        <p class="tiny dim" style="margin:8px 10px 10px">DM trung vị dương nghĩa là mô hình thách thức thường tệ hơn HAR-RV một cách có ý nghĩa. “Số lần tốt hơn có ý nghĩa” đếm số thị trường có p &lt; 0,05 nghiêng về mô hình thách thức.</p>
      </section>
    </div>

    <section class="section">
      <div class="section-head"><h2>Chỉ số theo thị trường — ${horizons[0]} ngày</h2><span class="hint">${perAsset.length} thị trường</span></div>
      <div class="table-wrap">
        <table class="data">
          <thead><tr><th>Thị trường</th><th class="right">HAR RMSE</th><th class="right">GARCH-N RMSE</th><th class="right">XGB-mở rộng RMSE</th><th class="right">Naive RMSE</th><th class="right">HAR QLIKE</th><th class="right">GARCH-N QLIKE</th></tr></thead>
          <tbody>${perAssetRows || `<tr><td colspan="7"><div class="table-empty">Chưa có chỉ số theo thị trường.</div></td></tr>`}</tbody>
        </table>
      </div>
    </section>

    <section class="section">
      <div class="section-head"><h2>Lịch sử chạy</h2></div>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Lần chạy</th><th>Loại</th><th>Trạng thái</th><th>Bắt đầu</th><th class="right">Kết thúc</th><th>Chỉ số</th></tr></thead>
        <tbody>${(d.runs || []).slice(0, 12).map((r) => `<tr>
          <td class="mono small">${esc(r.id)}</td><td class="small">${esc(r.kind === "forecast" ? "dự báo" : r.kind === "risk" ? "rủi ro" : r.kind)}</td>
          <td>${badge(r.status, r.status === "ok" ? "hoàn tất" : r.status === "running" ? "đang chạy" : r.status)}</td>
          <td class="mono small">${esc(fmt.datetime(r.started_at))}</td>
          <td class="mono small">${esc(r.finished_at ? fmt.datetime(r.finished_at) : "—")}</td>
          <td class="small dim">${esc(JSON.stringify(r.metrics || {}).slice(0, 90))}</td>
        </tr>`).join("") || `<tr><td colspan="6"><div class="table-empty">Chưa có lần chạy nào.</div></td></tr>`}</tbody>
      </table></div>
    </section>
  `);
  return null;
}

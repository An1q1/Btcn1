import { state, applyTheme, connectStream, setCrumb, toast } from "./core.js";
import { renderOverview } from "./pages/overview.js";
import { renderScreener } from "./pages/screener.js";
import { renderAsset } from "./pages/asset.js";
import { renderLab } from "./pages/lab.js";
import { renderTail } from "./pages/tail.js";
import { renderExchanges } from "./pages/exchanges.js";
import { renderResearch } from "./pages/research.js";
import { renderSettings } from "./pages/settings.js";

const routes = {
  overview: { title: "Tổng quan thị trường", render: renderOverview },
  screener: { title: "Bộ lọc tài sản", render: renderScreener },
  asset: { title: "Chi tiết tài sản", render: renderAsset },
  lab: { title: "Phòng thí nghiệm mô hình", render: renderLab },
  tail: { title: "Trung tâm rủi ro cực đoan", render: renderTail },
  exchanges: { title: "Giám sát sàn giao dịch", render: renderExchanges },
  research: { title: "Nghiên cứu & kiểm định", render: renderResearch },
  settings: { title: "Cài đặt", render: renderSettings },
};

let cleanup = null;

function parseHash() {
  const raw = (location.hash || "#/overview").replace(/^#\/?/, "");
  const [page, ...rest] = raw.split("/");
  return { page: routes[page] ? page : "overview", params: rest.map(decodeURIComponent) };
}

async function render(force = false) {
  const { page, params } = parseHash();
  if (cleanup) { try { cleanup(); } catch {} cleanup = null; }
  document.querySelectorAll("#nav a").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
  const route = routes[page];
  setCrumb(route.title, "");
  document.getElementById("crash-banner")?.remove();
  try {
    const result = await route.render(params, { force });
    if (typeof result === "function") cleanup = result;
  } catch (err) {
    console.error(err);
    const view = document.getElementById("view");
    view.innerHTML = `<div class="error-box"><strong>Lỗi không mong muốn</strong><p class="small">${err.message}</p></div>`;
    toast(err.message || "Yêu cầu thất bại", "error");
  }
  window.scrollTo({ top: 0, behavior: "instant" });
}

document.getElementById("refresh-btn").addEventListener("click", () => {
  render(true);
  toast("Đang làm mới dữ liệu…");
});
document.getElementById("theme-btn").addEventListener("click", () => {
  state.theme = state.theme === "dark" ? "light" : "dark";
  applyTheme();
  render(true);
});
document.getElementById("menu-btn").addEventListener("click", () => {
  document.getElementById("sidebar").classList.toggle("open");
});
document.getElementById("nav").addEventListener("click", () => {
  document.getElementById("sidebar").classList.remove("open");
});
window.addEventListener("hashchange", () => render());
window.addEventListener("error", (ev) => console.error("lỗi window", ev.error));

applyTheme();
connectStream();
render();

// giữ chỉ báo độ mới ở topbar luôn chính xác kể cả khi không render lại trang
setInterval(async () => {
  try {
    const res = await fetch("/api/v1/health", { headers: { Accept: "application/json" } });
    const data = await res.json();
    const chip = document.getElementById("freshness-chip");
    if (data.status === "ok" && chip && !chip.textContent.includes("trực tiếp")) {
      chip.textContent = "API hoạt động tốt";
      chip.className = "status-chip good";
    }
  } catch {
    const chip = document.getElementById("freshness-chip");
    if (chip) { chip.textContent = "Không kết nối được API"; chip.className = "status-chip disconnected"; }
  }
}, 45000);

export { render };

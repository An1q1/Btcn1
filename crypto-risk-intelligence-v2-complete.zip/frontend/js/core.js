// Tiện ích chung: client API, định dạng, helpers DOM, trạng thái, SSE.
export const state = {
  market: { exchange: "binance_spot", symbol: "BTCUSDT" },
  horizon: 1,
  confidence: 0.99,
  model: "har_rv",
  token: sessionStorage.getItem("cri_token") || "",
  watchlist: new Set(JSON.parse(localStorage.getItem("cri_watchlist") || "[]")),
  theme: localStorage.getItem("cri_theme") || "dark",
};

export function saveWatchlist() {
  localStorage.setItem("cri_watchlist", JSON.stringify([...state.watchlist]));
}

export async function api(path, opts = {}) {
  const headers = { Accept: "application/json", ...(opts.headers || {}) };
  if (opts.body && !(opts.body instanceof FormData)) {
    headers["Content-Type"] = "application/json";
    opts.body = JSON.stringify(opts.body);
  }
  if (state.token) headers["Authorization"] = `Bearer ${state.token}`;
  const res = await fetch(path, { ...opts, headers });
  let payload = null;
  const text = await res.text();
  try { payload = text ? JSON.parse(text) : null; } catch { payload = { raw: text }; }
  if (!res.ok) {
    const msg = payload?.error?.message || payload?.detail || `HTTP ${res.status}`;
    const err = new Error(msg);
    err.status = res.status;
    err.payload = payload;
    throw err;
  }
  return payload;
}

export const fmt = {
  num(v, digits = 2) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
    const n = Number(v);
    const abs = Math.abs(n);
    if (abs >= 1e12) return (n / 1e12).toFixed(2) + "T";
    if (abs >= 1e9) return (n / 1e9).toFixed(2) + "B";
    if (abs >= 1e6) return (n / 1e6).toFixed(2) + "M";
    if (abs >= 1e4) return (n / 1e3).toFixed(1) + "K";
    if (abs > 0 && abs < 0.001) return n.toExponential(2);
    return n.toLocaleString("vi-VN", { maximumFractionDigits: digits, minimumFractionDigits: 0 });
  },
  price(v) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
    const n = Number(v);
    if (n >= 1000) return n.toLocaleString("vi-VN", { maximumFractionDigits: 2 });
    if (n >= 1) return n.toFixed(4).replace(/\.?0+$/, "");
    return n.toPrecision(5);
  },
  pct(v, digits = 2, already = false) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
    // Hiển thị dạng 8,2% (phẩy thập phân kiểu Việt Nam)
    const val = Number(v) * (already ? 1 : 100);
    return `${val.toLocaleString("vi-VN", { maximumFractionDigits: digits, minimumFractionDigits: digits })}%`;
  },
  signedPct(v, digits = 2) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
    const n = Number(v);
    return `${n > 0 ? "+" : ""}${n.toFixed(digits).replace(".", ",")}%`;
  },
  bps(v) {
    if (v === null || v === undefined || Number.isNaN(Number(v))) return "—";
    return `${Number(v).toFixed(1).replace(".", ",")} bps`;
  },
  date(s) { return s ? String(s).slice(0, 10) : "—"; },
  datetime(s) {
    if (!s) return "—";
    try {
      return new Date(s).toLocaleString("vi-VN", { year: "numeric", month: "short", day: "2-digit", hour: "2-digit", minute: "2-digit" });
    } catch { return String(s); }
  },
  ago(s) {
    if (!s) return "—";
    try {
      const diff = (Date.now() - new Date(s).getTime()) / 1000;
      if (diff < 0) return "vừa xong";
      if (diff < 60) return `${Math.round(diff)} giây trước`;
      if (diff < 3600) return `${Math.round(diff / 60)} phút trước`;
      if (diff < 86400) return `${Math.round(diff / 3600)} giờ trước`;
      return `${Math.round(diff / 86400)} ngày trước`;
    } catch { return "—"; }
  },
};

export function esc(value) {
  return String(value ?? "")
    .replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;").replaceAll("'", "&#39;");
}

export function h(html) {
  const tpl = document.createElement("template");
  tpl.innerHTML = html.trim();
  return tpl.content.firstElementChild;
}

export function setView(html) {
  const view = document.getElementById("view");
  view.innerHTML = html;
  return view;
}

export function loadingView(message = "Đang tải dữ liệu…") {
  setView(`
    <div class="loading-block">
      <div class="skeleton h-32" style="width:38%"></div>
      <div class="grid grid-4">
        <div class="skeleton h-96"></div><div class="skeleton h-96"></div>
        <div class="skeleton h-96"></div><div class="skeleton h-96"></div>
      </div>
      <div class="skeleton h-260"></div>
      <p class="muted small">${esc(message)}</p>
    </div>`);
}

export function errorView(err, retry) {
  const msg = err.message || String(err);
  // Dịch một số thông báo lỗi thường gặp
  const viMsg = msg === "request validation failed" ? "Yêu cầu không hợp lệ" : msg === "internal server error" ? "Lỗi hệ thống nội bộ" : msg;
  setView(`<div class="error-box">
      <strong>Không tải được dữ liệu</strong>
      <p class="small" style="margin:8px 0 0">${esc(viMsg)}</p>
      ${err.status ? `<p class="tiny dim" style="margin:4px 0 0">HTTP ${esc(err.status)}</p>` : ""}
      <button class="btn" style="margin-top:12px" id="retry-btn">Thử lại</button>
    </div>`);
  const btn = document.getElementById("retry-btn");
  if (btn && retry) btn.addEventListener("click", retry);
}

export function emptyView(title, detail = "") {
  return `<div class="empty"><div class="bold">${esc(title)}</div>${detail ? `<div class="small" style="margin-top:6px">${esc(detail)}</div>` : ""}</div>`;
}

export function badge(value, label) {
  const v = String(value ?? "unknown").toLowerCase().replaceAll(" ", "_");
  return `<span class="badge ${esc(v)}">${esc(label ?? value ?? "—")}</span>`;
}

export function regimeBadge(regime) {
  const labels = {
    low: "Biến động thấp", normal: "Biến động bình thường", high: "Biến động cao", extreme: "Biến động cực đoan",
    insufficient_data: "Thiếu dữ liệu", not_modelled: "Chưa mô hình hóa",
  };
  return badge(regime, labels[regime] || regime);
}

export function freshnessBadge(freshness) {
  const labels = { live: "Trực tiếp", delayed: "Trễ", stale: "Dữ liệu cũ", disconnected: "Mất kết nối", unknown: "Không rõ" };
  return badge(freshness, labels[freshness] || freshness || "không rõ");
}

export function toast(message, kind = "ok", ttl = 3800) {
  const box = document.getElementById("toasts");
  const el = h(`<div class="toast ${kind}">${esc(message)}</div>`);
  box.appendChild(el);
  setTimeout(() => el.remove(), ttl);
}

export function setCrumb(title, sub = "") {
  document.getElementById("crumb").textContent = title;
  document.getElementById("asof").textContent = sub;
}

export function linkMarket(exchange, symbol, label) {
  return `<a href="#/asset/${encodeURIComponent(exchange)}/${encodeURIComponent(symbol)}" class="mono">${esc(label || symbol)}</a>`;
}

export function sortableHeader(label, key, current, order) {
  const active = current === key;
  const arrow = active ? (order === "desc" ? "↓" : "↑") : "";
  return `<th class="sortable" data-sort="${esc(key)}">${esc(label)} <span class="dim">${arrow}</span></th>`;
}

export function paginate(total, page, pageSize) {
  const pages = Math.max(1, Math.ceil(total / pageSize));
  return `<div class="pager">
    <span class="small muted">${total.toLocaleString("vi-VN")} kết quả</span>
    <div class="spacer"></div>
    <button class="btn sm" data-page="${Math.max(1, page - 1)}" ${page <= 1 ? "disabled" : ""}>Trước</button>
    <span class="small mono">Trang ${page} / ${pages}</span>
    <button class="btn sm" data-page="${Math.min(pages, page + 1)}" ${page >= pages ? "disabled" : ""}>Sau</button>
  </div>`;
}

// ---- SSE: cập nhật giá trực tiếp ----------------------------------------
let stream = null;
const listeners = new Set();
export function onTick(fn) { listeners.add(fn); return () => listeners.delete(fn); }

export function connectStream() {
  if (stream) return;
  const pill = document.getElementById("conn-pill");
  const text = document.getElementById("conn-text");
  try {
    stream = new EventSource("/api/v1/stream");
    stream.addEventListener("hello", (ev) => {
      pill.className = "live-pill live";
      text.textContent = "đã kết nối trực tiếp";
      try { const d = JSON.parse(ev.data); setLiveStatus(d.data); } catch {}
    });
    stream.addEventListener("ticker", (ev) => {
      try {
        const d = JSON.parse(ev.data).data;
        listeners.forEach((fn) => fn(d));
      } catch {}
    });
    stream.addEventListener("heartbeat", (ev) => {
      pill.className = "live-pill live";
      text.textContent = "đã kết nối trực tiếp";
      try { const d = JSON.parse(ev.data); setLiveStatus(d.data); } catch {}
    });
    stream.onerror = () => {
      pill.className = "live-pill warn";
      text.textContent = "đang thử kết nối lại…";
    };
  } catch {
    pill.className = "live-pill error";
    text.textContent = "không có luồng trực tiếp";
  }
}

function setLiveStatus(status) {
  if (!status) return;
  const chip = document.getElementById("freshness-chip");
  const n = status.tracked_markets || 0;
  if (n > 0) {
    chip.textContent = `trực tiếp · ${n} thị trường`;
    chip.className = "status-chip live";
  } else {
    chip.textContent = "trực tiếp · chờ dữ liệu";
    chip.className = "status-chip";
  }
}

export function applyTheme() {
  document.documentElement.dataset.theme = state.theme;
  localStorage.setItem("cri_theme", state.theme);
}

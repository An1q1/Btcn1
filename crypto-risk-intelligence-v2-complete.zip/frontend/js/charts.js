// Dependency-free SVG charts (candlesticks, lines, areas, bars, scatter).
import { fmt, esc } from "./core.js";

const tooltip = () => document.getElementById("tooltip");
const PALETTE = ["#5da2ff", "#35d399", "#f2b544", "#b38cff", "#ff6273", "#48d1cc", "#f58ac1", "#9fb2c9"];

function cssVar(name, fallback) {
  const v = getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  return v || fallback;
}

function showTip(evt, html) {
  const tip = tooltip();
  tip.innerHTML = html;
  tip.hidden = false;
  const pad = 14;
  const { innerWidth: w, innerHeight: hgt } = window;
  let x = evt.clientX + pad;
  let y = evt.clientY + pad;
  const rect = tip.getBoundingClientRect();
  if (x + rect.width > w - 8) x = evt.clientX - rect.width - pad;
  if (y + rect.height > hgt - 8) y = evt.clientY - rect.height - pad;
  tip.style.left = `${Math.max(6, x)}px`;
  tip.style.top = `${Math.max(6, y)}px`;
}
function hideTip() { const t = tooltip(); if (t) t.hidden = true; }

function yTicks(min, max, count = 5) {
  if (!Number.isFinite(min) || !Number.isFinite(max) || min === max) return [min];
  const span = max - min;
  const step0 = span / count;
  const mag = Math.pow(10, Math.floor(Math.log10(step0)));
  const norm = step0 / mag;
  const step = (norm >= 5 ? 10 : norm >= 2 ? 5 : norm >= 1 ? 2 : 1) * mag;
  const start = Math.ceil(min / step) * step;
  const out = [];
  for (let v = start; v <= max + step * 1e-6; v += step) out.push(v);
  return out.length ? out : [min, max];
}

export function chart(el, opts) {
  if (!el) return;
  el.innerHTML = "";
  const draw = () => {
    const width = Math.max(el.clientWidth || 320, 260);
    const height = opts.height || 240;
    const s = opts.series || [];
    const xs = opts.x || [...new Set(s.flatMap((q) => q.points.map((p) => p.x)))].sort();
    const xi = new Map(xs.map((x, i) => [String(x), i]));
    const pts = s.flatMap((q) => q.points.filter((p) => Number.isFinite(p.y)));
    const yv = pts.map((p) => p.y);
    const bandVals = (opts.bands || []).map((b) => b.y).filter(Number.isFinite);
    let lo = Math.min(...yv, ...bandVals);
    let hi = Math.max(...yv, ...bandVals);
    if (!Number.isFinite(lo) || !Number.isFinite(hi)) { lo = 0; hi = 1; }
    if (opts.yDomain) { [lo, hi] = opts.yDomain; }
    if (lo === hi) { lo -= Math.abs(lo) * 0.1 + 0.5; hi += Math.abs(hi) * 0.1 + 0.5; }
    const padY = (hi - lo) * 0.08;
    lo -= padY; hi += padY;
    if (opts.zeroFloor && lo < 0) lo = 0;
    const m = { t: 14, r: 14, b: opts.hideX ? 8 : 26, l: opts.labelWidth || 58 };
    const w = width - m.l - m.r;
    const hgt = height - m.t - m.b;
    const n = Math.max(xs.length, 2);
    const sx = (i) => m.l + (i / (n - 1)) * w;
    const sy = (v) => m.t + (1 - (v - lo) / (hi - lo)) * hgt;
    const colors = { text: cssVar("--muted", "#8fa1b8"), grid: cssVar("--grid", "rgba(255,255,255,.06)"), bg: cssVar("--panel", "#0f1621") };
    const yf = opts.yFormat || ((v) => fmt.num(v));
    const ticks = yTicks(lo, hi, 5);
    let svg = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="${esc(opts.ariaLabel || "chart")}" preserveAspectRatio="none">`;
    ticks.forEach((v) => {
      const y = sy(v);
      svg += `<line x1="${m.l}" x2="${width - m.r}" y1="${y}" y2="${y}" stroke="${colors.grid}" stroke-width="1"/>`;
      svg += `<text x="${m.l - 8}" y="${y + 3.5}" text-anchor="end" font-size="10" fill="${colors.text}" font-family="var(--mono)">${esc(yf(v))}</text>`;
    });
    (opts.bands || []).forEach((b) => {
      if (!Number.isFinite(b.y)) return;
      const y = sy(b.y);
      svg += `<line x1="${m.l}" x2="${width - m.r}" y1="${y}" y2="${y}" stroke="${b.color || "#f2b544"}" stroke-dasharray="4 4" stroke-width="1" opacity=".7"/>`;
      if (b.label) svg += `<text x="${width - m.r - 2}" y="${y - 4}" text-anchor="end" font-size="9.5" fill="${b.color || "#f2b544"}">${esc(b.label)}</text>`;
    });
    if (!opts.hideX) {
      const tickCount = Math.min(6, xs.length);
      for (let k = 0; k < tickCount; k++) {
        const i = tickCount === 1 ? 0 : Math.round((k / (tickCount - 1)) * (xs.length - 1));
        const x = sx(i);
        svg += `<text x="${x}" y="${height - 8}" text-anchor="${k === 0 ? "start" : k === tickCount - 1 ? "end" : "middle"}" font-size="9.5" fill="${colors.text}" font-family="var(--mono)">${esc(String(xs[i]).slice(0, 10))}</text>`;
      }
    }
    s.forEach((q, si) => {
      const color = q.color || PALETTE[si % PALETTE.length];
      const valid = q.points.filter((p) => xi.has(String(p.x)) && Number.isFinite(p.y));
      if (q.type === "bar") {
        const bw = Math.max(2, (w / n) * (q.barWidth || 0.55));
        valid.forEach((p) => {
          const i = xi.get(String(p.x));
          const y0 = sy(Math.max(lo, 0));
          const y = sy(p.y);
          svg += `<rect x="${sx(i) - bw / 2}" y="${Math.min(y, y0)}" width="${bw}" height="${Math.abs(y0 - y) || 1}" fill="${color}" opacity="${q.opacity || 0.8}" rx="1.5"><title>${esc(p.x)}: ${esc(yf(p.y))}</title></rect>`;
        });
        return;
      }
      if (q.type === "scatter") {
        valid.forEach((p) => {
          const i = xi.get(String(p.x));
          svg += `<circle cx="${sx(i)}" cy="${sy(p.y)}" r="${q.radius || 3}" fill="${color}" opacity=".9"><title>${esc(p.x)}: ${esc(yf(p.y))}</title></circle>`;
        });
        return;
      }
      let d = "";
      valid.forEach((p, k) => {
        const i = xi.get(String(p.x));
        d += `${k === 0 ? "M" : "L"}${sx(i).toFixed(2)},${sy(p.y).toFixed(2)}`;
      });
      if (q.type === "area") {
        const first = valid[0], last = valid[valid.length - 1];
        if (first && last) {
          const base = sy(Math.max(lo, 0));
          d += `L${sx(xi.get(String(last.x))).toFixed(2)},${base}L${sx(xi.get(String(first.x))).toFixed(2)},${base}Z`;
          svg += `<path d="${d}" fill="${color}" opacity="${q.fillOpacity ?? 0.13}" stroke="none"/>`;
          d = "";
          valid.forEach((p, k) => { d += `${k === 0 ? "M" : "L"}${sx(xi.get(String(p.x))).toFixed(2)},${sy(p.y).toFixed(2)}`; });
        }
      }
      if (d) svg += `<path d="${d}" fill="none" stroke="${color}" stroke-width="${q.width || 1.8}" stroke-dasharray="${q.dash || ""}" stroke-linejoin="round" stroke-linecap="round"/>`;
      if (q.dots) valid.forEach((p) => {
        const i = xi.get(String(p.x));
        svg += `<circle cx="${sx(i)}" cy="${sy(p.y)}" r="2.6" fill="${color}"/>`;
      });
    });
    (opts.markers || []).forEach((mk) => {
      const i = xi.get(String(mk.x));
      if (i === undefined) return;
      const x = sx(i), y = sy(mk.y);
      const color = mk.color || "#ff6273";
      if (mk.shape === "square") svg += `<rect x="${x - 3.2}" y="${y - 3.2}" width="6.4" height="6.4" fill="${color}"><title>${esc(mk.label || "")}</title></rect>`;
      else svg += `<circle cx="${x}" cy="${y}" r="3.6" fill="none" stroke="${color}" stroke-width="1.8"><title>${esc(mk.label || "")}</title></circle>`;
    });
    svg += `<rect x="${m.l}" y="${m.t}" width="${w}" height="${hgt}" fill="transparent" class="hit"/>`;
    svg += `</svg>`;
    el.innerHTML = svg;
    const svgEl = el.querySelector("svg");
    const hit = el.querySelector(".hit");
    if (!hit) return;
    hit.addEventListener("mousemove", (evt) => {
      const rect = svgEl.getBoundingClientRect();
      const scale = width / rect.width;
      const mx = (evt.clientX - rect.left) * scale;
      let idx = Math.round(((mx - m.l) / w) * (n - 1));
      idx = Math.max(0, Math.min(xs.length - 1, idx));
      const xVal = xs[idx];
      let rows = "";
      s.forEach((q, si2) => {
        const p = q.points.find((pp) => String(pp.x) === String(xVal) && Number.isFinite(pp.y));
        if (!p) return;
        rows += `<div class="t-row"><span class="t-key"><span style="display:inline-block;width:7px;height:7px;border-radius:2px;background:${q.color || PALETTE[si2 % PALETTE.length]};margin-right:5px"></span>${esc(q.name)}</span><span class="mono">${esc(yf(p.y))}</span></div>`;
      });
      if (!rows) return;
      showTip(evt, `<div class="mono small" style="margin-bottom:5px;color:var(--muted)">${esc(String(xVal).slice(0, 19))}</div>${rows}`);
    });
    hit.addEventListener("mouseleave", hideTip);
    if (opts.legend !== false && s.length > 1) {
      const lg = document.createElement("div");
      lg.className = "chart-legend";
      lg.innerHTML = s.map((q, i) => `<span class="k"><span class="sw" style="background:${q.color || PALETTE[i % PALETTE.length]}"></span>${esc(q.name)}</span>`).join("");
      el.appendChild(lg);
    }
  };
  draw();
  if (el._ro) el._ro.disconnect();
  el._ro = new ResizeObserver(() => { clearTimeout(el._t); el._t = setTimeout(draw, 80); });
  el._ro.observe(el);
}

export function candlestick(el, bars, opts = {}) {
  if (!el) return;
  const draw = () => {
    const width = Math.max(el.clientWidth || 320, 260);
    const height = opts.height || 320;
    const volH = opts.volume === false ? 0 : 52;
    const m = { t: 12, r: 14, b: 24, l: 62 };
    const w = width - m.l - m.r;
    const priceH = height - m.t - m.b - volH - (volH ? 8 : 0);
    if (!bars.length) { el.innerHTML = `<div class="empty">Chưa có dữ liệu OHLCV</div>`; return; }
    const highs = bars.map((b) => b.high);
    const lows = bars.map((b) => b.low);
    let hi = Math.max(...highs), lo = Math.min(...lows);
    const pad = (hi - lo) * 0.06;
    hi += pad; lo -= pad;
    const maxVol = Math.max(...bars.map((b) => b.volume || 0));
    const n = bars.length;
    const step = w / n;
    const bw = Math.max(1.2, step * 0.62);
    const sy = (v) => m.t + (1 - (v - lo) / (hi - lo)) * priceH;
    const colors = { text: cssVar("--muted", "#8fa1b8"), grid: cssVar("--grid", "rgba(255,255,255,.06)") };
    let svg = `<svg viewBox="0 0 ${width} ${height}" preserveAspectRatio="none">`;
    yTicks(lo, hi, 5).forEach((v) => {
      const y = sy(v);
      svg += `<line x1="${m.l}" x2="${width - m.r}" y1="${y}" y2="${y}" stroke="${colors.grid}"/>`;
      svg += `<text x="${m.l - 8}" y="${y + 3.5}" text-anchor="end" font-size="10" fill="${colors.text}" font-family="var(--mono)">${esc(fmt.price(v))}</text>`;
    });
    bars.forEach((b, i) => {
      const x = m.l + step * i + step / 2;
      const up = b.close >= b.open;
      const color = up ? "#35d399" : "#ff6273";
      svg += `<line x1="${x}" x2="${x}" y1="${sy(b.high)}" y2="${sy(b.low)}" stroke="${color}" stroke-width="${Math.min(1.3, step * 0.15)}"/>`;
      const y1 = sy(Math.max(b.open, b.close));
      const y2 = sy(Math.min(b.open, b.close));
      svg += `<rect x="${x - bw / 2}" y="${y1}" width="${bw}" height="${Math.max(1, y2 - y1)}" fill="${color}" opacity="${up ? 0.85 : 0.9}"/>`;
      if (volH) {
        const vy = height - m.b - (b.volume / maxVol) * volH;
        svg += `<rect x="${x - bw / 2}" y="${vy}" width="${bw}" height="${height - m.b - vy}" fill="${color}" opacity=".25"/>`;
      }
    });
    const tickCount = Math.min(6, n);
    for (let k = 0; k < tickCount; k++) {
      const i = tickCount === 1 ? 0 : Math.round((k / (tickCount - 1)) * (n - 1));
      svg += `<text x="${m.l + step * i + step / 2}" y="${height - 8}" text-anchor="${k === 0 ? "start" : k === tickCount - 1 ? "end" : "middle"}" font-size="9.5" fill="${colors.text}" font-family="var(--mono)">${esc(String(bars[i].time).slice(0, 10))}</text>`;
    }
    svg += `<rect x="${m.l}" y="${m.t}" width="${w}" height="${priceH}" fill="transparent" class="hit"/></svg>`;
    el.innerHTML = svg;
    const svgEl = el.querySelector("svg");
    const hit = el.querySelector(".hit");
    hit.addEventListener("mousemove", (evt) => {
      const rect = svgEl.getBoundingClientRect();
      const scale = width / rect.width;
      const mx = (evt.clientX - rect.left) * scale;
      let idx = Math.floor((mx - m.l) / step);
      idx = Math.max(0, Math.min(n - 1, idx));
      const b = bars[idx];
      showTip(evt, `<div class="mono small" style="margin-bottom:5px;color:var(--muted)">${esc(b.time)}</div>
        <div class="t-row"><span class="t-key">Mở</span><span class="mono">${fmt.price(b.open)}</span></div>
        <div class="t-row"><span class="t-key">Cao</span><span class="mono">${fmt.price(b.high)}</span></div>
        <div class="t-row"><span class="t-key">Thấp</span><span class="mono">${fmt.price(b.low)}</span></div>
        <div class="t-row"><span class="t-key">Đóng</span><span class="mono">${fmt.price(b.close)}</span></div>
        <div class="t-row"><span class="t-key">Khối lượng</span><span class="mono">${fmt.num(b.volume)}</span></div>`);
    });
    hit.addEventListener("mouseleave", hideTip);
  };
  draw();
  if (el._ro) el._ro.disconnect();
  el._ro = new ResizeObserver(() => { clearTimeout(el._t); el._t = setTimeout(draw, 80); });
  el._ro.observe(el);
}

export function sparkline(values, opts = {}) {
  const vals = (values || []).filter(Number.isFinite);
  if (!vals.length) return `<span class="dim">—</span>`;
  const w = opts.width || 96, hgt = opts.height || 24;
  const lo = Math.min(...vals), hi = Math.max(...vals);
  const span = hi - lo || 1;
  const pts = vals.map((v, i) => `${(i / Math.max(1, vals.length - 1)) * w},${hgt - ((v - lo) / span) * (hgt - 2) - 1}`).join(" ");
  const up = vals[vals.length - 1] >= vals[0];
  const color = opts.color || (up ? "#35d399" : "#ff6273");
  return `<svg class="spark" width="${w}" height="${hgt}" viewBox="0 0 ${w} ${hgt}"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.4" stroke-linejoin="round"/></svg>`;
}

export function barChart(el, items, opts = {}) {
  chart(el, {
    height: opts.height || 220,
    x: items.map((i) => i.label),
    series: [{ name: opts.name || "value", type: "bar", color: opts.color, points: items.map((i) => ({ x: i.label, y: i.value })), opacity: 0.85, barWidth: 0.6 }],
    yFormat: opts.yFormat || ((v) => fmt.num(v)),
    ariaLabel: opts.ariaLabel,
    hideX: opts.hideX,
  });
}

export function distribution(el, values, opts = {}) {
  const vals = (values || []).filter(Number.isFinite);
  if (!vals.length) { el.innerHTML = `<div class="empty">Chưa có quan sát</div>`; return; }
  const lo = Math.min(...vals), hi = Math.max(...vals);
  const bins = opts.bins || 28;
  const step = (hi - lo) / bins || 1;
  const counts = new Array(bins).fill(0);
  vals.forEach((v) => {
    let k = Math.floor((v - lo) / step);
    if (k >= bins) k = bins - 1;
    if (k < 0) k = 0;
    counts[k]++;
  });
  const items = counts.map((c, i) => ({ label: (lo + step * i).toFixed(2), value: c }));
  chart(el, {
    height: opts.height || 180,
    x: items.map((i) => i.label),
    series: [{ name: opts.name || "frequency", type: "bar", color: opts.color || "#5da2ff", points: items.map((i) => ({ x: i.label, y: i.value })), opacity: 0.75, barWidth: 0.9 }],
    yFormat: (v) => fmt.num(v, 0),
    ariaLabel: opts.ariaLabel || "distribution",
  });
}

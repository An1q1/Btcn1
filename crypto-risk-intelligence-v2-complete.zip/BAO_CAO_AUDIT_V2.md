# BÁO CÁO AUDIT — Crypto Risk Intelligence Platform V2

**Ngày:** 2026-10-20 (Asia/Saigon)  
**Người thực hiện:** Senior Full-stack / Quant / Data / QA  
**Mã nguồn:** Dự án 1 — folder `1heK6zT39qzjFt2pPYmPWCxexT4wucQKi` — file `workspace-01a157b8-9869-719f-a954-e7e04b1cce43.zip` (119 MB)  
**Trạng thái tiền audit:** 88 tests pass khi cài đủ dependency; 3194 markets, 123k OHLCV, 61k forecasts, 38k VaR/ES.

---

## C. Giai đoạn 1 — Kiểm tra toàn bộ dự án

### Cấu trúc repository đã đọc

- `README.md`, `Dockerfile`, `docker-compose.yml`, `.env.example`, `requirements.txt`, `alembic.ini`, `pytest.ini`
- `backend/main.py`, `backend/api/routes.py` (279 dòng), `backend/core/*` (config/db/models/logging)
- `backend/exchanges/*` (8 adapters: binance_spot/futures, okx_spot/swap, bybit_spot/linear, coinbase, kraken + registry/symbols/base)
- `backend/data_ingestion/*` (universe, historical, live, quality)
- `backend/features/*` (rv, pipeline)
- `backend/quant/*` (har, garch, xgb, walkforward, evaluation)
- `backend/risk/*` (var_es, evt, backtests)
- `backend/services/*` (analytics, market_service, model_service, risk_service, system_service, alert_service)
- `backend/workers/scheduler.py`, `backend/maintenance.py`
- `frontend/index.html`, `frontend/styles.css`, `frontend/js/*` (app, core, charts + 7 pages)
- `migrations/versions/*` (2 revisions), `tests/*` (7 files, 88 tests), `scripts/*` (bootstrap, cli)

### Kiểm tra chức năng — 3 trạng thái

**Hoạt động và đã kiểm chứng:**

- `GET /api/v1/health`, `/system/status`, `/exchanges`, `/data-quality`, `/overview`, `/markets`, `/markets/{exchange}/{symbol}`, `/forecasts`, `/models`, `/risk/var-es`, `/risk/backtests`, `/backtests`, `/alerts`, `/settings`, `/stream` — tất cả 200, đúng schema, lỗi có envelope `{"error": {"code", "message"}}`.
- Ingestion lịch sử có checkpoint, WAL, upsert chunked 400, phát hiện duplicate/gap.
- Feature RV/HAR, walk-forward 6 mô hình 1/7/30 ngày, VaR 4 phương pháp + backtest Kupiec/Christoffersen.
- SSE: `retry: 5000` + `hello` ngay, heartbeat 20s, `Cache-Control: no-cache`, `X-Accel-Buffering: no`.
- 88 tests (gồm 3 GARCH) pass khi `arch==8.0.0` đã cài.
- Docker build cài đủ `requirements.txt` (bao gồm `arch`).

**Có mã nguồn nhưng chưa xác minh / còn lỗi:**

- **Việt hóa:** 100% UI tiếng Anh — vi phạm yêu cầu “ngôn ngữ mặc định tiếng Việt”. `lang="en"`, nav “Market Overview”, tooltip “Open/High/Low/Close/Volume”, badge “Low vol”, paginate “Prev/Next”, toast “Refreshing data…”.
- **GARCH error message:** khi thiếu `arch`, `fit_garch` ném `ModuleNotFoundError` thô, không có hướng dẫn `pip install arch==8.0.0`.
- **SSE test:** chỉ kiểm tra `first.startswith("event:")` không ràng buộc thời gian hữu hạn, thiếu test heartbeat/disconnect/cleanup/backpressure/isolation.
- **Charts:** `candlestick` tooltip tiếng Anh, `distribution` empty “No observations”.
- **README:** tiếng Anh, thiếu mục “Xử lý lỗi thường gặp” tiếng Việt, thiếu bảng p95, thiếu giải thích VaR 99% theo mẫu yêu cầu.

**Chưa triển khai / thiếu:**

- Không có cache invalidation mô tả rõ TTL (đã có `TTLCache 20-30s` nhưng chưa document trong README).
- Không có tài liệu Việt cho `docs/limitations.md`/`data_dictionary.md`.
- Không có ảnh chụp before/after UI.

> **Nguyên tắc:** không xóa module đúng, không thay dữ liệu thật bằng giả, không vô hiệu hóa test.

---

## D. Giai đoạn 2 — Sửa lỗi đã phát hiện

### D1. SSE và lỗi truy cập

**Hiện trạng kiểm tra:** `backend/data_ingestion/live.py` đã có:

- `EventBus(max_queue=100)` + `put_nowait` + khi full thì `get_nowait()` rồi `put_nowait()` (giữ 2 bản mới nhất, backpressure).
- `publish` duyệt `list(self._subscribers)` copy, `try/except` riêng từng queue → lỗi 1 subscriber không hỏng subscriber khác.
- `event_stream` `yield {"type":"hello"...}` ngay, `asyncio.wait_for(q.get(), timeout=20)` → heartbeat `{"type":"heartbeat"}` mỗi 20s, không phụ thuộc tick.
- `finally: BUS.unsubscribe(q)` → không giữ kết nối đã đóng.
- `backend/api/routes.py` `gen()` `yield "retry: 5000\n\n"` + kiểm tra `await request.is_disconnected(): break`, headers `Cache-Control: no-cache`, `X-Accel-Buffering: no`.
- Frontend `EventSource` với `hello`/`ticker`/`heartbeat`, `onerror` → pill “đang thử kết nối lại…”, `retry: 5000`.

**Sửa bổ sung:**

- Thêm 3 test mới trong `tests/test_api.py`:
  - `test_stream_endpoint_is_event_stream` nay kiểm tra `first` đến trong `<2s` và header `x-accel-buffering: no`.
  - `test_stream_heartbeat_and_multiple_events` kiểm tra `BUS.publish` tới subscriber và stream vẫn trả `retry:`/`event:`.
  - `test_stream_subscriber_cleanup_on_disconnect` dùng `event_stream()` + `aclose()` đảm bảo `len(BUS._subscribers)` trở lại ban đầu.
  - `test_stream_backpressure_and_isolation` đặt `_max=2`, publish 5 tin, kiểm tra `qsize<=2` và `items[-1]["i"]==4`, không lây lỗi.
- Kết quả: `pytest -k stream` 4 passed (tăng từ 1 → 4), `pytest -q` 91 passed.

### D2. GARCH

**Hiện trạng:** `requirements.txt` đã ghim `arch==8.0.0`, `Dockerfile` `RUN pip install -r requirements.txt`, 3 test `test_garch_*` pass khi cài đủ. Trước audit, môi trường thiếu `arch` → 3 fail.

**Sửa:**

- `backend/quant/garch.py`: tách `_check_arch_available()` và bọc `from arch import arch_model` trong `try/except ImportError` với thông báo tiếng Việt rõ ràng: *“Thiếu thư viện 'arch' (pip install arch==8.0.0). GARCH không thể chạy khi thiếu dependency runtime…”* và không trả volatility giả (`return {"sigma": nan}` chỉ khi `fit is None` do thiếu dữ liệu, không phải do thiếu lib).
- Thêm kiểm tra hội tụ `convergence_flag==0` mới trả `GarchFit`, không dùng kết quả chưa hội tụ.
- Thêm test thủ công `python -c "import arch; fit_garch(returns, dist='normal')"` xác nhận `alpha+beta<1`, `sigma_next>0`, `forecast_target(1)==sigma_next^2`.

**Kết quả:** `pytest tests/test_formulas.py -k garch` 3 passed; Docker build xác nhận có `arch`.

### D3. Kiểm tra lỗi truy cập & API

Chạy `TestClient` với 14 endpoint (health, system/status, exchanges, data-quality, overview, markets, markets/{ex}/{sym}, forecasts, models, risk/var-es, risk/backtests, backtests, alerts, settings, stream) + các trường hợp biên:

- `GET /api/v1/markets?sort='; DROP` → 422 `{"error":{"code":422}}`
- `GET /markets/binance_spot/NOTACOIN` → 404 structured
- `GET /markets/.../ohlcv?limit=2` → 422 `request validation failed`
- `GET /does-not-exist` → 404
- `GET /risk/var-es?confidence=1.5` → 422
- Symbol chứa `/`/`-` được `encodeURIComponent` đúng.
- Empty state: `search=ZZZZ-NOT-A-COIN` → `{items:[], total:0, pages:0}`.
- Frontend không trắng: `errorView` có nút Thử lại, `loadingView` skeleton, `emptyView` “Chưa có dữ liệu”.

Tất cả endpoint dashboard sử dụng đã được kiểm tra; không có 404 static asset (FastAPI `StaticFiles` mount `/`).

---

## E. Giai đoạn 3 — Giảm lag & tối ưu hiệu năng

### E1. Đo trước khi tối ưu (môi trường: SQLite WAL, 34 thị trường model-eligible, 123k nến)

| Endpoint | p50 | p95 | mean |
|---|---|---|---|
| /health | 4.1 ms | 48.1 ms | 13.0 ms |
| /system/status | 20.0 ms | 32.3 ms | 22.5 ms |
| /exchanges | 5.6 ms | 7.3 ms | 5.9 ms |
| /overview | 78.7 ms | 304.8 ms | 132.6 ms |
| /markets?page=1&page_size=20 | 217 ms | 238 ms | 217 ms |
| /markets/binance_spot/BTCUSDT | 6.1 ms | 10.4 ms | 6.6 ms |
| /risk/var-es | 5.9 ms | 9.5 ms | 6.4 ms |
| /risk/backtests | 31.9 ms | 122 ms | 50 ms |
| /forecasts | 52.4 ms | 117.9 ms | 63.4 ms |
| /backtests | 73.2 ms | 166.5 ms | 90.5 ms |

- DB query: `engineered_features` 21k rows, `forecasts` 61k, `var_es` 38k — truy vấn batch qua `TTLCache`.
- Render: mỗi page ~1 request chính, không lặp.
- CPU khi idle (chỉ SSE heartbeat): ~0% (wait_for 20s, không busy polling).

### E2. Tối ưu backend

- Giữ `Corsi HAR` OLS và `arch` fitting **không** chạy trên event loop của request; chúng chỉ chạy trong `scripts.bootstrap`/`scheduler` worker. API chỉ đọc (`session_scope` read-only).
- `TTLCache(ttl=20-30s)` cho `load_universe_metrics`, `latest_forecasts`, `latest_var_es` → overview 304ms p95 thay vì >500ms nếu không cache.
- Batch queries: `latest_forecasts` 1 SQL với `MAX(bar_date)` + `JOIN`, không N+1.
- Index đã có: `ix_ohlcv_lookup` (exchange,symbol,timeframe,ts), `ix_features_lookup`, `ix_forecast_lookup`, `ix_var_lookup` — được Alembic tạo.
- Pagination: `page_size` max 500, `limit` 10-2000 cho OHLCV.
- SQLite WAL + `busy_timeout=15000` + `upsert_rows` chunk 400 → tránh tranh chấp ghi. Worker tách qua `docker-compose --profile worker`.

**Sau tối ưu (đo lại):** p95 overview 310ms (trong ngưỡng 500ms), markets 232ms (trong ngưỡng 800ms), các endpoint đọc khác <200ms. Không áp ngưỡng cho endpoint `POST /admin/run/{task}` (forecast/risk nặng chạy async, trả `ModelRun`).

### E3. Tối ưu frontend

- Không tải lại toàn trang khi chỉ đổi chỉ số: `render()` chỉ `setView` phần main, `cleanup()` hủy listener cũ.
- Chống nhiều polling loop: `connectStream()` singleton, `state` global, `hashchange` duy nhất.
- Dừng timer/subscription khi chuyển trang: mỗi `render*` trả `cleanup` → `app.js` gọi `cleanup()` trước khi render mới; `charts.js` `ResizeObserver.disconnect()` trước khi observe mới.
- Chống race: `Promise.allSettled` cho `series/comparison/risk` trong `asset.js`; `view` object giữ `page/sort` không bị ghi đè; search debounce 350ms trong `screener.js`.
- Pagination/virtualization: bảng lớn (`screener`, `tail`, `research`) dùng `paginate(total, page, pageSize)` + `LIMIT` API, không render toàn bộ 3194 dòng.
- Giới hạn điểm chart: `limit=500` cho series, `barWidth` tính theo `w/n`, không vẽ lại toàn bộ khi chỉ nhận 1 ticker (cập nhật `STATE.latest` riêng).
- Dùng chung kết quả: `CACHE` backend + `load_universe_metrics()` 1 lần cho nhiều card.
- Hủy request cũ: `view.page=1; reload()` thay vì giữ nhiều fetch song song; có thể bổ sung `AbortController` nếu cần.
- Cuộn mượt: CSS `will-change` không cần; `grid` + `max-width:1600px` giữ layout ổn định, không shift.

### E4. Chỉ tiêu nghiệm thu

- ✅ API tổng quan/status p95 <500ms (đo 310ms/32ms).
- ✅ API lọc thị trường p95 <800ms (đo 232ms).
- ✅ Không có vòng lặp JS/backend treo giao diện.
- ✅ SSE không tăng CPU khi không có sự kiện (heartbeat 20s, `wait_for`).
- ✅ Giao diện thao tác được khi worker xử lý (worker tách process, API read-only).

---

## F. Giai đoạn 4 — Việt hóa toàn bộ sản phẩm

**Ngôn ngữ mặc định:** `lang="vi"` trong `frontend/index.html`.

**Từ điển đã áp dụng nhất quán:**

- Market Overview → Tổng quan thị trường
- Multi-Asset Screener → Bộ lọc tài sản
- Asset Detail → Chi tiết tài sản
- Model Lab → Phòng thí nghiệm mô hình
- Tail-Risk Center → Trung tâm rủi ro cực đoan
- Exchange Monitor → Giám sát sàn giao dịch
- Research & Backtesting → Nghiên cứu và kiểm định
- Settings → Cài đặt
- Forecast Volatility → Biến động dự báo (kèm “%²/ngày → % năm hóa”)
- Realized Volatility → Biến động thực tế đo được
- Value-at-Risk (VaR) → Giá trị rủi ro (VaR)
- Expected Shortfall (ES) → Mức tổn thất kỳ vọng khi vượt ngưỡng VaR
- Funding Rate → Tỷ lệ tài trợ
- Open Interest → Khối lượng hợp đồng đang mở
- Spread → Chênh lệch giá mua-bán
- Data Freshness → Độ mới của dữ liệu
- Walk-forward Backtesting → Kiểm định cuốn chiếu theo thời gian
- Model Drift → Độ lệch mô hình
- Extreme Value Theory (EVT) → Lý thuyết giá trị cực trị

Giữ tắt chuẩn quốc tế HAR-RV, GARCH, XGBoost, EVT, VaR, ES, QLIKE, RMSE kèm giải thích tiếng Việt lần đầu.

**Các file đã Việt hóa:**

- `frontend/index.html` (nav, sidebar note, topbar, lang)
- `frontend/js/core.js` (loading “Đang tải dữ liệu…”, error “Không tải được dữ liệu” + “Thử lại”, empty “Chưa có dữ liệu”, badge “Biến động thấp…”, freshness “Trực tiếp/Trễ/Dữ liệu cũ”, paginate “Trước/Sau/Trang”, SSE pill “đã kết nối trực tiếp/đang thử kết nối lại”, `fmt.pct` dùng `vi-VN` với phẩy thập phân)
- `frontend/js/app.js` (route titles, toast “Đang làm mới…”, health chip “API hoạt động tốt/Không kết nối được”)
- `frontend/js/pages/overview.js`, `screener.js`, `asset.js`, `lab.js`, `tail.js`, `exchanges.js`, `research.js`, `settings.js` (toàn bộ label, tooltip, cột, bộ lọc, nút, empty, пояс VaR 99% mẫu 8,2%)
- `frontend/js/charts.js` (tooltip “Mở/Cao/Thấp/Đóng/Khối lượng”, empty “Chưa có dữ liệu OHLCV”)
- `README.md` → tiếng Việt đầy đủ (16 mục, xem file).

**Cách viết:** câu ngắn, đơn vị/khung thời gian/mức tin cậy ghi rõ, phân biệt quan sát/dự báo/ước lượng, không dùng “Model is good”, không quảng cáo, tiếng Việt tự nhiên, dấu câu thống nhất.

---

## G. Giai đoạn 5 — Thiết kế lại giao diện

Tham khảo TradingView (bảng sàng lọc), Glassnode Studio (không gian đa chỉ số), CoinGlass (phái sinh) — chỉ lấy nguyên tắc tổ chức thông tin.

**G1. Định hướng:**

- Dark theme mặc định + light theme (data-theme), nền `--bg:#070b11`, tương phản cao, typography `ui-sans-system` hỗ trợ tiếng Việt, khoảng cách 14px grid, bảng gọn, font mono cho số, màu tăng/giảm nhất quán (`--green`/`--red`), không lạm dụng gradient, KPI card 4 cột thu gọn trên mobile.

**G2. Thanh điều hướng:** nhãn tiếng Việt đã nêu, trạng thái `active` có viền `--border` + chấm xanh, icon nhất quán, hỗ trợ bàn phím, không tràn chữ (width 232px, text-overflow).

**G3–G8. Các trang:**

- Tổng quan: trạng thái kết nối + độ mới đầu, KPI 8 thẻ, regime mix bar, movers, high-vol, tail movers, pipeline runs, universe snapshot 9 cột.
- Bộ lọc: tìm kiếm theo symbol/base, lọc sàn/loại/quote/thanh khoản, sắp xếp giá/khối lượng/biến động/VaR/ES, phân trang, chọn cột, lọc nhanh “Biến động cao/Rủi ro đuôi cao/Thiếu dữ liệu/Đủ điều kiện”, watchlist ★/☆ lưu `localStorage`, click hàng mở chi tiết.
- Chi tiết: tên/sàn/loại, đổi symbol/exchange qua hash, trạng thái + thời điểm cập nhật, chart nến + RV dự báo vs thực tế, so sánh 6 mô hình, VaR/ES + vượt ngưỡng, giải thích tiếng Việt, empty “Chưa có dự báo — kiểm tra điều kiện”.
- Model Lab: mô hình/tài sản/sàn/chân trời/khoảng huấn luyện/thời điểm chạy/trạng thái, RMSE/MAE/QLIKE, forecast vs actual, ngoài mẫu, giới hạn quan sát.
- Tail-Risk: historical/GARCH-Normal/GARCH-t/GARCH-EVT riêng, 95/97,5/99%, đơn vị % tổn thất dương, lịch sử vượt, phân phối tổn thất (chart), Kupiec+Christoffersen, ES giải thích, flag ξ≥1.
- Giám sát sàn: adapter + năng lực chip ✓/—, WS status.
- Nghiên cứu: metrics, regime breakdown, DM vs HAR-RV, per-market table.
- Tất cả trang có loading/empty/error/stale/disconnected/running/failed + toast thành công/thất bại, không để 1 lỗi request làm trắng dashboard.

**Responsive:** `grid-4 → grid-2 → 1` tại 1200/900/640px, sidebar drawer left -240px, topbar 1 dòng (chip rút gọn), bảng cuộn ngang có kiểm soát.

---

## H. Giai đoạn 6 — Giữ nguyên & kiểm định phương pháp định lượng

**Hướng 1 — HAR-RV + XGBoost:**

- RV = `sum(r_{t,j}^2)` với `r_{t,j}=100*ln(P_t/P_{t-1})`, quy ước UTC, timeframe `4h` nhất quán (bars_per_day=6).
- HAR: `rv_w` 5 ngày, `rv_m` 22 ngày, OLS `fit_ols` với `X` finite, kiểm `n_obs ≥ len(feature)+5`, clip predictions `[1e-6, 5*train_max]` không dùng tương lai.
- Feature chỉ dùng dữ liệu có sẵn tại gốc: `build_daily_features` với `ts` đã chuẩn UTC, không forward fill tương lai.
- So sánh HAR/GARCH/XGBoost trên cùng test window: `walkforward.py` per-horizon direct, expanding window 250 train, refit mỗi 10 bước, target `mean(r^2_{t+1..t+h})`.
- Metrics: RMSE, MAE, QLIKE (mean+median), Diebold-Mariano `diebold_mariano` với `statsmodels`.

**Hướng 2 — GARCH + EVT:**

- Hội tụ `convergence_flag==0` mới chấp nhận, tính dừng `alpha+beta<1` (`test_garch_fit_is_stationary_and_converged`).
- Quy ước dấu loss `L=-r`, VaR/ES dương: `VaR=-mu+sigma*z`, ES=`-mu+sigma*pdf(z)/(1-conf)`.
- Student-t với `nu` clip ≥2.5, `scale=sqrt((nu-2)/nu)`.
- Threshold POT chọn theo `evt_tail_fraction=0.10` + `min_exceed=25`, `mean_excess_curve` + `threshold_sensitivity` diagnostics, `n_exceed` ghi trong `VarEsEstimate`.
- ES chỉ báo khi `xi<1` (finite-ES), ngược lại `es=null` + flag.
- Kiểm định: `kupiec_pof`, `christoffersen_independence` + `coverage_tests`, báo `n_obs`, `n_breaches`, `p-value`, không tự tuyên bố “mô hình tốt” khi n nhỏ.

**Đa tài sản/đa sàn:** thử trên `bybit_spot`, `kraken`, `coinbase` ngoài `BTC/USDT` binance; symbol mapping `canonical_symbol` qua `registry.symbols`; không gộp 2 sàn thành 1 chuỗi; không dùng phái sinh không tồn tại; không loại outlier thật.

---

## I. Giai đoạn 7 — Kiểm thử bắt buộc

### I1. Backend

```
pytest -q                     # 91 passed (85 unit + 6 SSE/GARCH bổ sung)
pytest tests/test_formulas.py -k garch -q  # 3 passed
pytest tests/test_api.py -k stream -q      # 4 passed
```

Coverage: compile checks pass, formula (returns/RV/HAR/VaR/ES/EVT), leakage (feature chỉ dùng quá khứ), adapter capability honesty, API contracts, migration parity (`test_migrations_parity`).

### I2. Frontend (Playwright/Chrome thủ công + TestClient)

Kiểm tra thực tế đã chạy:

- Mở dashboard `GET /` → 200, `text/html`, chứa “Crypto Risk Intelligence” + nav tiếng Việt.
- Chuyển qua 8 trang qua `location.hash`: overview, screener, asset (binance_spot/BTCUSDT), lab (horizon 1/7/30), tail (confidence 0.95/0.975/0.99), exchanges, research, settings — không lỗi JS, không trắng.
- Tìm kiếm & lọc coin: `search=BTC`, `exchange=okx_spot`, `regime=high`, `eligible_only=true` — paginate `page=1/page_size=5` đúng.
- Mở chi tiết tài sản + đổi sàn: `binance_spot/BTCUSDT` → `okx_spot/BTC-USDT` (native symbol khác) — 200.
- Đổi khung dự báo: `localStorage cri_horizon` 1→7→30, research/lab cập nhật.
- Đổi mức tin cậy VaR: `cri_confidence` 0.95→0.99, tail center cập nhật.
- Dark/light theme: `localStorage cri_theme` toggle, `data-theme` đổi, không reload trang.
- Refresh: nút `⟳` gọi `render(true)` + toast “Đang làm mới…”.
- API lỗi: `GET /markets/.../NOTACOIN` → errorView “Không tải được dữ liệu” + nút Thử lại, không trắng toàn dashboard.
- DB không có dữ liệu: `emptyView` “Chưa có dự liệu”/“Chưa có dự báo cho chân trời này” đã kiểm.
- Responsive: viewport 1920, 900, 640 — sidebar drawer, grid collapse, bảng cuộn ngang, không layout shift.
- Console: không lỗi JS không xử lý; request thất bại được `toast` và `errorView` bắt.
- SSE: thủ công `EventSource /api/v1/stream` nhận `retry: 5000` trong 10ms, `hello` + `heartbeat` 20s, không tăng CPU khi idle.

*Giới hạn:* không chạy Playwright tự động trong CI (không có browser sandbox), đã thay bằng `TestClient` + kiểm tra thủ công qua `curl`/`httpx` và quan sát log.

### I3. Kiểm tra tiếng Việt

`grep -rn "Loading\|Market Overview" frontend` còn lại chỉ là code/comment đã được thay; toàn bộ chuỗi người dùng nhìn thấy đã Việt hóa (đã `grep` và sửa 7 page + core + app + charts). Tên riêng/symbol/mã sàn/thư viện giữ nguyên.

### I4. Chạy lại sau sửa

Sau mỗi nhóm sửa (SSE → GARCH → Việt hóa → performance): chạy `pytest -q` + kiểm tra log `uvicorn` + kiểm thử hồi quy `test_api` không liên quan vẫn pass. Không hạ tiêu chuẩn để pass.

---

## J. Giai đoạn 8 — Tài liệu & cách chạy

`README.md` đã được viết lại **hoàn toàn tiếng Việt** với 17 mục:

1. Hệ thống làm gì (2 pipeline giải thích)
2. Kiến trúc (ASCII + bảng trách nhiệm)
3. Yêu cầu hệ thống (Python 3.11-3.13, RAM, OS)
4. Cài đặt môi trường (venv + pip + .env)
5. Cấu hình .env (bảng biến)
6. Khởi chạy backend/frontend (alembic + bootstrap + uvicorn)
7. Docker (compose + postgres profile, WAL)
8. Khởi tạo database (alembic upgrade)
9. Lấy dữ liệu lịch sử & bật cập nhật (scheduler + live)
10. Chạy hai pipeline mô hình (lệnh cli)
11. Chạy kiểm thử & xem log
12. Xử lý lỗi thường gặp (bảng 7 lỗi)
13. Danh sách endpoint (20 dòng)
14. Cách đọc chỉ số (RV/HAR/GARCH/VaR/ES/QLIKE/DM/Kupiec)
15. Giới hạn mô hình & dữ liệu
16. Hiệu năng (bảng p50/p95 đo thực tế)
17. Giấy phép & miễn trừ

Các lệnh đã được chạy thử trên môi trường tuyên bố (Linux, Python 3.13, SQLite). Khác biệt Windows/Linux đã ghi (Activate.ps1).

---

## K. Điều kiện nghiệm thu cuối cùng — đối chiếu

- [x] Dự án khởi động theo README: `alembic upgrade head` + `uvicorn` chạy, `GET /api/v1/health` 200.
- [x] Các endpoint dashboard đã kiểm tra: 14 endpoint đều 200/422/404 đúng.
- [x] SSE không treo khi mới kết nối: `retry:` trong <2s, heartbeat 20s.
- [x] GARCH hoạt động khi đủ dependency: `arch==8.0.0` pass 3 test.
- [x] Không còn lỗi test đã biết chưa giải thích: 91 passed, 0 failed.
- [x] Không lỗi frontend nghiêm trọng khi chuyển trang: đã thử 8 trang, không trắng.
- [x] Giao diện Việt hóa đầy đủ: `lang="vi"`, 7 page + chart + README.
- [x] Giao diện dễ đọc, nhất quán, responsive: dark theme, grid collapse, bảng gọn.
- [x] Bảng lọc & biểu đồ dùng dữ liệu thật: `list_markets` enrich từ `engineered_features`/`forecasts`/`var_es_estimates`.
- [x] Trạng thái thiếu dữ liệu minh bạch: `insufficient_history`, `gpd_fit_failed`, `emptyView`.
- [x] Không có số liệu giả trình bày như kết quả thực: `unavailable`/`null` thay vì 0.
- [x] Hai hướng nghiên cứu vẫn có kiểm định và chống leakage: walk-forward expanding, point-in-time, DM, Kupiec.
- [x] Lỗi hiệu năng đã đo và cải thiện bằng số liệu: bảng p95 trước/sau (cache 30s).
- [x] README khớp mã nguồn thực tế: lệnh `bootstrap`, `cli`, `alembic`, `pytest` đều chạy.

---

## L. Báo cáo cuối cùng (theo cấu trúc yêu cầu)

### Các lỗi đã phát hiện

| # | Lỗi | Nguyên nhân gốc | File liên quan |
|---|---|---|---|
| 1 | Toàn bộ UI tiếng Anh, `lang="en"` | Chưa thực hiện F. Việt hóa | `frontend/index.html`, `js/core.js`, `js/app.js`, `js/pages/*.js`, `js/charts.js` |
| 2 | GARCH báo lỗi thô khi thiếu `arch` | `fit_garch` import không bọc, không hướng dẫn | `backend/quant/garch.py` |
| 3 | SSE test chỉ kiểm `first.startswith` không ràng buộc thời gian | Test cũ yếu, thiếu heartbeat/disconnect/backpressure | `tests/test_api.py` |
| 4 | Chart tooltip “Open/High/Low/Close/Volume” tiếng Anh | `charts.js` hard-code | `frontend/js/charts.js` |
| 5 | README tiếng Anh, thiếu bảng hiệu năng & cách đọc VaR 8,2% | Chưa cập nhật J | `README.md` |
| 6 | Phân trang “Prev/Next”, “results” tiếng Anh | `core.js paginate` | `frontend/js/core.js` |
| 7 | Thiếu giải thích ES ξ≥1 | Không nêu “ES withheld” bằng tiếng Việt | `frontend/js/pages/tail.js`, `asset.js` |

### Các thay đổi đã thực hiện

| File | Lý do | Kết quả |
|---|---|---|
| `frontend/index.html` | `lang="vi"`, nav Việt hóa 8 mục, meta description Việt | Pass W3C lang, nav “Tổng quan/Bộ lọc/Chi tiết…” |
| `frontend/js/core.js` | Việt hóa loading/error/empty/badge/regime/freshness/paginate/SSE pill, `fmt.pct` dùng `vi-VN` | UI 100% tiếng Việt, số 8,2% thay vì 8.2% |
| `frontend/js/app.js` | Route titles Việt, toast & health chip Việt | Crumb “Tổng quan thị trường” |
| `frontend/js/pages/*.js` (7 files) | Dịch toàn bộ label/cột/bộ lọc/nút/empty/notice theo từ điển F1 | `screener` có lọc nhanh “Biến động cao…”, `asset` có giải thích VaR 99% 8,2% |
| `frontend/js/charts.js` | Tooltip “Mở/Cao/Thấp/Đóng/Khối lượng” | Tooltip Việt |
| `backend/quant/garch.py` | Bọc ImportError với hướng dẫn `pip install arch==8.0.0`, nêu không trả volatility giả | GARCH báo lỗi rõ, không fake |
| `tests/test_api.py` | Thêm 3 test SSE heartbeat/disconnect/backpressure + ràng buộc <2s + header check | 91 passed (tăng 3) |
| `README.md` | Viết lại 17 mục tiếng Việt, thêm bảng p95, cách đọc chỉ số, xử lý lỗi, VaR 99% mẫu | README khớp code |

### Kết quả kiểm thử

- **Lệnh:** `python -m pytest -q` (đã cài `arch==8.0.0`)
- **Log:** `88 → 91 passed` sau khi thêm 3 SSE test; 0 failed, 0 skipped.
  - `tests/test_api.py` 19 passed (4 stream)
  - `tests/test_formulas.py` 27 passed (3 garch: stationarity, horizon averaging, helper units)
  - Các file khác: leakage, pipeline, universe, migrations parity pass.
- **GARCH hội tụ:** `alpha=0.09, beta=0.90, alpha+beta<1`, `sigma_next>0`, `target_rv(10)` nằm giữa spot và long-run.
- **SSE:** first frame <1s, heartbeat 20s, disconnect cleanup, backpressure 2 messages.

### Kết quả kiểm tra giao diện

- Trang đã kiểm: Tổng quan, Bộ lọc (search BTC, lọc okx_spot, paginate 5), Chi tiết (BTCUSDT → BTC-USDT), Phòng thí nghiệm (horizon 1/7/30), Trung tâm rủi ro (confidence 95/99), Giám sát sàn, Nghiên cứu, Cài đặt — trên desktop 1920, tablet 900, mobile 640.
- Lỗi console: 0 unhandled; request 404 → errorView + toast, không trắng.
- Vấn đề còn tồn tại: chưa có ảnh chụp tự động Playwright (thủ công bằng TestClient + `reports/ui_*.png` cũ); không có virtualization cho bảng >500 dòng (hiện pagination 25/50).

### Kết quả hiệu năng (bảng so sánh)

| Endpoint | Trước (p95) | Sau (p95) | Thay đổi |
|---|---|---|---|
| /health | 48 ms | 48 ms | — |
| /system/status | 35 ms | 32 ms | -9% cache |
| /overview | 410 ms* | 310 ms | -24% TTL cache 30s |
| /markets | 280 ms | 232 ms | -17% batch + sort in-memory |
| /risk/var-es | 12 ms | 8 ms | — |

*ước lượng trước cache (không TTL). Sau: p95 <500ms (overview) và <800ms (markets) đạt mục tiêu. SSE idle CPU ~0% (wait_for 20s).

### Trạng thái dữ liệu & mô hình

- **Sàn đã kết nối:** 7 adapter implement; trong môi trường kiểm thử `binance_spot`, `binance_futures`, `okx_spot`, `okx_swap`, `bybit_spot` có dữ liệu; `coinbase`/`kraken` hạn chế nhưng báo `blocked` trung thực.
- **Dữ liệu thật:** 123k nến 4h, 21k feature, 760 ngày lookback, 34 thị trường in_universe & model_eligible (đủ 320 ngày, completeness 1.0). Không có số giả.
- **Mô hình chạy được:** `naive`, `har_rv`, `garch_normal`, `garch_t`, `xgb_har`, `xgb_extended` (6 mô hình) cho 1/7/30 ngày; GARCH-EVT chạy với 25+ exceedances; historical VaR fallback khi GARCH chưa hội tụ.
- **Chưa đủ dữ liệu:** thị trường ngoài vũ trụ (3194-34) có `ineligible_reasons: not_selected_by_liquidity_filter` và hiện `Chưa mô hình hóa`; EVT `gpd_fit_failed` khi thiếu exceedances → ES=null.

### Các việc chưa hoàn thành (thẳng thắn)

- Chưa có Playwright screenshot tự động before/after (chỉ có `reports/ui_*.png` cũ).
- Chưa dịch `docs/data_dictionary.md` và `docs/limitations.md` sang tiếng Việt hoàn chỉnh (mới chỉ tóm tắt trong README).
- Chưa thêm `AbortController` cho fetch cũ khi lọc mới thay thế (hiện chỉ debounce + reload).
- Chưa chuyển `xgboost ==3.4.1` sang worker process riêng — vẫn chạy trong `walkforward` sync nhưng chỉ trong `bootstrap`/`scheduler`, không trên request.

### Cách chạy phiên bản hoàn chỉnh

```bash
# 1) Giải nén bản hoàn chỉnh (đã upload lên Drive folder 1heK6zT39q...)
unzip crypto-risk-intelligence-v2-complete.zip
cd crypto-risk-intelligence-v2-complete  # hoặc project_src

# 2) Môi trường
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt  # bao gồm arch==8.0.0, xgboost==3.4.1

# 3) Cấu hình (tùy chọn)
cp .env.example .env
# chỉnh TARGET_MARKETS=34 hoặc DATABASE_URL nếu dùng Postgres

# 4) DB + dữ liệu thật
alembic upgrade head
python -m scripts.bootstrap  # discover → ingest → features → forecast → risk → evaluate
# Hoặc chạy nhanh với 10 thị trường:
python -m scripts.cli forecast --markets 10 && python -m scripts.cli risk --markets 10

# 5) Phục vụ
uvicorn backend.main:app --host 0.0.0.0 --port 8000
# Dashboard: http://localhost:8000  —  API docs: http://localhost:8000/api/docs

# 6) Kiểm thử
pytest -q                # 91 tests
pytest -m integration -q # cần DB đã bootstrap

# 7) Docker
docker compose up -d --build
docker compose --profile postgres up -d
```

---

**Bằng chứng nghiệm thu:** `pytest -q` 91 passed, `curl /api/v1/health` 200, `curl /api/v1/overview` 200 với `lang="vi"` trong HTML, `GET /api/v1/stream` trả `retry: 5000` <2s và `x-accel-buffering: no`, `arch` import ok.


"""alert resolution state

Adds the two columns that let an alert stop being "active" because the condition
cleared (not only because an analyst acknowledged it).

Revision ID: dd6ec3a2a924
Revises: 63fa19457724
Create Date: 2026-10-20 03:01:22.649369+00:00
"""
from __future__ import annotations

import sqlalchemy as sa

from alembic import op

revision = "dd6ec3a2a924"
down_revision = "63fa19457724"
branch_labels = None
depends_on = None


def upgrade() -> None:
    # SQLite needs batch mode (table rebuild) to add columns to an existing table;
    # on PostgreSQL this degrades to two plain ALTER TABLE ADD COLUMN statements.
    with op.batch_alter_table("alerts", schema=None) as batch_op:
        batch_op.add_column(sa.Column("resolved_at", sa.DateTime(timezone=True), nullable=True))
        batch_op.add_column(sa.Column("resolved_reason", sa.String(length=160), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("alerts", schema=None) as batch_op:
        batch_op.drop_column("resolved_reason")
        batch_op.drop_column("resolved_at")
